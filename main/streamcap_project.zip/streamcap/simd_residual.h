// ============================================================================
// simd_residual.h
//
// Public entry points the codec calls. Internally these route through a
// function pointer chosen once by InitSimdResidualDispatch() (AVX2 on x86_64
// if the CPU+OS support it, NEON on ARM, otherwise the portable scalar
// fallback) -- callers never need to know which one is actually running.
//
// Both operate on a single image plane (call once per Y/U/V plane; chroma
// planes are just a smaller width/height/stride than luma, same math).
// ============================================================================
#pragma once
#include <cstdint>

// residual[i] = clamp(orig[i] - upscaled[i] + 128, 0, 255)
void ComputeResidualPlane(const uint8_t *orig, int origStride,
                           const uint8_t *upscaled, int upscaledStride,
                           uint8_t *out, int outStride,
                           int width, int height);

// recon[i] = clamp(upscaled[i] + residual[i] - 128, 0, 255)
void AddResidualPlane(const uint8_t *upscaled, int upscaledStride,
                       const uint8_t *residual, int residualStride,
                       uint8_t *out, int outStride,
                       int width, int height);

// Detects the CPU's SIMD tier (via architecture.h) and points the two
// functions above at the matching implementation. Cheap, idempotent, and
// safe to call more than once (e.g. from multiple FrameCodec instances) --
// only the first call does any real work. Call this once at startup before
// the first encode/decode call; codec_common.h's FrameCodec::init() does
// this for you.
void InitSimdResidualDispatch();
