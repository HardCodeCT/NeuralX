// ============================================================================
// diff_detector.h / diff_detector.cpp
//
// Splits a frame into a grid of small blocks and, against the previous
// frame, reports which blocks actually changed -- then reduces that
// scattered dirty-block map down to a single bounding rectangle. This is
// what turns "capture a new screenshot 24x/sec" into "only send the one
// rectangle of the screen that actually moved" -- typing a line of text or
// nudging the mouse touches a handful of small blocks clustered in one
// area, and the bounding box collapses all of them into one small region
// instead of one region per block.
//
// IMPORTANT: detection is meant to run on a DOWNSCALED proxy of the
// captured frame, not the native-resolution capture. Comparing every byte
// of a 1900x900 capture (SAD over ~6.8MB, twice -- previous and current)
// is real, measurable CPU cost every single frame; comparing a ~633x300
// proxy is roughly 9x less data to touch. DownscaleBoxAverage() below
// produces that proxy, and MapBoundingBoxToFullRes() converts the
// resulting bounding box back to full-resolution pixel coordinates so the
// sender can still extract and compress the ORIGINAL full-quality pixels
// for that region -- only detection runs at reduced resolution, never the
// actual transmitted content.
//
// Comparison is done with the same SAD (sum of absolute differences)
// approach and the same AVX2/scalar dispatch shape as simd_residual.cpp:
// detect the CPU tier once via architecture.h, then always call through a
// cached function pointer.
//
// Detection granularity is deliberately fine (8x8px blocks of the
// downscaled proxy, not 64x64) -- finer granularity means the bounding box
// hugs the actual changed pixels more tightly instead of being dragged out
// to the edges of a coarse tile that's mostly unchanged. The trade is more
// blocks to scan per frame (~2,923 for a 633x300 proxy), which is why the
// SAD comparison itself stays SIMD-accelerated with an aggressive early-out.
// ============================================================================
#pragma once
#include <algorithm>
#include <cstdint>
#include <vector>

namespace diffdet {

// One entry per block, row-major (block (bx,by) is at index by*blocksX+bx).
// true = changed since the previous frame (by more than `threshold`).
struct TileGrid {
    int tilesX = 0, tilesY = 0, tileSize = 0;
    int fullW = 0, fullH = 0;
    std::vector<uint8_t> dirty; // 0/1 per block

    int tileCount() const { return tilesX * tilesY; }
    // Pixel-space bounds of block index i, clipped to the frame edge (the
    // last row/column of blocks is usually smaller than tileSize).
    void tileBounds(int i, int &x, int &y, int &w, int &h) const {
        int tx = i % tilesX, ty = i / tilesX;
        x = tx * tileSize;
        y = ty * tileSize;
        w = std::min(tileSize, fullW - x);
        h = std::min(tileSize, fullH - y);
    }
};

// A single dirty region in pixel coordinates of whichever space it was
// computed in (downscaled proxy or full frame -- see MapBoundingBoxToFullRes
// for converting between the two). width/height == 0 means "nothing
// changed" (no valid rectangle).
struct BoundingBox {
    int x = 0, y = 0, width = 0, height = 0;
    bool empty() const { return width <= 0 || height <= 0; }
};

// Computes tilesX/tilesY for a given frame size + block size (ceil-div, so
// the grid always covers the whole frame even when it doesn't divide evenly).
TileGrid makeGrid(int fullW, int fullH, int tileSize);

// Compares `curr` against `prev` (both tightly packed BGRA8, `strideBytes`
// each) block-by-block and fills grid.dirty. `threshold` is the maximum
// summed absolute byte difference within a block that still counts as
// "unchanged" -- 0 means bit-exact match required (the right default for
// screen capture: unlike a camera sensor, a static desktop really is
// byte-identical frame to frame).
//
// Intended to be called on a DOWNSCALED proxy of the captured frame (see
// DownscaleBoxAverage), not the native-resolution capture -- see the file
// header comment above for why.
void DetectDirtyTiles(const uint8_t *prev, const uint8_t *curr, int strideBytes,
                       TileGrid &grid, uint32_t threshold = 0);

// Scans grid.dirty once and returns the smallest axis-aligned rectangle
// (in the same coordinate space as `grid` -- downscaled proxy pixels, if
// that's what was passed to DetectDirtyTiles) that contains every dirty
// block. This is a single O(blockCount) pass over already-computed boolean
// flags -- negligible cost (microseconds, not milliseconds) even at
// ~2,923 blocks, so it doesn't need SIMD of its own; the SAD comparison in
// DetectDirtyTiles() is where the real per-frame cost lives.
// Returns an empty BoundingBox (width==height==0) if no blocks are dirty.
BoundingBox ComputeDirtyBoundingBox(const TileGrid &grid);

// Downscales `src` (tightly packed BGRA8, `srcStrideBytes`, srcW x srcH)
// into `dst` (BGRA8, `dstStrideBytes`, dstW x dstH) via non-overlapping box
// averaging: every source pixel contributes to exactly one destination
// pixel, with no gaps and no double-counting, even when srcW/srcH aren't
// evenly divisible by dstW/dstH (the standard "partition by
// index*srcSize/dstSize" scheme -- matched exactly by
// MapBoundingBoxToFullRes below, which is what makes round-tripping a
// bounding box through this downscale and back lossless in terms of pixel
// coverage).
//
// Correctness note: because this is a genuine average (not a nearest-pixel
// subsample), it's extremely unlikely -- but not mathematically
// impossible -- for two pixels changing in exactly offsetting directions
// within the same source block to leave that block's average unchanged,
// which would hide a real change from detection. For screen-capture
// content (flat UI regions, text, cursor movement) this is a negligible
// risk in practice, but it's a real, disclosed limitation of averaging as
// a downscale strategy, not a guarantee-free zone.
void DownscaleBoxAverage(const uint8_t *src, int srcW, int srcH, int srcStrideBytes,
                          uint8_t *dst, int dstW, int dstH, int dstStrideBytes);

// Converts a BoundingBox computed in a `dsW`x`dsH` downscaled proxy's pixel
// space (produced by ComputeDirtyBoundingBox after running detection on a
// DownscaleBoxAverage'd proxy) back to `fullW`x`fullH` full-frame pixel
// coordinates. Uses the exact same index*fullSize/dsSize partition boundary
// as DownscaleBoxAverage, so the resulting rectangle covers precisely every
// full-resolution pixel that could have contributed to any dirty proxy
// pixel -- no separate padding margin is needed for coverage.
BoundingBox MapBoundingBoxToFullRes(const BoundingBox &dsBox, int dsW, int dsH,
                                     int fullW, int fullH);

// Same one-time detect-and-cache pattern as simd_residual.h. Called
// internally by DetectDirtyTiles() on first use; exposed so callers can
// force it (and log the chosen tier) up front if they want to.
void InitDiffDispatch();

} // namespace diffdet
