# Screen-capture -> scalable codec -> localhost stream

All Windows/MSVC:

- **architecture.h / architecture.cpp** — pure CPU/OS capability detection.
  No image code lives here; it just answers "does this CPU (and, for AVX2,
  does the OS) actually support the vector tier this binary was built for?"
  and returns `Scalar` / `AVX2` / `NEON`.
- **simd_residual.h / simd_residual.cpp** — the residual math
  (`orig - upscaled + 128` clamped, and its inverse) in three forms: scalar
  (1 byte/iter), AVX2 (32 bytes/iter, x86_64 only), NEON (16 bytes/iter, ARM
  only). `InitSimdResidualDispatch()` calls `architecture.cpp` once, caches
  the result behind `std::call_once`, and points two function pointers at
  the matching implementation — every call after that first one goes
  straight through the pointer, no branching per call.
- **diff_detector.h / diff_detector.cpp** *(sender-side only)* —
  SIMD-accelerated (same dispatch pattern) 8x8-block change detection
  between the current and previous frame's *downscaled detection proxies*
  (not the native-resolution capture — see `DownscaleBoxAverage`), plus
  `ComputeDirtyBoundingBox()` (reduces dirty blocks to one rectangle) and
  `MapBoundingBoxToFullRes()` (converts that rectangle back to
  full-resolution pixel coordinates before extraction).
- **codec_common.h** — shared per-frame codec. MJPEG for the low-res base
  layer, FFV1 (lossless) for the full-res residual, both intra-only so each
  frame is encoded/decoded completely independently (no video container,
  no inter-frame state — correct for live frame-by-frame transmission). Its
  residual step calls into `simd_residual.h` instead of a scalar loop. Also
  still contains `TileCodec` (a fixed-size, per-region lossless FFV1
  codec) — unused by the current delta path (see the comment above its
  definition), kept as a reusable building block.
- **lz4.h / lz4.c** — vendored LZ4 (BSD-2-Clause, official lz4/lz4 repo).
- **lz4_rect_codec.h** — thin zero-alloc wrapper around LZ4 used to
  compress/decompress the single dirty rectangle each delta frame carries.
  Chosen over reusing FFV1/TileCodec for this because FFV1 wants a
  fixed-size, persistent codec context, and the rectangle's dimensions
  change every frame; LZ4 has no setup cost and compresses whatever size
  buffer you hand it in one call.
- **wire_protocol.h** — shared 17-byte framed message format (type + frame
  index + tile index + payload size) + the hardcoded endpoint
  (`127.0.0.1:5000`, in one place so sender and receiver can't drift out of
  sync).
- **sender_client.cpp** — Windows Graphics Capture client. Captures the
  primary monitor, hard-locks to 24 FPS by dropping frames in the
  `FrameArrived` callback, reads back through a `D3D11_USAGE_STAGING`
  texture, strips row-pitch padding into a tightly packed buffer, hands it
  to a network thread via a lock-free triple buffer. That thread compares
  each frame against the previous one at 8x8-block granularity: if most of
  the screen changed, it sends a full frame through the scalable codec;
  otherwise it collapses every dirty block into one bounding rectangle,
  LZ4-compresses just that region, and sends it as a single message (and
  nothing at all if the screen didn't change).
- **receiver_server.cpp** — listens on `127.0.0.1:5000`, maintains a
  persistent BGRA canvas, applies incoming full-frame overwrites or
  single-rectangle delta patches to it, and writes each updated frame out
  as `received_frames/frame_000123.bmp` — individual image frames, not a
  muxed video file.

## Delta encoding: downscaled 8x8-block detection -> one bounding rectangle -> LZ4

Every captured frame is first **downscaled into a small detection proxy**
(~1/3 linear size by default, ~1/9 the pixels — `kDetectionDownscaleFactor`
in `sender_client.cpp`, via `DownscaleBoxAverage`), and change detection
runs entirely on that proxy against the *previous frame's proxy* — never
the native-resolution capture. This is deliberate: comparing every byte of
a 1900x900 capture against the previous frame is real, measurable CPU cost
every single frame; a ~633x300 proxy is roughly 9x less data to touch for
the same detection quality.

Detection then runs at fine (8x8px, of the *proxy*) granularity so the
resulting bounding box hugs the actual changed pixels tightly — a single
line of typed text collapses to one small rectangle instead of being
dragged out to the edges of a handful of coarse 64x64 tiles. Every dirty
block found gets reduced to **one** rectangle (not one message per block),
in the proxy's coordinate space; that rectangle is then mapped back to
full-resolution pixel coordinates (`MapBoundingBoxToFullRes`) before the
sender extracts the ORIGINAL full-quality pixels for that region — only
the *decision* of what changed runs at reduced resolution, never the
transmitted content. The extracted rectangle is packed out of the (strided)
capture buffer into a contiguous scratch buffer, LZ4-compressed, and sent
as the entire `MSG_FRAME_DELTA` payload: `[rect_x][rect_y][rect_w][rect_h]`
+ compressed bytes. `rect_w == 0` means nothing changed at all. If more
than 50% of blocks are dirty (e.g. a full-screen video or window drag), the
sender falls back to a full-frame send through the lossy scalable codec
instead — this also caps worst-case per-frame bandwidth.

Two tradeoffs worth knowing, both disclosed in code comments where they're
made:
- **Single bounding box, not multiple rectangles.** A box covers everything
  between two simultaneously-changed regions even if they're on opposite
  sides of the screen (e.g. a clock tick in one corner plus a cursor blink
  in another). Deliberate simplicity/bandwidth tradeoff — large win for the
  target case (typing, mouse movement, localized UI changes), and still
  bounded by the 50% full-frame fallback in the worst case.
- **Box-average downscaling, not subsampling.** Averaging (rather than
  picking every Nth pixel) guarantees a change can't fall "between" sampled
  points and get missed outright. The residual risk is two pixels changing
  in exactly offsetting directions within the same averaging block leaving
  that block's average unchanged — vanishingly unlikely for real screen
  content, but a genuine, disclosed limitation of averaging, not something
  silently guaranteed against.

## About the AVX2/NEON split

You can't compile both into one binary and pick at runtime the way you can
pick AVX2-vs-scalar on the same CPU — AVX2 intrinsics only assemble into
x86_64 machine code, NEON intrinsics only assemble into ARM machine code.
So `simd_residual.cpp`/`diff_detector.cpp` guard each vector implementation
behind `#if defined(ARCH_X86)` / `#if defined(ARCH_ARM)` (set from the
target triple/`_M_*` macros at the top of the file) — you build this
project once per target architecture, and *within* that build,
`architecture.cpp` decides at runtime whether the specific CPU actually has
the ISA the binary was compiled for (e.g. an older x86_64 chip without
AVX2 still gets a correct, working build — it just falls back to scalar).

## Dependencies

- FFmpeg dev libraries: `avcodec`, `avutil`, `swscale` (headers + `.lib`s).
  Grab a shared build from https://www.gyan.dev/ffmpeg/builds/ (the
  "shared" package includes `include/` and `lib/`), or build/vcpkg your own.
- Windows 10 SDK (for WGC — `windows.graphics.capture.interop.h` requires
  a reasonably recent SDK, 10.0.18362.0+).
- `windowsapp.lib` for the WinRT activation factory calls in the sender.
- LZ4 is vendored in-tree (`lz4.h`/`lz4.c`) — nothing extra to install.

## Build (Developer PowerShell for VS, x64)

```powershell
# Sender (Windows-only, needs WGC + D3D11)
# /arch:AVX2 lets the compiler assemble the AVX2 intrinsics in
# simd_residual.cpp/diff_detector.cpp; architecture.cpp still checks at
# runtime whether the CPU actually has AVX2 before that path is used, so
# this build still runs correctly (falling back to scalar) on older x86_64
# CPUs.
cl /std:c++20 /EHsc /await /arch:AVX2 `
   sender_client.cpp codec_common.h architecture.cpp simd_residual.cpp diff_detector.cpp lz4.c `
   /I C:\ffmpeg\include `
   /link /LIBPATH:C:\ffmpeg\lib avcodec.lib avutil.lib swscale.lib `
         d3d11.lib dxgi.lib windowsapp.lib ws2_32.lib

# Receiver (doesn't need diff_detector.cpp -- detection is sender-side only)
cl /std:c++20 /EHsc /arch:AVX2 `
   receiver_server.cpp architecture.cpp simd_residual.cpp lz4.c `
   /I C:\ffmpeg\include `
   /link /LIBPATH:C:\ffmpeg\lib avcodec.lib avutil.lib swscale.lib ws2_32.lib
```

On an ARM64 build (e.g. `cl` targeting ARM64, or clang with
`--target=aarch64-...`), drop `/arch:AVX2` — `architecture.cpp` and
`simd_residual.cpp`/`diff_detector.cpp` all auto-select the NEON path at
compile time via the `_M_ARM64`/`__aarch64__` macros, no other change
needed.

Put `avcodec-*.dll`, `avutil-*.dll`, `swscale-*.dll` next to both `.exe`s
(or on `PATH`) before running.

## Run

Start the **receiver first** (it's the listener):

```powershell
.\receiver_server.exe
```

Then start the sender (it connects out as the client):

```powershell
.\sender_client.exe
```

You should see `received_frames/frame_000000.bmp`, `frame_000001.bmp`, ...
appear while the sender runs — far less frequently updated once things are
static, since unchanged frames after the first no longer trigger a write.

## Notes / things you'll likely want to change

- **One connection only.** The receiver `accept()`s a single client and
  exits when it disconnects — fine for a point-to-point live link, not a
  multi-viewer server. Wrap the accept loop if you need more than one.
- **Single bounding rectangle, not multiple.** See the tradeoff note above
  — simplest to implement and covers the common case well, but two
  far-apart simultaneous changes cost more bandwidth than a
  multi-rectangle scheme would. `TileCodec` (still present, unused) is one
  possible building block for a future multi-rectangle version.
- **Base-layer quality/size.** `kLowResHeight` in `sender_client.cpp`
  (currently 360p) and the MJPEG `qscale` in `codec_common.h::openEncoder`
  trade base-layer bandwidth against how much detail the lossless
  enhancement layer has to carry.
- **BMP output.** Swap `writeBmp()` for a PNG encoder (e.g. `libpng` or
  `stb_image_write.h`) if you want smaller files on disk — BMP was chosen
  here for zero extra dependencies.
- **Capture target.** `initCaptureItem()` captures the primary monitor via
  `MonitorFromWindow(nullptr, MONITOR_DEFAULTTOPRIMARY)`. Swap in
  `CreateCaptureItemForWindow` (interop) if you want to capture a single
  window instead.
