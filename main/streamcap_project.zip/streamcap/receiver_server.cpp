// ============================================================================
// receiver_server.cpp
//
// Listens on a hardcoded localhost:port TCP socket and reconstructs the
// sender's screen frame by frame, using either of two message shapes the
// sender picks per-frame:
//
//   MSG_FRAME_FULL + MSG_BASE + MSG_ENH   -- whole frame, via the scalable
//     image codec (MJPEG base + FFV1 lossless residual).
//   MSG_FRAME_DELTA                        -- a single message whose payload
//     is [rect_x][rect_y][rect_w][rect_h] + LZ4-compressed BGRA bytes of
//     just that one rectangle -- the bounding box of everything that
//     changed since the previous frame (see diff_detector.h on the sender
//     side). rect_w/rect_h == 0 means nothing changed at all.
//
// A persistent BGRA "canvas" is maintained across frames: a full-frame
// message overwrites it entirely, a delta message overwrites only the one
// rectangle that was sent, leaving everything else exactly as it was.
// Each reconstructed/updated frame is emitted as a standalone image (BMP)
// rather than muxed into a video file, since this is live transmission.
//
// Build (MSVC, x64):
//   cl /std:c++20 /EHsc receiver_server.cpp architecture.cpp simd_residual.cpp lz4.c ^
//      /I<ffmpeg_include> ^
//      /link /LIBPATH:<ffmpeg_lib> avcodec.lib avutil.lib swscale.lib ws2_32.lib
//
// Architecture:
//   - Network/decode thread: reads the socket (recvMessage() loops recv()
//     until a full header+payload has arrived, so a message split across
//     multiple TCP segments is handled correctly -- see TcpReceiver below),
//     applies full-frame or delta-rect updates to the canvas as they
//     complete, and publishes the resulting BGRA canvas into a
//     pre-allocated triple buffer -- mirroring the sender's zero-alloc,
//     non-blocking hand-off pattern so slow disk I/O never stalls the
//     socket read loop. A delta frame with an empty rect (screen
//     unchanged) is never published at all, so a static desktop costs the
//     writer thread nothing.
//   - Writer thread: claims the latest published canvas and writes it out
//     as frame_%06lld.bmp into the output directory.
// ============================================================================

#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>

#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <thread>
#include <vector>

#include "codec_common.h"
#include "wire_protocol.h"
#include "lz4_rect_codec.h"

namespace fs = std::filesystem;

// ----------------------------------------------------------------------------
// Same triple-buffer pattern as the sender: the decode thread never blocks
// on the writer thread, and the writer thread never blocks the decode/socket
// thread. No allocation in either thread's steady-state hot path.
// ----------------------------------------------------------------------------
class TripleBuffer {
public:
    void init(size_t bytesPerFrame) {
        for (auto &b : buf_) b.assign(bytesPerFrame, 0);
    }
    uint8_t *writeSlot() { return buf_[writeIndex_].data(); }
    void publish(int64_t frameIndex) {
        readyIndex_.store(writeIndex_, std::memory_order_release);
        readyFrameIndex_.store(frameIndex, std::memory_order_release);
        writeIndex_ = (writeIndex_ + 1) % 3;
        if (writeIndex_ == readIndex_.load(std::memory_order_acquire))
            writeIndex_ = (writeIndex_ + 1) % 3;
    }
    const uint8_t *claimLatest(int64_t &outFrameIndex) {
        int idx = readyIndex_.load(std::memory_order_acquire);
        int64_t fi = readyFrameIndex_.load(std::memory_order_acquire);
        if (fi == lastConsumed_) return nullptr;
        lastConsumed_ = fi;
        readIndex_.store(idx, std::memory_order_release);
        outFrameIndex = fi;
        return buf_[idx].data();
    }
private:
    std::vector<uint8_t> buf_[3];
    int writeIndex_ = 0;
    std::atomic<int> readIndex_{0};
    std::atomic<int> readyIndex_{-1};
    std::atomic<int64_t> readyFrameIndex_{-1};
    int64_t lastConsumed_ = -1;
};

// ----------------------------------------------------------------------------
// Writes a tightly packed top-down BGRA8 buffer out as a standard (bottom-up)
// 32-bit BMP -- the most broadly viewable option for a plain still image.
// ----------------------------------------------------------------------------
static void writeBmp(const fs::path &path, const uint8_t *bgraTopDown, int w, int h) {
    const int rowBytes = w * 4;
    const uint32_t pixelDataSize = static_cast<uint32_t>(rowBytes) * h;
    const uint32_t fileSize = 14 + 40 + pixelDataSize;

    std::vector<uint8_t> header(14 + 40);
    uint8_t *p = header.data();
    p[0] = 'B'; p[1] = 'M';
    std::memcpy(p + 2, &fileSize, 4);
    uint32_t zero = 0; std::memcpy(p + 6, &zero, 4);
    uint32_t dataOffset = 14 + 40; std::memcpy(p + 10, &dataOffset, 4);

    uint32_t dibSize = 40; std::memcpy(p + 14, &dibSize, 4);
    int32_t width = w; std::memcpy(p + 18, &width, 4);
    int32_t height = h; std::memcpy(p + 22, &height, 4); // positive: bottom-up
    uint16_t planes = 1; std::memcpy(p + 26, &planes, 2);
    uint16_t bpp = 32; std::memcpy(p + 28, &bpp, 2);
    uint32_t compression = 0; std::memcpy(p + 30, &compression, 4);
    std::memcpy(p + 34, &pixelDataSize, 4);
    int32_t ppm = 2835; std::memcpy(p + 38, &ppm, 4);
    std::memcpy(p + 42, &ppm, 4);
    uint32_t zero2 = 0; std::memcpy(p + 46, &zero2, 4);
    std::memcpy(p + 50, &zero2, 4);

    FILE *f = nullptr;
    if (_wfopen_s(&f, path.c_str(), L"wb") != 0 || !f) return;
    std::fwrite(header.data(), 1, header.size(), f);
    // BMP rows are bottom-up; our source buffer is top-down, so reverse row order.
    for (int y = h - 1; y >= 0; --y)
        std::fwrite(bgraTopDown + static_cast<size_t>(y) * rowBytes, 1, rowBytes, f);
    std::fclose(f);
}

// ----------------------------------------------------------------------------
// Minimal blocking TCP server: accepts exactly one connection (one live
// sender), per the hardcoded localhost pairing with sender_client.cpp.
// ----------------------------------------------------------------------------
class TcpReceiver {
public:
    TcpReceiver() {
        WSADATA wsaData;
        if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
            throw std::runtime_error("WSAStartup failed");
    }
    ~TcpReceiver() {
        if (client_ != INVALID_SOCKET) closesocket(client_);
        if (listenSock_ != INVALID_SOCKET) closesocket(listenSock_);
        WSACleanup();
    }

    void listenAndAccept() {
        listenSock_ = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (listenSock_ == INVALID_SOCKET) throw std::runtime_error("socket() failed");

        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(endpoint::PORT);
        inet_pton(AF_INET, endpoint::HOST, &addr.sin_addr); // hardcoded 127.0.0.1

        int one = 1;
        setsockopt(listenSock_, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<const char *>(&one), sizeof(one));

        if (bind(listenSock_, reinterpret_cast<sockaddr *>(&addr), sizeof(addr)) != 0)
            throw std::runtime_error("bind() failed");
        if (listen(listenSock_, 1) != 0)
            throw std::runtime_error("listen() failed");

        std::fprintf(stderr, "[receiver] listening on %s:%u ...\n", endpoint::HOST, endpoint::PORT);
        client_ = accept(listenSock_, nullptr, nullptr);
        if (client_ == INVALID_SOCKET) throw std::runtime_error("accept() failed");

        int nodelay = 1;
        setsockopt(client_, IPPROTO_TCP, TCP_NODELAY, reinterpret_cast<const char *>(&nodelay), sizeof(nodelay));
        std::fprintf(stderr, "[receiver] sender connected\n");
    }

    // Returns false on clean disconnect.
    bool recvMessage(wire::Header &outHeader, std::vector<uint8_t> &outPayload) {
        uint8_t hdr[wire::HEADER_SIZE];
        if (!recvAll(hdr, sizeof(hdr))) return false;
        outHeader = wire::Header::parse(hdr);
        outPayload.resize(outHeader.payloadSize);
        if (outHeader.payloadSize && !recvAll(outPayload.data(), outHeader.payloadSize)) return false;
        return true;
    }

private:
    SOCKET listenSock_ = INVALID_SOCKET;
    SOCKET client_ = INVALID_SOCKET;

    bool recvAll(uint8_t *data, size_t size) {
        size_t got = 0;
        while (got < size) {
            int rc = recv(client_, reinterpret_cast<char *>(data) + got,
                           static_cast<int>(size - got), 0);
            if (rc <= 0) return false; // 0 = clean close, <0 = error
            got += static_cast<size_t>(rc);
        }
        return true;
    }
};

int main() {
    const fs::path outDir = "received_frames";
    fs::create_directories(outDir);

    try {
        TcpReceiver server;
        server.listenAndAccept();

        // ---- Handshake: read MSG_CONFIG before anything else. ----
        wire::Header hdr;
        std::vector<uint8_t> payload;
        if (!server.recvMessage(hdr, payload) || hdr.type != wire::MSG_CONFIG)
            throw std::runtime_error("expected MSG_CONFIG as first message");
        auto cfg = wire::parseConfigPayload(payload);
        std::fprintf(stderr, "[receiver] full %dx%d, base %dx%d, dirty-detection block %dpx (%dx%d grid, sender-side only)\n",
                     cfg.fullW, cfg.fullH, cfg.lowW, cfg.lowH, cfg.tileSize, cfg.tilesX, cfg.tilesY);

        scalcodec::FrameCodec fullCodec;
        // lowW/lowH are re-derived deterministically from fullW/fullH/targetHeight
        // on both sides via computeLowRes(), so passing the received cfg.lowH as
        // the target height reproduces the identical low-res dimensions.
        fullCodec.init(scalcodec::FrameCodec::Side::Receiver, cfg.fullW, cfg.fullH, cfg.lowH);

        TripleBuffer tripleBuf;
        tripleBuf.init(static_cast<size_t>(cfg.fullW) * cfg.fullH * 4);

        // Zero-alloc scratch for the delta-rect path: worst case a
        // rectangle covers the whole frame, so size for that once, up
        // front, and never resize on the hot path.
        const size_t maxRectBytes = static_cast<size_t>(cfg.fullW) * cfg.fullH * 4;
        std::vector<uint8_t> rectDecompressScratch(maxRectBytes, 0);

        std::atomic<bool> running{true};

        // ---- Writer thread: claims latest reconstructed frame, writes BMP.
        // Only frames that actually changed get published (see the decode
        // loop below), so this thread -- and disk I/O -- naturally goes
        // idle whenever the screen is static. ----
        std::thread writer([&]() {
            while (running.load(std::memory_order_relaxed)) {
                int64_t fi;
                const uint8_t *bgra = tripleBuf.claimLatest(fi);
                if (!bgra) {
                    std::this_thread::sleep_for(std::chrono::milliseconds(1));
                    continue;
                }
                char name[64];
                std::snprintf(name, sizeof(name), "frame_%06lld.bmp", static_cast<long long>(fi));
                writeBmp(outDir / name, bgra, cfg.fullW, cfg.fullH);
                std::fprintf(stderr, "[receiver] wrote %s\n", name);
            }
        });

        // ---- Persistent canvas: the running reconstruction of the sender's
        // screen. A full-frame message overwrites it entirely; a delta
        // message overwrites only the single rectangle that was actually
        // sent, so an unchanged region simply keeps whatever pixels were
        // already there from a previous frame. ----
        std::vector<uint8_t> canvas(static_cast<size_t>(cfg.fullW) * cfg.fullH * 4, 0);
        const int strideBytes = cfg.fullW * 4;

        enum class Mode { None, Full, Delta };
        Mode mode = Mode::None;
        int64_t currentFrame = -1;
        std::vector<uint8_t> baseBuf, enhBuf;
        bool haveBase = false, haveEnh = false;

        auto publishCanvas = [&](int64_t fi) {
            std::memcpy(tripleBuf.writeSlot(), canvas.data(), canvas.size());
            tripleBuf.publish(fi);
        };

        while (true) {
            // recvMessage() internally loops recv() until the full header
            // and payload have arrived (see TcpReceiver::recvAll below) --
            // TCP makes no guarantee a single recv() call returns a whole
            // message, so every read here is already boundary-safe.
            if (!server.recvMessage(hdr, payload)) break; // sender disconnected
            if (hdr.type == wire::MSG_END) break;

            switch (hdr.type) {
                case wire::MSG_FRAME_FULL:
                    mode = Mode::Full;
                    currentFrame = hdr.frameIndex;
                    haveBase = haveEnh = false;
                    break;

                case wire::MSG_FRAME_DELTA: {
                    mode = Mode::Delta;
                    currentFrame = hdr.frameIndex;

                    if (payload.size() < wire::RECT_HEADER_SIZE) {
                        std::fprintf(stderr, "[receiver] frame %lld: malformed delta payload (too short)\n",
                                     static_cast<long long>(currentFrame));
                        break;
                    }
                    auto rect = wire::parseDeltaPayloadHeader(payload);

                    if (rect.rectW == 0 || rect.rectH == 0) {
                        // Screen unchanged since last frame: nothing to
                        // decompress, nothing new to write -- this is the
                        // whole point of delta mode (a static desktop or a
                        // mouse-only frame costs essentially zero bytes and
                        // zero receiver work).
                        std::fprintf(stderr, "[receiver] frame %lld unchanged (empty rect)\n",
                                     static_cast<long long>(currentFrame));
                        break;
                    }

                    // Bounds-check against the canvas before touching memory --
                    // a corrupt/malicious rect_x+rect_w exceeding cfg.fullW
                    // would otherwise write past the canvas buffer.
                    if (rect.rectX < 0 || rect.rectY < 0 ||
                        rect.rectX + rect.rectW > cfg.fullW || rect.rectY + rect.rectH > cfg.fullH) {
                        std::fprintf(stderr, "[receiver] frame %lld: rect (%d,%d %dx%d) out of canvas bounds, dropped\n",
                                     static_cast<long long>(currentFrame), rect.rectX, rect.rectY, rect.rectW, rect.rectH);
                        break;
                    }

                    const uint8_t *compressed = payload.data() + wire::RECT_HEADER_SIZE;
                    const size_t compressedSize = payload.size() - wire::RECT_HEADER_SIZE;
                    const size_t rawRectBytes = static_cast<size_t>(rect.rectW) * 4 * rect.rectH;

                    try {
                        lz4rect::DecompressRect(compressed, compressedSize,
                                                 rectDecompressScratch.data(), rawRectBytes);

                        // Paste: one memcpy per row (the canvas's stride
                        // and the rect's packed width differ in the general
                        // case, so a single whole-rect memcpy only works
                        // when rect.rectW == cfg.fullW; row-by-row is the
                        // correct general form and is still O(height) calls,
                        // not O(width*height)).
                        const int rectRowBytes = rect.rectW * 4;
                        for (int row = 0; row < rect.rectH; ++row) {
                            uint8_t *dstRow = canvas.data() + static_cast<size_t>(rect.rectY + row) * strideBytes
                                                             + static_cast<size_t>(rect.rectX) * 4;
                            const uint8_t *srcRow = rectDecompressScratch.data() + static_cast<size_t>(row) * rectRowBytes;
                            std::memcpy(dstRow, srcRow, rectRowBytes);
                        }
                        publishCanvas(currentFrame);
                    } catch (const std::exception &ex) {
                        std::fprintf(stderr, "[receiver] frame %lld rect decode failed: %s\n",
                                     static_cast<long long>(currentFrame), ex.what());
                    }
                    break;
                }

                case wire::MSG_BASE:
                    baseBuf = std::move(payload);
                    haveBase = true;
                    break;

                case wire::MSG_ENH:
                    enhBuf = std::move(payload);
                    haveEnh = true;
                    if (haveBase && haveEnh && mode == Mode::Full) {
                        try {
                            fullCodec.decodeFrame(baseBuf, enhBuf, canvas.data(), strideBytes);
                            publishCanvas(currentFrame);
                        } catch (const std::exception &ex) {
                            std::fprintf(stderr, "[receiver] frame %lld (full) failed to decode: %s\n",
                                         static_cast<long long>(currentFrame), ex.what());
                        }
                    }
                    break;

                default:
                    break;
            }
        }

        running.store(false, std::memory_order_relaxed);
        writer.join();
        std::fprintf(stderr, "[receiver] connection closed, exiting\n");
    } catch (const std::exception &ex) {
        std::fprintf(stderr, "[receiver] fatal: %s\n", ex.what());
        return 1;
    }
    return 0;
}
