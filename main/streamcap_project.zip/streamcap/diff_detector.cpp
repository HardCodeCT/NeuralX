#include "diff_detector.h"
#include "architecture.h"

#include <cstdio>
#include <cstdlib>
#include <mutex>

#if defined(_M_X64) || defined(__x86_64__) || defined(_M_IX86) || defined(__i386__)
    #define ARCH_X86 1
    #include <immintrin.h>
#elif defined(_M_ARM64) || defined(__aarch64__) || defined(_M_ARM) || defined(__arm__)
    #define ARCH_ARM 1
    #include <arm_neon.h>
#endif

namespace diffdet {

TileGrid makeGrid(int fullW, int fullH, int tileSize) {
    TileGrid g;
    g.fullW = fullW; g.fullH = fullH; g.tileSize = tileSize;
    g.tilesX = (fullW + tileSize - 1) / tileSize;
    g.tilesY = (fullH + tileSize - 1) / tileSize;
    g.dirty.assign(static_cast<size_t>(g.tilesX) * g.tilesY, 0);
    return g;
}

// ---- Row SAD: sum(|a[i]-b[i]|) over `count` bytes. Early-outs the moment
// the running sum exceeds `threshold`, since callers only care "changed or
// not", not the exact magnitude -- most dirty tiles differ enormously
// (a moved cursor is 100% different pixels), so this exits almost
// immediately for dirty tiles and only walks the full tile for clean ones.
// ---------------------------------------------------------------------------
static uint32_t rowSadScalar(const uint8_t *a, const uint8_t *b, int count, uint32_t budget) {
    uint32_t sum = 0;
    for (int i = 0; i < count; ++i) {
        sum += static_cast<uint32_t>(std::abs(static_cast<int>(a[i]) - static_cast<int>(b[i])));
        if (sum > budget) return sum;
    }
    return sum;
}

#if defined(ARCH_X86)
// _mm256_sad_epu8 gives four 16-bit partial sums (one per 8-byte lane group)
// packed into a 256-bit result; summing those 4 lanes gives the row's total
// SAD for 32 bytes in one instruction.
static uint32_t rowSadAVX2(const uint8_t *a, const uint8_t *b, int count, uint32_t budget) {
    int x = 0;
    uint32_t sum = 0;
    const int vecCount = count - (count % 32);
    for (; x < vecCount; x += 32) {
        __m256i av = _mm256_loadu_si256(reinterpret_cast<const __m256i *>(a + x));
        __m256i bv = _mm256_loadu_si256(reinterpret_cast<const __m256i *>(b + x));
        __m256i sad = _mm256_sad_epu8(av, bv); // four uint64-ish lanes, really 4x uint16 sums
        alignas(32) uint64_t lanes[4];
        _mm256_store_si256(reinterpret_cast<__m256i *>(lanes), sad);
        sum += static_cast<uint32_t>(lanes[0] + lanes[1] + lanes[2] + lanes[3]);
        if (sum > budget) return sum; // early-out: this tile is already dirty
    }
    for (; x < count; ++x)
        sum += static_cast<uint32_t>(std::abs(static_cast<int>(a[x]) - static_cast<int>(b[x])));
    return sum;
}
#endif

#if defined(ARCH_ARM)
static uint32_t rowSadNEON(const uint8_t *a, const uint8_t *b, int count, uint32_t budget) {
    int x = 0;
    uint32_t sum = 0;
    const int vecCount = count - (count % 16);
    for (; x < vecCount; x += 16) {
        uint8x16_t av = vld1q_u8(a + x);
        uint8x16_t bv = vld1q_u8(b + x);
        uint8x16_t diff = vabdq_u8(av, bv); // |a-b| per byte
        // Widen-and-add-across to a 32-bit horizontal sum.
        uint16x8_t sum16 = vpaddlq_u8(diff);
        uint32x4_t sum32 = vpaddlq_u16(sum16);
        uint64x2_t sum64 = vpaddlq_u32(sum32);
        sum += static_cast<uint32_t>(vgetq_lane_u64(sum64, 0) + vgetq_lane_u64(sum64, 1));
        if (sum > budget) return sum;
    }
    for (; x < count; ++x)
        sum += static_cast<uint32_t>(std::abs(static_cast<int>(a[x]) - static_cast<int>(b[x])));
    return sum;
}
#endif

using RowSadFn = uint32_t (*)(const uint8_t *, const uint8_t *, int, uint32_t);
static RowSadFn g_rowSadFn = rowSadScalar;
static std::once_flag g_initFlag;

void InitDiffDispatch() {
    std::call_once(g_initFlag, []() {
        SimdLevel level = DetectSimdLevel();
        switch (level) {
#if defined(ARCH_X86)
            case SimdLevel::AVX2: g_rowSadFn = rowSadAVX2; break;
#endif
#if defined(ARCH_ARM)
            case SimdLevel::NEON: g_rowSadFn = rowSadNEON; break;
#endif
            default: g_rowSadFn = rowSadScalar; break;
        }
        std::fprintf(stderr, "[diff] tile comparison dispatched to: %s\n", SimdLevelName(level));
    });
}

void DetectDirtyTiles(const uint8_t *prev, const uint8_t *curr, int strideBytes,
                       TileGrid &grid, uint32_t threshold) {
    InitDiffDispatch();

    const int bytesPerPixel = 4; // BGRA8
    for (int i = 0; i < grid.tileCount(); ++i) {
        int tx, ty, tw, th;
        grid.tileBounds(i, tx, ty, tw, th);
        const int rowBytes = tw * bytesPerPixel;

        uint32_t sum = 0;
        bool dirty = false;
        for (int row = 0; row < th; ++row) {
            const uint8_t *a = prev + static_cast<size_t>(ty + row) * strideBytes + tx * bytesPerPixel;
            const uint8_t *b = curr + static_cast<size_t>(ty + row) * strideBytes + tx * bytesPerPixel;
            // Budget remaining this tile so the early-out in rowSad* stays
            // meaningful across rows, not just within one row.
            uint32_t remainingBudget = (sum > threshold) ? 0 : (threshold - sum);
            sum += g_rowSadFn(a, b, rowBytes, remainingBudget);
            if (sum > threshold) { dirty = true; break; }
        }
        grid.dirty[i] = dirty ? 1 : 0;
    }
}

BoundingBox ComputeDirtyBoundingBox(const TileGrid &grid) {
    int minX = grid.fullW, minY = grid.fullH, maxX = -1, maxY = -1;

    for (int i = 0; i < grid.tileCount(); ++i) {
        if (!grid.dirty[i]) continue;
        int bx, by, bw, bh;
        grid.tileBounds(i, bx, by, bw, bh);
        minX = std::min(minX, bx);
        minY = std::min(minY, by);
        maxX = std::max(maxX, bx + bw);
        maxY = std::max(maxY, by + bh);
    }

    if (maxX < 0) return BoundingBox{}; // no dirty blocks at all -> empty box

    BoundingBox box;
    box.x = minX;
    box.y = minY;
    box.width = maxX - minX;
    box.height = maxY - minY;
    return box;
}

// ---- Non-overlapping box-average downscale + its exact inverse mapping.
// Both use the identical "partition by index*srcSize/dstSize" boundary
// rule, which is what guarantees every source pixel is averaged into
// exactly one destination pixel (no gaps, no overlap) and that mapping a
// bounding box back through the same boundaries recovers precisely the
// full-res region that could have produced it. ----
static void computeAxisPartition(int dstIndex, int srcSize, int dstSize, int &start, int &end) {
    start = static_cast<int>(static_cast<int64_t>(dstIndex) * srcSize / dstSize);
    end = static_cast<int>(static_cast<int64_t>(dstIndex + 1) * srcSize / dstSize);
    if (end <= start) end = start + 1; // guard degenerate case (dstSize > srcSize)
    if (end > srcSize) end = srcSize;
}

void DownscaleBoxAverage(const uint8_t *src, int srcW, int srcH, int srcStrideBytes,
                          uint8_t *dst, int dstW, int dstH, int dstStrideBytes) {
    for (int dy = 0; dy < dstH; ++dy) {
        int sy0, sy1;
        computeAxisPartition(dy, srcH, dstH, sy0, sy1);

        for (int dx = 0; dx < dstW; ++dx) {
            int sx0, sx1;
            computeAxisPartition(dx, srcW, dstW, sx0, sx1);

            uint32_t sumB = 0, sumG = 0, sumR = 0, sumA = 0;
            int count = 0;
            for (int sy = sy0; sy < sy1; ++sy) {
                const uint8_t *row = src + static_cast<size_t>(sy) * srcStrideBytes;
                for (int sx = sx0; sx < sx1; ++sx) {
                    const uint8_t *px = row + static_cast<size_t>(sx) * 4;
                    sumB += px[0]; sumG += px[1]; sumR += px[2]; sumA += px[3];
                    ++count;
                }
            }
            uint8_t *outPx = dst + static_cast<size_t>(dy) * dstStrideBytes + static_cast<size_t>(dx) * 4;
            outPx[0] = static_cast<uint8_t>(sumB / count);
            outPx[1] = static_cast<uint8_t>(sumG / count);
            outPx[2] = static_cast<uint8_t>(sumR / count);
            outPx[3] = static_cast<uint8_t>(sumA / count);
        }
    }
}

BoundingBox MapBoundingBoxToFullRes(const BoundingBox &dsBox, int dsW, int dsH,
                                     int fullW, int fullH) {
    if (dsBox.empty()) return BoundingBox{};

    int x0, discard1, x1, discard2;
    computeAxisPartition(dsBox.x, fullW, dsW, x0, discard1);
    computeAxisPartition(dsBox.x + dsBox.width - 1, fullW, dsW, discard2, x1);

    int y0, discard3, y1, discard4;
    computeAxisPartition(dsBox.y, fullH, dsH, y0, discard3);
    computeAxisPartition(dsBox.y + dsBox.height - 1, fullH, dsH, discard4, y1);

    BoundingBox box;
    box.x = x0;
    box.y = y0;
    box.width = x1 - x0;
    box.height = y1 - y0;
    return box;
}

} // namespace diffdet
