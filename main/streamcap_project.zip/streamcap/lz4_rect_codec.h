// ============================================================================
// lz4_rect_codec.h
//
// Thin wrapper around vendored LZ4 (lz4.h/lz4.c, BSD-2-Clause, from the
// official lz4/lz4 repo) for the one job this pipeline needs it for:
// compressing/decompressing a single, arbitrarily-sized BGRA rectangle per
// frame. This is a better fit here than FFV1/TileCodec because LZ4 has no
// fixed-shape codec context to (re)configure -- every call is independent
// and takes whatever size buffer you hand it, which matches a bounding box
// that's a different size every frame. The tradeoff is a lower compression
// ratio than FFV1, but at these buffer sizes (a text line's worth of
// pixels, typically a few KB to a few tens of KB) that's the right trade:
// the real bandwidth win already happened by only sending the changed
// rectangle instead of the whole frame, and LZ4 is fast enough (GB/s
// range) to stay well under the sub-millisecond budget.
//
// Zero-allocation: both functions write into a caller-owned, pre-sized
// buffer and return the number of bytes actually used. Size that buffer
// once at startup with Lz4Bound(maxRectBytes) (worst case = the whole
// frame, if a "delta" ever ends up covering it) and never resize it.
// ============================================================================
#pragma once

#include "lz4.h"

#include <cstdint>
#include <stdexcept>
#include <string>

namespace lz4rect {

// Worst-case compressed size for a raw buffer of `rawSize` bytes. Always
// slightly larger than rawSize (LZ4 guarantees compressed output never
// exceeds this even for incompressible input) -- size scratch buffers with
// this, once, at startup.
inline size_t Lz4Bound(size_t rawSize) {
    return static_cast<size_t>(LZ4_compressBound(static_cast<int>(rawSize)));
}

// Compresses `rawSize` bytes from `raw` into `outCompressed` (capacity
// `outCapacity`, must be >= Lz4Bound(rawSize)). Returns the number of
// compressed bytes written -- always less than outCapacity, but varies
// frame to frame with how compressible the rectangle's pixels are, so the
// caller must track this return value as the actual payload length to
// send, not the buffer's full capacity.
inline size_t CompressRect(const uint8_t *raw, size_t rawSize,
                            uint8_t *outCompressed, size_t outCapacity) {
    int written = LZ4_compress_default(
        reinterpret_cast<const char *>(raw), reinterpret_cast<char *>(outCompressed),
        static_cast<int>(rawSize), static_cast<int>(outCapacity));
    if (written <= 0)
        throw std::runtime_error("LZ4_compress_default failed (buffer too small or input too large)");
    return static_cast<size_t>(written);
}

// Decompresses exactly `expectedRawSize` bytes from `compressed`
// (`compressedSize` bytes) into `outRaw` (must have capacity
// >= expectedRawSize). Throws if the compressed stream is malformed or
// doesn't decompress to exactly the expected size -- both are treated as
// hard errors here since a size mismatch means the sender and receiver
// have desynced on rectangle dimensions, which should never happen given
// the rect_w/rect_h header always precedes the compressed bytes on the wire.
inline void DecompressRect(const uint8_t *compressed, size_t compressedSize,
                            uint8_t *outRaw, size_t expectedRawSize) {
    int written = LZ4_decompress_safe(
        reinterpret_cast<const char *>(compressed), reinterpret_cast<char *>(outRaw),
        static_cast<int>(compressedSize), static_cast<int>(expectedRawSize));
    if (written < 0 || static_cast<size_t>(written) != expectedRawSize)
        throw std::runtime_error("LZ4_decompress_safe failed or size mismatch (expected " +
                                  std::to_string(expectedRawSize) + ", got " + std::to_string(written) + ")");
}

} // namespace lz4rect
