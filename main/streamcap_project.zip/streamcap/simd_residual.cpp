// ============================================================================
// simd_residual.cpp
//
// Three implementations of the same two operations (compute residual / add
// residual back), each processing progressively more bytes per instruction:
//   - Scalar : 1 byte/iteration, always correct, always compiles, baseline.
//   - AVX2   : 32 bytes/iteration, x86_64 only, used if architecture.cpp's
//              DetectSimdLevel() reports the CPU+OS actually support it.
//   - NEON   : 16 bytes/iteration, ARM only, used if DetectSimdLevel()
//              reports NEON available.
//
// All three are byte-exact with each other -- the vector paths use widened
// 16-bit intermediate math specifically so the +128 bias and clamp can't
// overflow, matching the scalar `int` arithmetic exactly. That equivalence
// is what makes it safe to switch between them purely based on which CPU
// happens to be running the process.
// ============================================================================
#include "simd_residual.h"
#include "architecture.h"

#include <algorithm>
#include <cstdio>
#include <mutex>

#if defined(_M_X64) || defined(__x86_64__) || defined(_M_IX86) || defined(__i386__)
    #define ARCH_X86 1
    #include <immintrin.h>
#elif defined(_M_ARM64) || defined(__aarch64__) || defined(_M_ARM) || defined(__arm__)
    #define ARCH_ARM 1
    #include <arm_neon.h>
#endif

// ============================================================================
// Scalar (portable fallback; identical math to the original hand-written
// loops in codec_common.h, just factored out to one place per plane).
// ============================================================================
static void computeResidualScalar(const uint8_t *orig, int origStride,
                                   const uint8_t *up, int upStride,
                                   uint8_t *out, int outStride,
                                   int width, int height) {
    for (int y = 0; y < height; ++y) {
        const uint8_t *o = orig + y * origStride;
        const uint8_t *u = up   + y * upStride;
        uint8_t *r        = out  + y * outStride;
        for (int x = 0; x < width; ++x) {
            int diff = static_cast<int>(o[x]) - static_cast<int>(u[x]) + 128;
            r[x] = static_cast<uint8_t>(std::clamp(diff, 0, 255));
        }
    }
}
static void addResidualScalar(const uint8_t *up, int upStride,
                               const uint8_t *resid, int residStride,
                               uint8_t *out, int outStride,
                               int width, int height) {
    for (int y = 0; y < height; ++y) {
        const uint8_t *u = up    + y * upStride;
        const uint8_t *r = resid + y * residStride;
        uint8_t *o        = out   + y * outStride;
        for (int x = 0; x < width; ++x) {
            int val = static_cast<int>(u[x]) + (static_cast<int>(r[x]) - 128);
            o[x] = static_cast<uint8_t>(std::clamp(val, 0, 255));
        }
    }
}

// ============================================================================
// AVX2 (x86_64 only). Processes 32 pixels/instruction.
//
// Trick: zero-extend each 32-byte lane to two 16-bit halves with
// unpacklo/unpackhi (element order stays intra-lane-consistent), do the
// add/subtract + bias in 16-bit so nothing overflows, then _mm256_packus_epi16
// both saturates back to [0,255] *and* undoes the unpack ordering in one
// instruction -- no permute needed, no branches anywhere.
// ============================================================================
#if defined(ARCH_X86)

static inline __m256i clampAddBias32(__m256i a, __m256i b, int bias, bool subtract) {
    const __m256i zero = _mm256_setzero_si256();
    const __m256i biasVec = _mm256_set1_epi16(static_cast<short>(bias));

    __m256i a_lo = _mm256_unpacklo_epi8(a, zero);
    __m256i a_hi = _mm256_unpackhi_epi8(a, zero);
    __m256i b_lo = _mm256_unpacklo_epi8(b, zero);
    __m256i b_hi = _mm256_unpackhi_epi8(b, zero);

    __m256i r_lo = subtract ? _mm256_sub_epi16(a_lo, b_lo) : _mm256_add_epi16(a_lo, b_lo);
    __m256i r_hi = subtract ? _mm256_sub_epi16(a_hi, b_hi) : _mm256_add_epi16(a_hi, b_hi);
    r_lo = _mm256_add_epi16(r_lo, biasVec);
    r_hi = _mm256_add_epi16(r_hi, biasVec);

    return _mm256_packus_epi16(r_lo, r_hi); // saturates to [0,255], restores byte order
}

static void computeResidualAVX2(const uint8_t *orig, int origStride,
                                 const uint8_t *up, int upStride,
                                 uint8_t *out, int outStride,
                                 int width, int height) {
    const int vecWidth = width - (width % 32);
    for (int y = 0; y < height; ++y) {
        const uint8_t *o = orig + y * origStride;
        const uint8_t *u = up   + y * upStride;
        uint8_t *r        = out  + y * outStride;
        int x = 0;
        for (; x < vecWidth; x += 32) {
            __m256i ov = _mm256_loadu_si256(reinterpret_cast<const __m256i *>(o + x));
            __m256i uv = _mm256_loadu_si256(reinterpret_cast<const __m256i *>(u + x));
            __m256i res = clampAddBias32(ov, uv, 128, /*subtract*/ true);
            _mm256_storeu_si256(reinterpret_cast<__m256i *>(r + x), res);
        }
        for (; x < width; ++x) { // remainder tail, scalar
            int diff = static_cast<int>(o[x]) - static_cast<int>(u[x]) + 128;
            r[x] = static_cast<uint8_t>(std::clamp(diff, 0, 255));
        }
    }
}
static void addResidualAVX2(const uint8_t *up, int upStride,
                             const uint8_t *resid, int residStride,
                             uint8_t *out, int outStride,
                             int width, int height) {
    const int vecWidth = width - (width % 32);
    for (int y = 0; y < height; ++y) {
        const uint8_t *u = up    + y * upStride;
        const uint8_t *r = resid + y * residStride;
        uint8_t *o        = out   + y * outStride;
        int x = 0;
        for (; x < vecWidth; x += 32) {
            __m256i uv = _mm256_loadu_si256(reinterpret_cast<const __m256i *>(u + x));
            __m256i rv = _mm256_loadu_si256(reinterpret_cast<const __m256i *>(r + x));
            __m256i res = clampAddBias32(uv, rv, -128, /*subtract*/ false);
            _mm256_storeu_si256(reinterpret_cast<__m256i *>(o + x), res);
        }
        for (; x < width; ++x) {
            int val = static_cast<int>(u[x]) + (static_cast<int>(r[x]) - 128);
            o[x] = static_cast<uint8_t>(std::clamp(val, 0, 255));
        }
    }
}

#endif // ARCH_X86

// ============================================================================
// NEON (ARM only). Processes 16 pixels/instruction. Same widen -> 16-bit
// math -> saturating-narrow shape as AVX2, but NEON's vqmovun_s16 does the
// saturate-to-[0,255] narrow directly with no lane-ordering gotchas at all.
// ============================================================================
#if defined(ARCH_ARM)

static inline uint8x16_t clampAddBias16(uint8x16_t a, uint8x16_t b, int16_t bias, bool subtract) {
    int16x8_t a_lo = vreinterpretq_s16_u16(vmovl_u8(vget_low_u8(a)));
    int16x8_t a_hi = vreinterpretq_s16_u16(vmovl_u8(vget_high_u8(a)));
    int16x8_t b_lo = vreinterpretq_s16_u16(vmovl_u8(vget_low_u8(b)));
    int16x8_t b_hi = vreinterpretq_s16_u16(vmovl_u8(vget_high_u8(b)));

    int16x8_t r_lo = subtract ? vsubq_s16(a_lo, b_lo) : vaddq_s16(a_lo, b_lo);
    int16x8_t r_hi = subtract ? vsubq_s16(a_hi, b_hi) : vaddq_s16(a_hi, b_hi);
    int16x8_t biasVec = vdupq_n_s16(bias);
    r_lo = vaddq_s16(r_lo, biasVec);
    r_hi = vaddq_s16(r_hi, biasVec);

    uint8x8_t out_lo = vqmovun_s16(r_lo); // saturating narrow signed16 -> unsigned8
    uint8x8_t out_hi = vqmovun_s16(r_hi);
    return vcombine_u8(out_lo, out_hi);
}

static void computeResidualNEON(const uint8_t *orig, int origStride,
                                 const uint8_t *up, int upStride,
                                 uint8_t *out, int outStride,
                                 int width, int height) {
    const int vecWidth = width - (width % 16);
    for (int y = 0; y < height; ++y) {
        const uint8_t *o = orig + y * origStride;
        const uint8_t *u = up   + y * upStride;
        uint8_t *r        = out  + y * outStride;
        int x = 0;
        for (; x < vecWidth; x += 16) {
            uint8x16_t ov = vld1q_u8(o + x);
            uint8x16_t uv = vld1q_u8(u + x);
            vst1q_u8(r + x, clampAddBias16(ov, uv, 128, /*subtract*/ true));
        }
        for (; x < width; ++x) {
            int diff = static_cast<int>(o[x]) - static_cast<int>(u[x]) + 128;
            r[x] = static_cast<uint8_t>(std::clamp(diff, 0, 255));
        }
    }
}
static void addResidualNEON(const uint8_t *up, int upStride,
                             const uint8_t *resid, int residStride,
                             uint8_t *out, int outStride,
                             int width, int height) {
    const int vecWidth = width - (width % 16);
    for (int y = 0; y < height; ++y) {
        const uint8_t *u = up    + y * upStride;
        const uint8_t *r = resid + y * residStride;
        uint8_t *o        = out   + y * outStride;
        int x = 0;
        for (; x < vecWidth; x += 16) {
            uint8x16_t uv = vld1q_u8(u + x);
            uint8x16_t rv = vld1q_u8(r + x);
            vst1q_u8(o + x, clampAddBias16(uv, rv, -128, /*subtract*/ false));
        }
        for (; x < width; ++x) {
            int val = static_cast<int>(u[x]) + (static_cast<int>(r[x]) - 128);
            o[x] = static_cast<uint8_t>(std::clamp(val, 0, 255));
        }
    }
}

#endif // ARCH_ARM

// ============================================================================
// Dispatch: detect once, cache the choice, hand every subsequent call
// straight to a function pointer (no branching on every call after warmup).
// ============================================================================
using ResidualFn = void (*)(const uint8_t *, int, const uint8_t *, int, uint8_t *, int, int, int);

static ResidualFn g_computeResidualFn = computeResidualScalar;
static ResidualFn g_addResidualFn     = addResidualScalar;
static std::once_flag g_initFlag;

void InitSimdResidualDispatch() {
    std::call_once(g_initFlag, []() {
        SimdLevel level = DetectSimdLevel();
        switch (level) {
#if defined(ARCH_X86)
            case SimdLevel::AVX2:
                g_computeResidualFn = computeResidualAVX2;
                g_addResidualFn     = addResidualAVX2;
                break;
#endif
#if defined(ARCH_ARM)
            case SimdLevel::NEON:
                g_computeResidualFn = computeResidualNEON;
                g_addResidualFn     = addResidualNEON;
                break;
#endif
            default:
                g_computeResidualFn = computeResidualScalar;
                g_addResidualFn     = addResidualScalar;
                break;
        }
        std::fprintf(stderr, "[simd] residual math dispatched to: %s\n", SimdLevelName(level));
    });
}

void ComputeResidualPlane(const uint8_t *orig, int origStride,
                           const uint8_t *upscaled, int upscaledStride,
                           uint8_t *out, int outStride,
                           int width, int height) {
    g_computeResidualFn(orig, origStride, upscaled, upscaledStride, out, outStride, width, height);
}
void AddResidualPlane(const uint8_t *upscaled, int upscaledStride,
                       const uint8_t *residual, int residualStride,
                       uint8_t *out, int outStride,
                       int width, int height) {
    g_addResidualFn(upscaled, upscaledStride, residual, residualStride, out, outStride, width, height);
}
