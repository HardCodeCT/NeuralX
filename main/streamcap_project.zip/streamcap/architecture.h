// ============================================================================
// architecture.h / architecture.cpp
//
// Pure detection, no vector code lives here. Answers exactly one question:
// "what's the best SIMD tier this CPU (and OS) actually supports right now?"
// Everything downstream (simd_residual.cpp) uses the answer to pick which
// implementation to call -- this file never does image work itself.
// ============================================================================
#pragma once

enum class SimdLevel {
    Scalar, // no usable vector ISA found; portable byte-at-a-time fallback
    AVX2,   // x86_64: 256-bit integer vector ops, confirmed CPU+OS support
    NEON,   // ARM: 128-bit vector ops (mandatory on AArch64, optional on ARMv7)
};

// Runs the CPUID/OS-support checks (x86) or the mandatory/optional NEON
// check (ARM) once and returns the highest tier this process can safely use.
// Cheap to call repeatedly, but callers should still cache the result --
// see simd_residual.cpp's InitSimdResidualDispatch() for the "load once"
// pattern.
SimdLevel DetectSimdLevel();

const char *SimdLevelName(SimdLevel level);
