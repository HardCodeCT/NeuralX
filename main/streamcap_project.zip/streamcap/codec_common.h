// ============================================================================
// codec_common.h
//
// Per-FRAME (not per-file) scalable image codec, adapted from the video
// scalable_codec.cpp pipeline. Because this is live screen transmission,
// there is no container/mux step and no inter-frame prediction: every frame
// is encoded completely independently, in isolation, exactly like the
// residual-coding step of the original design but applied one still image
// at a time.
//
//   ENCODE (per frame):
//     full-res BGRA frame --[sws, Lanczos down]--> low-res frame
//                                                     |
//                                                     +--[MJPEG encode]--> baseBytes  (small, lossy, sendable alone)
//                                                     |
//                                                     +--[MJPEG decode]--> reconstructed low-res
//                                                           (drift-free: exactly what the receiver will decode)
//                                                     |
//     full-res original  -  upscale(reconstructed low-res)  =  residual (+128, clamped)
//                                                     |
//                                                     +--[FFV1 lossless encode]--> enhBytes
//
//   DECODE (per frame):
//     baseBytes --[MJPEG decode]--> low-res --[sws, Lanczos up]--> upscaled
//     enhBytes  --[FFV1 decode]-->  residual
//     reconstructed = clamp(upscaled + residual - 128)
//
// Why MJPEG instead of H.264 for the base layer: H.264's compression
// advantage comes from inter-frame prediction across a GOP, which requires
// a continuous stream. Here every frame stands alone (live, frame-by-frame,
// no video file), so an intra-only image codec is the correct tool and
// avoids carrying B/P-frame reordering and encoder lookahead latency.
// FFV1 was already intra-only in the original design, so it is unchanged.
//
// This header is intentionally allocation-light in the per-frame hot path:
// call `FrameCodec::init()` once, then `encodeFrame()` / `decodeFrame()`
// repeatedly. Internal AVFrame/AVPacket scratch objects are owned by the
// FrameCodec and reused; only the caller-supplied output byte vectors grow
// (and quickly stabilize to a steady-state capacity after the first frame).
// ============================================================================
#pragma once

extern "C" {
#include <libavcodec/avcodec.h>
#include <libswscale/swscale.h>
#include <libavutil/opt.h>
#include <libavutil/imgutils.h>
}

#include <cstdint>
#include <cstring>
#include <stdexcept>
#include <string>
#include <vector>
#include <memory>
#include <algorithm>

#include "simd_residual.h"

namespace scalcodec {

inline std::string avErr(int rc) {
    char buf[AV_ERROR_MAX_STRING_SIZE] = {0};
    av_strerror(rc, buf, sizeof(buf));
    return std::string(buf);
}
struct CodecError : std::runtime_error {
    explicit CodecError(const std::string &m) : std::runtime_error(m) {}
};
#define SC_CHECK(expr, what)                                                  \
    do {                                                                      \
        int _rc = (expr);                                                    \
        if (_rc < 0) throw scalcodec::CodecError(std::string(what) + ": " + scalcodec::avErr(_rc)); \
    } while (0)

struct FrameDeleter  { void operator()(AVFrame *f)  const { if (f) av_frame_free(&f); } };
struct PacketDeleter { void operator()(AVPacket *p) const { if (p) av_packet_free(&p); } };
struct CtxDeleter    { void operator()(AVCodecContext *c) const { if (c) avcodec_free_context(&c); } };
struct SwsDeleter    { void operator()(SwsContext *s) const { if (s) sws_freeContext(s); } };
using FramePtr  = std::unique_ptr<AVFrame, FrameDeleter>;
using PacketPtr = std::unique_ptr<AVPacket, PacketDeleter>;
using CtxPtr    = std::unique_ptr<AVCodecContext, CtxDeleter>;
using SwsPtr    = std::unique_ptr<SwsContext, SwsDeleter>;

inline FramePtr allocFrame() {
    AVFrame *f = av_frame_alloc();
    if (!f) throw CodecError("av_frame_alloc failed");
    return FramePtr(f);
}
inline PacketPtr allocPacket() {
    AVPacket *p = av_packet_alloc();
    if (!p) throw CodecError("av_packet_alloc failed");
    return PacketPtr(p);
}

// Round down/up to even dims (4:2:0 chroma requirement) preserving aspect.
inline void computeLowRes(int srcW, int srcH, int targetHeight, int &dstW, int &dstH) {
    dstH = targetHeight;
    dstW = static_cast<int>(std::lround((double)srcW * targetHeight / srcH));
    if (dstH % 2) dstH += 1;
    if (dstW % 2) dstW += 1;
    dstW = std::max(dstW, 2);
    dstH = std::max(dstH, 2);
}

// ----------------------------------------------------------------------------
// FrameCodec: owns everything needed to turn one BGRA full-res image into a
// (baseBytes, enhBytes) pair, or the reverse. One instance is reused across
// the entire live session -- construct once, call many times.
// ----------------------------------------------------------------------------
class FrameCodec {
public:
    // side: build only what that side needs (sender only needs encoders +
    // the loop-back base decoder for drift-free residuals; receiver only
    // needs decoders). Both sides need the scalers.
    enum class Side { Sender, Receiver };

    void init(Side side, int fullW, int fullH, int targetLowHeight) {
        // Detect once (cached internally, safe to call from every instance)
        // and point the residual math at AVX2/NEON/scalar accordingly.
        InitSimdResidualDispatch();

        side_ = side;
        fullW_ = fullW; fullH_ = fullH;
        computeLowRes(fullW, fullH, targetLowHeight, lowW_, lowH_);

        downScaler_ = makeScaler(fullW_, fullH_, AV_PIX_FMT_BGRA, lowW_, lowH_, AV_PIX_FMT_YUV420P);
        upScaler_   = makeScaler(lowW_, lowH_, AV_PIX_FMT_YUV420P, fullW_, fullH_, AV_PIX_FMT_YUV420P);
        // bgraToYuvFull_: only needed on the sender, to build the full-res
        // YUV420P "original" frame that the residual is computed against.
        if (side == Side::Sender)
            bgraToYuvFull_ = makeScaler(fullW_, fullH_, AV_PIX_FMT_BGRA, fullW_, fullH_, AV_PIX_FMT_YUV420P);
        else
            yuvFullToBgra_ = makeScaler(fullW_, fullH_, AV_PIX_FMT_YUV420P, fullW_, fullH_, AV_PIX_FMT_BGRA);

        if (side == Side::Sender) {
            openEncoder(baseEnc_, AV_CODEC_ID_MJPEG, lowW_, lowH_, /*qscale*/ 3);
            openEncoder(enhEnc_,  AV_CODEC_ID_FFV1,  fullW_, fullH_, 0);
            openDecoder(baseDecLoopback_, AV_CODEC_ID_MJPEG, lowW_, lowH_);
        } else {
            openDecoder(baseDec_, AV_CODEC_ID_MJPEG, lowW_, lowH_);
            openDecoder(enhDec_,  AV_CODEC_ID_FFV1,  fullW_, fullH_);
        }

        // Pre-allocate every scratch frame used in the hot path so encode/
        // decode calls never hit av_frame_get_buffer beyond the first use.
        scratchLow_      = makeYuvFrame(lowW_, lowH_);
        scratchUpscaled_ = makeYuvFrame(fullW_, fullH_);
        scratchOriginal_ = makeYuvFrame(fullW_, fullH_);
        scratchResidual_ = makeYuvFrame(fullW_, fullH_);
        scratchRecon_    = makeYuvFrame(fullW_, fullH_);
    }

    // ---- Sender side ------------------------------------------------------
    // bgra: tightly packed BGRA8, fullW*fullH*4 bytes, top-down.
    void encodeFrame(const uint8_t *bgra, int strideBytes, int64_t frameIndex,
                      std::vector<uint8_t> &baseOut, std::vector<uint8_t> &enhOut) {
        const uint8_t *srcPlanes[1] = { bgra };
        int srcStride[1] = { strideBytes };

        // Full-res original -> YUV420P (kept for residual subtraction).
        sws_scale(bgraToYuvFull_.get(), srcPlanes, srcStride, 0, fullH_,
                  scratchOriginal_->data, scratchOriginal_->linesize);

        // Downscale (Lanczos) -> low-res YUV420P.
        sws_scale(downScaler_.get(), srcPlanes, srcStride, 0, fullH_,
                  scratchLow_->data, scratchLow_->linesize);
        scratchLow_->pts = frameIndex;

        // Encode low-res with MJPEG -> baseOut.
        encodeOne(baseEnc_.get(), scratchLow_.get(), baseOut);

        // Loop back: decode the exact bytes we just produced, so the
        // residual is computed against what the receiver will actually see
        // (drift-free), not the pre-encode ideal.
        FramePtr reconLow = decodeOneFromBytes(baseDecLoopback_.get(), baseOut);

        // Upscale reconstructed low-res -> full res.
        sws_scale(upScaler_.get(), reconLow->data, reconLow->linesize, 0, lowH_,
                  scratchUpscaled_->data, scratchUpscaled_->linesize);

        // residual = original - upscaled + 128, clamped to [0,255].
        computeResidual(scratchOriginal_.get(), scratchUpscaled_.get(), scratchResidual_.get());
        scratchResidual_->pts = frameIndex;

        // Encode residual losslessly with FFV1 -> enhOut.
        encodeOne(enhEnc_.get(), scratchResidual_.get(), enhOut);
    }

    // ---- Receiver side ------------------------------------------------------
    // Writes the reconstructed full-res image as tightly packed BGRA8 into
    // `outBgra` (caller-owned, pre-sized to fullW*fullH*4; no allocation here).
    void decodeFrame(const std::vector<uint8_t> &baseBytes, const std::vector<uint8_t> &enhBytes,
                      uint8_t *outBgra, int outStrideBytes) {
        FramePtr low = decodeOneFromBytes(baseDec_.get(), baseBytes);
        sws_scale(upScaler_.get(), low->data, low->linesize, 0, lowH_,
                  scratchUpscaled_->data, scratchUpscaled_->linesize);

        FramePtr residual = decodeOneFromBytes(enhDec_.get(), enhBytes);

        // reconstructed = upscaled + (residual - 128), clamped.
        addResidual(scratchUpscaled_.get(), residual.get(), scratchRecon_.get());

        uint8_t *dstPlanes[1] = { outBgra };
        int dstStride[1] = { outStrideBytes };
        sws_scale(yuvFullToBgra_.get(), scratchRecon_->data, scratchRecon_->linesize, 0, fullH_,
                  dstPlanes, dstStride);
    }

    int fullWidth()  const { return fullW_; }
    int fullHeight() const { return fullH_; }
    int lowWidth()   const { return lowW_; }
    int lowHeight()  const { return lowH_; }

private:
    Side side_;
    int fullW_ = 0, fullH_ = 0, lowW_ = 0, lowH_ = 0;

    SwsPtr downScaler_, upScaler_, bgraToYuvFull_, yuvFullToBgra_;
    CtxPtr baseEnc_, enhEnc_, baseDec_, enhDec_, baseDecLoopback_;

    FramePtr scratchLow_, scratchUpscaled_, scratchOriginal_, scratchResidual_, scratchRecon_;

    static SwsPtr makeScaler(int sw, int sh, AVPixelFormat sf, int dw, int dh, AVPixelFormat df) {
        SwsContext *s = sws_getContext(sw, sh, sf, dw, dh, df, SWS_LANCZOS, nullptr, nullptr, nullptr);
        if (!s) throw CodecError("sws_getContext failed");
        return SwsPtr(s);
    }

    static FramePtr makeYuvFrame(int w, int h) {
        FramePtr f = allocFrame();
        f->format = AV_PIX_FMT_YUV420P;
        f->width = w; f->height = h;
        SC_CHECK(av_frame_get_buffer(f.get(), 32), "av_frame_get_buffer");
        return f;
    }

    static void openEncoder(CtxPtr &ctx, AVCodecID id, int w, int h, int mjpegQscale) {
        const AVCodec *codec = avcodec_find_encoder(id);
        if (!codec) throw CodecError(std::string("encoder not found: ") + avcodec_get_name(id));
        ctx.reset(avcodec_alloc_context3(codec));
        ctx->width = w; ctx->height = h;
        ctx->pix_fmt = AV_PIX_FMT_YUV420P;
        ctx->time_base = AVRational{1, 1000}; // arbitrary; frames are independent stills
        ctx->framerate = AVRational{24, 1};
        if (id == AV_CODEC_ID_MJPEG) {
            ctx->flags |= AV_CODEC_FLAG_QSCALE;
            ctx->global_quality = FF_QP2LAMBDA * mjpegQscale; // lower = higher quality
        }
        SC_CHECK(avcodec_open2(ctx.get(), codec, nullptr), "avcodec_open2 (encoder)");
    }

    static void openDecoder(CtxPtr &ctx, AVCodecID id, int w, int h) {
        const AVCodec *codec = avcodec_find_decoder(id);
        if (!codec) throw CodecError(std::string("decoder not found: ") + avcodec_get_name(id));
        ctx.reset(avcodec_alloc_context3(codec));
        ctx->width = w; ctx->height = h;
        ctx->pix_fmt = AV_PIX_FMT_YUV420P;
        SC_CHECK(avcodec_open2(ctx.get(), codec, nullptr), "avcodec_open2 (decoder)");
    }

    // MJPEG/FFV1 are both intra-only: one send_frame reliably yields exactly
    // one packet via receive_packet without needing a flush, but we still
    // drain the loop defensively in case an implementation buffers once.
    static void encodeOne(AVCodecContext *enc, AVFrame *frame, std::vector<uint8_t> &out) {
        out.clear();
        SC_CHECK(avcodec_send_frame(enc, frame), "avcodec_send_frame");
        PacketPtr pkt = allocPacket();
        while (true) {
            int rc = avcodec_receive_packet(enc, pkt.get());
            if (rc == AVERROR(EAGAIN) || rc == AVERROR_EOF) break;
            SC_CHECK(rc, "avcodec_receive_packet");
            size_t off = out.size();
            out.resize(off + pkt->size);
            std::memcpy(out.data() + off, pkt->data, pkt->size);
            av_packet_unref(pkt.get());
        }
    }

    static FramePtr decodeOneFromBytes(AVCodecContext *dec, const std::vector<uint8_t> &bytes) {
        PacketPtr pkt = allocPacket();
        SC_CHECK(av_new_packet(pkt.get(), static_cast<int>(bytes.size())), "av_new_packet");
        std::memcpy(pkt->data, bytes.data(), bytes.size());
        SC_CHECK(avcodec_send_packet(dec, pkt.get()), "avcodec_send_packet");
        FramePtr f = allocFrame();
        int rc = avcodec_receive_frame(dec, f.get());
        SC_CHECK(rc, "avcodec_receive_frame");
        return f;
    }

    // Per-plane loops replaced with calls into simd_residual.{h,cpp}: same
    // math, dispatched at runtime to AVX2 (x86_64), NEON (ARM), or the
    // scalar fallback, chosen once by InitSimdResidualDispatch() in init().
    static void computeResidual(const AVFrame *orig, const AVFrame *upscaled, AVFrame *out) {
        const int w = orig->width, h = orig->height;
        const int planeW[3] = { w, w / 2, w / 2 };
        const int planeH[3] = { h, h / 2, h / 2 };
        for (int p = 0; p < 3; ++p) {
            ComputeResidualPlane(orig->data[p], orig->linesize[p],
                                  upscaled->data[p], upscaled->linesize[p],
                                  out->data[p], out->linesize[p],
                                  planeW[p], planeH[p]);
        }
    }

    static void addResidual(const AVFrame *upscaled, const AVFrame *residual, AVFrame *out) {
        const int w = upscaled->width, h = upscaled->height;
        const int planeW[3] = { w, w / 2, w / 2 };
        const int planeH[3] = { h, h / 2, h / 2 };
        for (int p = 0; p < 3; ++p) {
            AddResidualPlane(upscaled->data[p], upscaled->linesize[p],
                              residual->data[p], residual->linesize[p],
                              out->data[p], out->linesize[p],
                              planeW[p], planeH[p]);
        }
    }
};

// ----------------------------------------------------------------------------
// TileCodec: losslessly encodes/decodes small, fixed-size BGRA tiles.
//
// NOT USED by the current sender/receiver pipeline -- the delta-frame path
// now sends one bounding-box rectangle (see diff_detector.h's
// ComputeDirtyBoundingBox and lz4_rect_codec.h) per frame instead of many
// per-block tiles, since that collapses e.g. a whole line of typed text
// into a single message instead of one per changed block. Kept here as a
// reusable building block in case a future design wants fixed-size,
// per-region lossless encoding again (e.g. a multi-rectangle scheme).
//
// Deliberately simpler than FrameCodec: no downscale/upscale/residual
// split, no YUV conversion (so no chroma subsampling loss) -- just direct
// lossless FFV1 on raw BGRA bytes.
// ----------------------------------------------------------------------------
class TileCodec {
public:
    void init(int tileW, int tileH) {
        tileW_ = tileW; tileH_ = tileH;
        openEncoder(enc_, tileW, tileH);
        openDecoder(dec_, tileW, tileH);
        scratch_ = allocFrame();
        scratch_->format = AV_PIX_FMT_BGRA;
        scratch_->width = tileW; scratch_->height = tileH;
        SC_CHECK(av_frame_get_buffer(scratch_.get(), 32), "av_frame_get_buffer (tile)");
    }

    // `bgra` need not be tightly packed to tileW*4 -- pass the real capture
    // stride so partial (edge) tiles can be read directly out of the full
    // frame buffer without an extra copy. `actualW`/`actualH` are the real
    // pixel dimensions of this tile (< tileW_/tileH_ for edge tiles, where
    // the frame doesn't divide evenly by the tile grid); the padding area
    // is filled by edge-replication so the fixed-size FFV1 context can
    // still be reused for every tile regardless of position.
    void encodeTile(const uint8_t *bgra, int strideBytes, int actualW, int actualH,
                     std::vector<uint8_t> &out) {
        for (int y = 0; y < tileH_; ++y) {
            int srcY = std::min(y, actualH - 1);
            const uint8_t *srcRow = bgra + static_cast<size_t>(srcY) * strideBytes;
            uint8_t *dstRow = scratch_->data[0] + y * scratch_->linesize[0];
            std::memcpy(dstRow, srcRow, static_cast<size_t>(actualW) * 4);
            for (int x = actualW; x < tileW_; ++x) // replicate last column into padding
                std::memcpy(dstRow + static_cast<size_t>(x) * 4, srcRow + static_cast<size_t>(actualW - 1) * 4, 4);
        }
        out.clear();
        SC_CHECK(avcodec_send_frame(enc_.get(), scratch_.get()), "avcodec_send_frame (tile enc)");
        PacketPtr pkt = allocPacket();
        while (true) {
            int rc = avcodec_receive_packet(enc_.get(), pkt.get());
            if (rc == AVERROR(EAGAIN) || rc == AVERROR_EOF) break;
            SC_CHECK(rc, "avcodec_receive_packet (tile enc)");
            size_t off = out.size();
            out.resize(off + pkt->size);
            std::memcpy(out.data() + off, pkt->data, pkt->size);
            av_packet_unref(pkt.get());
        }
    }

    // Writes into `outBgra` at `strideBytes`, cropped back down to
    // actualW/actualH (discarding the encoder's edge-replication padding),
    // so the receiver can decode straight into the right spot of its
    // full-frame canvas.
    void decodeTile(const std::vector<uint8_t> &bytes, uint8_t *outBgra, int strideBytes,
                     int actualW, int actualH) {
        PacketPtr pkt = allocPacket();
        SC_CHECK(av_new_packet(pkt.get(), static_cast<int>(bytes.size())), "av_new_packet (tile dec)");
        std::memcpy(pkt->data, bytes.data(), bytes.size());
        SC_CHECK(avcodec_send_packet(dec_.get(), pkt.get()), "avcodec_send_packet (tile dec)");
        FramePtr f = allocFrame();
        SC_CHECK(avcodec_receive_frame(dec_.get(), f.get()), "avcodec_receive_frame (tile dec)");
        for (int y = 0; y < actualH; ++y)
            std::memcpy(outBgra + static_cast<size_t>(y) * strideBytes, f->data[0] + y * f->linesize[0],
                        static_cast<size_t>(actualW) * 4);
    }

private:
    int tileW_ = 0, tileH_ = 0;
    CtxPtr enc_, dec_;
    FramePtr scratch_;

    static void openEncoder(CtxPtr &ctx, int w, int h) {
        const AVCodec *codec = avcodec_find_encoder(AV_CODEC_ID_FFV1);
        if (!codec) throw CodecError("FFV1 encoder not found");
        ctx.reset(avcodec_alloc_context3(codec));
        ctx->width = w; ctx->height = h;
        ctx->pix_fmt = AV_PIX_FMT_BGRA;
        ctx->time_base = AVRational{1, 1000};
        SC_CHECK(avcodec_open2(ctx.get(), codec, nullptr), "avcodec_open2 (tile encoder)");
    }
    static void openDecoder(CtxPtr &ctx, int w, int h) {
        const AVCodec *codec = avcodec_find_decoder(AV_CODEC_ID_FFV1);
        if (!codec) throw CodecError("FFV1 decoder not found");
        ctx.reset(avcodec_alloc_context3(codec));
        ctx->width = w; ctx->height = h;
        ctx->pix_fmt = AV_PIX_FMT_BGRA;
        SC_CHECK(avcodec_open2(ctx.get(), codec, nullptr), "avcodec_open2 (tile decoder)");
    }
};

} // namespace scalcodec
