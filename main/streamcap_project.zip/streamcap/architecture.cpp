#include "architecture.h"

// ----------------------------------------------------------------------------
// Architecture selection is compile-time (you can only compile AVX2
// intrinsics into an x86_64 binary and NEON intrinsics into an ARM binary --
// there's no such thing as a single binary that runs real AVX2 instructions
// on an ARM chip). What's decided at *runtime* is whether the specific CPU
// (and, for AVX2, the OS) actually supports the vector tier this binary was
// built to offer, versus needing to fall back to Scalar.
// ----------------------------------------------------------------------------
#if defined(_M_X64) || defined(__x86_64__) || defined(_M_IX86) || defined(__i386__)
    #define ARCH_X86 1
#elif defined(_M_ARM64) || defined(__aarch64__) || defined(_M_ARM) || defined(__arm__)
    #define ARCH_ARM 1
#endif

#if defined(ARCH_X86)
    #include <immintrin.h> // _xgetbv
    #if defined(_MSC_VER)
        #include <intrin.h> // __cpuid / __cpuidex
    #endif
#elif defined(ARCH_ARM) && defined(_WIN32)
    #include <windows.h>
#endif

#if defined(ARCH_X86)

static bool cpuidHasAvx2() {
#if defined(_MSC_VER)
    int regs[4] = {0};
    __cpuid(regs, 0);
    int maxLeaf = regs[0];
    if (maxLeaf < 7) return false;

    __cpuid(regs, 1);
    const bool osUsesXsave    = (regs[2] & (1 << 27)) != 0; // ECX.OSXSAVE
    const bool cpuSupportsAvx = (regs[2] & (1 << 28)) != 0; // ECX.AVX
    if (!osUsesXsave || !cpuSupportsAvx) return false;

    // CPUID reporting AVX support isn't enough on its own: the OS also has
    // to have opted in to saving/restoring the wider YMM register state on
    // context switches (it does this via XSETBV at boot). XGETBV(0) reads
    // that back; bits 1 and 2 must both be set (XMM state + YMM state).
    const unsigned long long xcr0 = _xgetbv(0);
    const bool osSavesYmm = (xcr0 & 0x6) == 0x6;
    if (!osSavesYmm) return false;

    __cpuidex(regs, 7, 0);
    const bool cpuSupportsAvx2 = (regs[1] & (1 << 5)) != 0; // EBX.AVX2
    return cpuSupportsAvx2;
#elif defined(__GNUC__) || defined(__clang__)
    __builtin_cpu_init();
    return __builtin_cpu_supports("avx2");
#else
    return false; // unknown x86 compiler: don't assume, fall back to scalar
#endif
}

#endif // ARCH_X86

SimdLevel DetectSimdLevel() {
#if defined(ARCH_X86)
    return cpuidHasAvx2() ? SimdLevel::AVX2 : SimdLevel::Scalar;

#elif defined(ARCH_ARM)
    #if defined(__aarch64__) || defined(_M_ARM64)
        // NEON is a mandatory part of the AArch64 base ISA -- every AArch64
        // core has it, no runtime probe needed.
        return SimdLevel::NEON;
    #elif defined(_WIN32)
        // 32-bit ARM (Windows on ARM, older devices): NEON is optional.
        return IsProcessorFeaturePresent(PF_ARM_NEON_INSTRUCTIONS_AVAILABLE)
                   ? SimdLevel::NEON : SimdLevel::Scalar;
    #elif defined(__ARM_NEON)
        // 32-bit ARM, non-Windows: compiler flags already require NEON
        // (-mfpu=neon), so it's safe to assume present if we got this far.
        return SimdLevel::NEON;
    #else
        return SimdLevel::Scalar;
    #endif

#else
    return SimdLevel::Scalar; // unrecognized architecture
#endif
}

const char *SimdLevelName(SimdLevel level) {
    switch (level) {
        case SimdLevel::AVX2: return "AVX2";
        case SimdLevel::NEON: return "NEON";
        default:              return "Scalar";
    }
}
