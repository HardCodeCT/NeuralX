// ============================================================================
// sender_client.cpp
//
// Windows Graphics Capture (WGC) -> paced 24 FPS -> GPU staging readback ->
// per-frame full/delta decision (diff_detector.h) -> scalable image codec or
// single-rectangle LZ4 delta (codec_common.h / lz4_rect_codec.h) -> raw TCP
// -> hardcoded receiver.
//
// Every captured frame is first downscaled (DownscaleBoxAverage) into a
// small detection proxy (~1/3 linear size, ~1/9 the pixels), and compared
// against the *previous frame's proxy* at fine (8x8px) block granularity
// (diff_detector.h, SIMD-accelerated SAD) -- this keeps the per-frame
// change-detection cost proportional to the proxy's size, not the native
// capture resolution. If most of the proxy's blocks changed, the whole
// frame goes through the existing lossy scalable codec (MJPEG base + FFV1
// residual). Otherwise every dirty block is reduced to a single bounding
// rectangle in proxy coordinates, mapped back to full-resolution pixel
// coordinates (MapBoundingBoxToFullRes), and that region's ORIGINAL
// full-quality pixels are extracted, packed, LZ4-compressed, and sent as
// one message -- the common case (typing, mouse moves, a small UI update)
// collapses to one small rectangle; a frame where nothing changed at all
// sends a tiny empty marker and nothing else.
//
// Build (Developer PowerShell for VS, x64):
//   cl /std:c++20 /EHsc /await /arch:AVX2 ^
//      sender_client.cpp architecture.cpp simd_residual.cpp diff_detector.cpp lz4.c ^
//      /I<ffmpeg_include> ^
//      /link /LIBPATH:<ffmpeg_lib> avcodec.lib avutil.lib swscale.lib ^
//      d3d11.lib dxgi.lib windowsapp.lib ws2_32.lib
//
// Architecture summary (mirrors the requested design point-for-point):
//   1. Frame pacing    - FrameArrived throttles to exactly 1/24s using
//                         std::chrono::high_resolution_clock; frames that
//                         arrive too soon are closed immediately and dropped.
//   2. GPU->CPU staging - the captured ID3D11Texture2D is copied into a
//                         pre-created D3D11_USAGE_STAGING texture and Map'd.
//   3. Pitch stripping  - the mapped RowPitch (which includes GPU alignment
//                         padding) is walked row-by-row with memcpy into a
//                         tightly packed buffer; no expensive row-inversion
//                         is needed since WGC delivers top-down and we do not
//                         need a negative-height BITMAPINFOHEADER trick here
//                         (that trick only matters for the classic GDI/BMP
//                         convention; our packed buffer is consumed directly
//                         by libswscale as top-down BGRA, so it is documented
//                         below and available via packedFrameInfoHeader()
//                         but not otherwise used).
//   4. Zero-alloc hot path - three pre-allocated BGRA buffers are cycled with
//                         an atomic "latest ready" index; the WGC callback
//                         thread never allocates and never blocks on the
//                         network thread, and vice versa.
//   5. Resource lifecycle - Unmap() and frame.Close() are called on every
//                         single iteration, whether the frame was processed
//                         or dropped, so the frame pool can never starve.
// ============================================================================

#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Graphics.Capture.h>
#include <winrt/Windows.Graphics.DirectX.h>
#include <winrt/Windows.Graphics.DirectX.Direct3D11.h>
#include <windows.graphics.capture.interop.h>
#include <windows.graphics.directx.direct3d11.interop.h>

#include <d3d11.h>
#include <dxgi1_2.h>
#include <wrl/client.h>

#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>

#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <thread>
#include <vector>

#include "codec_common.h"
#include "wire_protocol.h"
#include "diff_detector.h"
#include "lz4_rect_codec.h"

using Microsoft::WRL::ComPtr;
namespace winrt_gc = winrt::Windows::Graphics::Capture;
namespace winrt_d3d = winrt::Windows::Graphics::DirectX::Direct3D11;

// ----------------------------------------------------------------------------
// Documented-but-unused-on-the-wire header, included to satisfy the classic
// "top-down capture -> negative-height BITMAPINFOHEADER" convention some
// downstream tools expect if this buffer is ever handed to GDI/BMP code
// instead of libswscale.
// ----------------------------------------------------------------------------
static BITMAPINFOHEADER packedFrameInfoHeader(int width, int height) {
    BITMAPINFOHEADER bih{};
    bih.biSize = sizeof(BITMAPINFOHEADER);
    bih.biWidth = width;
    bih.biHeight = -height; // negative: matches WGC's native top-down layout
    bih.biPlanes = 1;
    bih.biBitCount = 32; // BGRA8
    bih.biCompression = BI_RGB;
    bih.biSizeImage = width * height * 4;
    return bih;
}

// ----------------------------------------------------------------------------
// Fixed-capacity triple buffer for the packed BGRA payload. The capture
// thread writes into the "next" slot and atomically publishes it; the
// network thread atomically claims the latest published slot. No locks, no
// allocation, on either side.
// ----------------------------------------------------------------------------
class TripleBuffer {
public:
    void init(size_t bytesPerFrame) {
        for (auto &b : buf_) b.assign(bytesPerFrame, 0);
    }
    // Returns a pointer to the slot the capture thread should fill next.
    uint8_t *writeSlot() { return buf_[writeIndex_].data(); }

    // Called after the capture thread finishes filling writeSlot(); makes it
    // visible to the consumer and advances to the next free slot.
    void publish(int64_t frameIndex) {
        readyIndex_.store(writeIndex_, std::memory_order_release);
        readyFrameIndex_.store(frameIndex, std::memory_order_release);
        writeIndex_ = (writeIndex_ + 1) % 3;
        // Skip the slot currently claimed by a reader, if any, to avoid
        // tearing; with 3 slots there is always a free one between the
        // in-flight write slot and the last-published/consumed slot.
        if (writeIndex_ == readIndex_.load(std::memory_order_acquire))
            writeIndex_ = (writeIndex_ + 1) % 3;
    }

    // Consumer side: returns nullptr if no new frame has been published
    // since the last claim.
    const uint8_t *claimLatest(int64_t &outFrameIndex) {
        int idx = readyIndex_.load(std::memory_order_acquire);
        int64_t fi = readyFrameIndex_.load(std::memory_order_acquire);
        if (fi == lastConsumed_) return nullptr;
        lastConsumed_ = fi;
        readIndex_.store(idx, std::memory_order_release);
        outFrameIndex = fi;
        return buf_[idx].data();
    }

private:
    std::vector<uint8_t> buf_[3];
    int writeIndex_ = 0;
    std::atomic<int> readIndex_{0};
    std::atomic<int> readyIndex_{-1};
    std::atomic<int64_t> readyFrameIndex_{-1};
    int64_t lastConsumed_ = -1;
};

// ----------------------------------------------------------------------------
// Minimal blocking TCP sender used by the network thread.
// ----------------------------------------------------------------------------
class TcpSender {
public:
    TcpSender() {
        WSADATA wsaData;
        if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
            throw std::runtime_error("WSAStartup failed");
    }
    ~TcpSender() {
        if (sock_ != INVALID_SOCKET) closesocket(sock_);
        WSACleanup();
    }

    void connectToReceiver() {
        sock_ = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (sock_ == INVALID_SOCKET) throw std::runtime_error("socket() failed");

        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(endpoint::PORT);
        inet_pton(AF_INET, endpoint::HOST, &addr.sin_addr); // hardcoded 127.0.0.1

        std::fprintf(stderr, "[sender] connecting to %s:%u ...\n", endpoint::HOST, endpoint::PORT);
        if (connect(sock_, reinterpret_cast<sockaddr *>(&addr), sizeof(addr)) != 0)
            throw std::runtime_error("connect() failed");

        int one = 1;
        setsockopt(sock_, IPPROTO_TCP, TCP_NODELAY, reinterpret_cast<const char *>(&one), sizeof(one));
        std::fprintf(stderr, "[sender] connected\n");
    }

    void sendMessage(wire::MsgType type, int64_t frameIndex, const uint8_t *data, uint32_t size,
                      uint32_t tileIndex = wire::NO_TILE) {
        wire::Header h;
        h.type = static_cast<uint8_t>(type);
        h.frameIndex = frameIndex;
        h.tileIndex = tileIndex;
        h.payloadSize = size;
        uint8_t hdr[wire::HEADER_SIZE];
        h.serialize(hdr);
        sendAll(hdr, sizeof(hdr));
        if (size) sendAll(data, size);
    }
    void sendMessage(wire::MsgType type, int64_t frameIndex, const std::vector<uint8_t> &data,
                      uint32_t tileIndex = wire::NO_TILE) {
        sendMessage(type, frameIndex, data.empty() ? nullptr : data.data(),
                    static_cast<uint32_t>(data.size()), tileIndex);
    }

private:
    SOCKET sock_ = INVALID_SOCKET;

    void sendAll(const uint8_t *data, size_t size) {
        size_t sent = 0;
        while (sent < size) {
            int rc = send(sock_, reinterpret_cast<const char *>(data) + sent,
                           static_cast<int>(size - sent), 0);
            if (rc <= 0) throw std::runtime_error("send() failed");
            sent += static_cast<size_t>(rc);
        }
    }
};

// ----------------------------------------------------------------------------
// ScreenCaptureSender: owns the D3D11 device, the WGC frame pool/session,
// the staging texture, the triple buffer, and the network thread.
// ----------------------------------------------------------------------------
class ScreenCaptureSender {
public:
    static constexpr double kTargetFps = 24.0;
    static constexpr auto   kFramePeriod = std::chrono::duration<double, std::milli>(1000.0 / kTargetFps); // ~41.67ms
    static constexpr int    kLowResHeight = 360; // base-layer target height
    static constexpr int    kBlockSize = 8;      // dirty-detection grid cell size, pixels *of the downscaled proxy*
    // Dirty-detection runs on a downscaled proxy of the capture, not the
    // native-resolution frame -- comparing every byte of a 1900x900 capture
    // (SAD over ~6.8MB, against the previous frame, every frame) is real
    // CPU cost; comparing a proxy this much smaller is proportionally
    // cheaper. 3x roughly matches "1900x900 -> ~633x300", i.e. the
    // resolution this scheme was originally budgeted against; tune if your
    // capture resolution differs a lot from that.
    static constexpr int    kDetectionDownscaleFactor = 3;
    // If more than this fraction of blocks changed, sending one big
    // bounding-box rectangle stops being a win over just re-sending the
    // whole frame through the lossy scalable codec -- fall back to full
    // mode. This also caps worst-case delta-frame bandwidth.
    static constexpr double kFullFrameFallbackRatio = 0.5;

    void run() {
        initD3D11();
        initCaptureItem();
        initStagingTexture();

        codec_.init(scalcodec::FrameCodec::Side::Sender, fullW_, fullH_, kLowResHeight);

        // Downscaled detection proxy dimensions + grid. Detection (the SAD
        // comparison) and the resulting bounding box both operate in this
        // smaller coordinate space; MapBoundingBoxToFullRes() converts the
        // final box back to full-res pixel coordinates before extraction,
        // so the actual transmitted pixels are still full quality -- only
        // the *decision of which region changed* runs at reduced resolution.
        dsW_ = std::max(1, fullW_ / kDetectionDownscaleFactor);
        dsH_ = std::max(1, fullH_ / kDetectionDownscaleFactor);
        blockGrid_ = diffdet::makeGrid(dsW_, dsH_, kBlockSize);

        tripleBuf_.init(static_cast<size_t>(fullW_) * fullH_ * 4);
        prevFrameDs_.assign(static_cast<size_t>(dsW_) * dsH_ * 4, 0);
        currFrameDs_.assign(static_cast<size_t>(dsW_) * dsH_ * 4, 0);
        havePrevFrame_ = false;

        // Worst case a delta rectangle can be is the entire frame (just
        // under the 50% fallback ratio can still produce a bounding box
        // that spans the whole width/height if dirty blocks are scattered
        // at opposite corners) -- size the zero-alloc scratch buffers for
        // that once, up front, so encoding a rectangle never allocates.
        const size_t maxRectBytes = static_cast<size_t>(fullW_) * fullH_ * 4;
        rectPackScratch_.assign(maxRectBytes, 0);
        rectCompressedScratch_.assign(lz4rect::Lz4Bound(maxRectBytes), 0);

        sender_.connectToReceiver();
        sender_.sendMessage(wire::MSG_CONFIG, 0,
                             wire::buildConfigPayload(fullW_, fullH_, codec_.lowWidth(), codec_.lowHeight(),
                                                       kBlockSize, blockGrid_.tilesX, blockGrid_.tilesY));

        networkThread_ = std::thread(&ScreenCaptureSender::networkLoop, this);

        framePool_ = winrt_gc::Direct3D11CaptureFramePool::Create(
            winrtDevice_, winrt::Windows::Graphics::DirectX::DirectXPixelFormat::B8G8R8A8UIntNormalized,
            /*numBuffers*/ 2, captureItem_.Size());
        framePool_.FrameArrived({this, &ScreenCaptureSender::onFrameArrived});

        session_ = framePool_.CreateCaptureSession(captureItem_);
        session_.StartCapture();

        std::fprintf(stderr, "[sender] capturing %dx%d @ %.2f fps -> base %dx%d, detection proxy %dx%d, block grid %dx%d @ %dpx (%d blocks total)\n",
                     fullW_, fullH_, kTargetFps, codec_.lowWidth(), codec_.lowHeight(),
                     dsW_, dsH_, blockGrid_.tilesX, blockGrid_.tilesY, kBlockSize, blockGrid_.tileCount());

        // Keep the WinRT dispatcher-free capture pumping; FrameArrived fires
        // on a WGC worker thread, so we just idle here.
        std::this_thread::sleep_for(std::chrono::hours(24));
    }

private:
    // ---- D3D11 / WGC state --------------------------------------------------
    ComPtr<ID3D11Device> d3dDevice_;
    ComPtr<ID3D11DeviceContext> d3dContext_;
    winrt_d3d::IDirect3DDevice winrtDevice_{nullptr};
    winrt_gc::GraphicsCaptureItem captureItem_{nullptr};
    winrt_gc::Direct3D11CaptureFramePool framePool_{nullptr};
    winrt_gc::GraphicsCaptureSession session_{nullptr};
    ComPtr<ID3D11Texture2D> stagingTex_;

    int fullW_ = 0, fullH_ = 0;
    int dsW_ = 0, dsH_ = 0; // downscaled detection-proxy dimensions

    // ---- Pacing --------------------------------------------------------------
    std::chrono::high_resolution_clock::time_point lastAcceptedTime_{};
    int64_t frameCounter_ = 0;

    // ---- Codec / handoff / network --------------------------------------------
    scalcodec::FrameCodec codec_;
    diffdet::TileGrid blockGrid_;          // 8x8 dirty-detection grid, in DOWNSCALED proxy coordinates
    std::vector<uint8_t> prevFrameDs_;     // previous frame's downscaled proxy, for delta comparison
    std::vector<uint8_t> currFrameDs_;     // current frame's downscaled proxy, rebuilt every frame
    bool havePrevFrame_ = false;
    TripleBuffer tripleBuf_;
    TcpSender sender_;
    std::thread networkThread_;
    std::vector<uint8_t> baseScratch_, enhScratch_;             // full-frame path, reused every send
    std::vector<uint8_t> rectPackScratch_, rectCompressedScratch_; // delta-rect path, reused every send
    std::vector<uint8_t> deltaPayload_;                          // rect header + compressed bytes, reused every send

    void initD3D11() {
        UINT flags = D3D11_CREATE_DEVICE_BGRA_SUPPORT; // required: WGC surfaces are BGRA
#if defined(_DEBUG)
        flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif
        D3D_FEATURE_LEVEL fl;
        HRESULT hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, flags,
                                        nullptr, 0, D3D11_SDK_VERSION,
                                        d3dDevice_.GetAddressOf(), &fl, d3dContext_.GetAddressOf());
        if (FAILED(hr)) throw std::runtime_error("D3D11CreateDevice failed");

        ComPtr<IDXGIDevice> dxgiDevice;
        d3dDevice_.As(&dxgiDevice);
        winrt::com_ptr<::IInspectable> inspectable;
        winrt::check_hresult(CreateDirect3D11DeviceFromDXGIDevice(
            dxgiDevice.Get(), reinterpret_cast<::IInspectable **>(winrt::put_abi(inspectable))));
        winrtDevice_ = inspectable.as<winrt_d3d::IDirect3DDevice>();
    }

    void initCaptureItem() {
        // Capture the primary monitor. (Swap for a specific HWND via
        // CreateCaptureItemForWindow if you want a single window instead.)
        HMONITOR monitor = MonitorFromWindow(nullptr, MONITOR_DEFAULTTOPRIMARY);
        auto interopFactory = winrt::get_activation_factory<winrt_gc::GraphicsCaptureItem>()
                                   .as<IGraphicsCaptureItemInterop>();
        winrt::com_ptr<ABI::Windows::Graphics::Capture::IGraphicsCaptureItem> itemAbi;
        winrt::check_hresult(interopFactory->CreateForMonitor(
            monitor, winrt::guid_of<ABI::Windows::Graphics::Capture::IGraphicsCaptureItem>(), itemAbi.put_void()));
        captureItem_ = itemAbi.as<winrt_gc::GraphicsCaptureItem>();

        auto size = captureItem_.Size();
        fullW_ = size.Width;
        fullH_ = size.Height;
    }

    void initStagingTexture() {
        D3D11_TEXTURE2D_DESC desc{};
        desc.Width = fullW_;
        desc.Height = fullH_;
        desc.MipLevels = 1;
        desc.ArraySize = 1;
        desc.Format = DXGI_FORMAT_B8G8R8A8_UNORM;
        desc.SampleDesc.Count = 1;
        desc.Usage = D3D11_USAGE_STAGING;
        desc.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
        desc.BindFlags = 0;
        if (FAILED(d3dDevice_->CreateTexture2D(&desc, nullptr, stagingTex_.GetAddressOf())))
            throw std::runtime_error("CreateTexture2D (staging) failed");
    }

    // ---- WGC callback: this is the hot path. No allocation happens here
    // after the first call (buffers are all pre-sized in TripleBuffer::init). ----
    void onFrameArrived(winrt_gc::Direct3D11CaptureFramePool const &pool,
                         winrt::Windows::Foundation::IInspectable const &) {
        auto frame = pool.TryGetNextFrame();
        if (!frame) return; // spurious wakeup; nothing to close

        // ---- 1. Frame pacing: 24 FPS hard lock -------------------------------
        auto now = std::chrono::high_resolution_clock::now();
        auto elapsed = now - lastAcceptedTime_;
        bool accept = elapsed >= kFramePeriod;

        if (!accept) {
            // Drop: still must close the frame every single iteration so the
            // pool never starves, per the resource-lifecycle requirement.
            frame.Close();
            return;
        }
        lastAcceptedTime_ = now;

        // ---- 2. GPU-to-CPU staging readback -----------------------------------
        auto surface = frame.Surface();
        auto dxgiInterfaceAccess = surface.as<
            ::Windows::Graphics::DirectX::Direct3D11::IDirect3DDxgiInterfaceAccess>();
        ComPtr<ID3D11Texture2D> srcTex;
        winrt::check_hresult(dxgiInterfaceAccess->GetInterface(IID_PPV_ARGS(srcTex.GetAddressOf())));

        d3dContext_->CopyResource(stagingTex_.Get(), srcTex.Get());

        D3D11_MAPPED_SUBRESOURCE mapped{};
        HRESULT hr = d3dContext_->Map(stagingTex_.Get(), 0, D3D11_MAP_READ, 0, &mapped);
        if (SUCCEEDED(hr)) {
            // ---- 3. Strict pitch stripping into a tightly packed buffer ------
            uint8_t *dst = tripleBuf_.writeSlot();
            const uint8_t *src = static_cast<const uint8_t *>(mapped.pData);
            const int tightRowBytes = fullW_ * 4; // BGRA8
            for (int y = 0; y < fullH_; ++y) {
                std::memcpy(dst + y * tightRowBytes, src + y * mapped.RowPitch, tightRowBytes);
            }
            d3dContext_->Unmap(stagingTex_.Get(), 0);

            // ---- 4. Hand off via atomic publish (no lock, no block) -----------
            tripleBuf_.publish(frameCounter_++);
        } else {
            d3dContext_->Unmap(stagingTex_.Get(), 0); // still balance the map attempt if partially applied
        }

        // ---- 5. Resource lifecycle: always close the frame -----------------------
        frame.Close();
    }

    // ---- Network thread: pulls the latest published buffer, decides
    // full-frame vs. delta-rect mode by comparing against the previous
    // frame, encodes accordingly, and streams it out. Runs independently of
    // the WGC callback thread so encode/send/diff time never causes WGC
    // frame-pool starvation. ----
    void networkLoop() {
        const int dsStrideBytes = dsW_ * 4;
        while (true) {
            int64_t fi;
            const uint8_t *bgra = tripleBuf_.claimLatest(fi);
            if (!bgra) {
                std::this_thread::sleep_for(std::chrono::milliseconds(1));
                continue;
            }
            try {
                const int strideBytes = fullW_ * 4;

                // Build this frame's downscaled detection proxy once, up
                // front -- this is the fix for comparing at native
                // resolution: detection below runs entirely on the ~9x
                // smaller dsW_ x dsH_ buffer, not the full capture.
                diffdet::DownscaleBoxAverage(bgra, fullW_, fullH_, strideBytes,
                                              currFrameDs_.data(), dsW_, dsH_, dsStrideBytes);

                if (!havePrevFrame_) {
                    // First frame ever: nothing to diff against, must send in full.
                    sendFullFrame(bgra, strideBytes, fi);
                } else {
                    // 8x8-block SAD comparison on the downscaled proxies
                    // (SIMD-dispatched inside diffdet; see diff_detector.cpp).
                    diffdet::DetectDirtyTiles(prevFrameDs_.data(), currFrameDs_.data(), dsStrideBytes, blockGrid_);
                    int dirtyCount = 0;
                    for (uint8_t d : blockGrid_.dirty) dirtyCount += d;

                    const double dirtyRatio = static_cast<double>(dirtyCount) / blockGrid_.tileCount();
                    if (dirtyRatio > kFullFrameFallbackRatio) {
                        // Too much of the screen changed for one small
                        // rectangle to be worth it -- caps worst-case
                        // per-frame bandwidth at one full-frame encode.
                        sendFullFrame(bgra, strideBytes, fi);
                    } else if (dirtyCount == 0) {
                        sendEmptyDelta(fi);
                    } else {
                        // Bounding box is computed in the downscaled
                        // proxy's coordinate space; map it back to
                        // full-resolution pixel coordinates before
                        // extracting -- the transmitted pixels are always
                        // full quality, only the change-detection ran at
                        // reduced resolution.
                        diffdet::BoundingBox dsBox = diffdet::ComputeDirtyBoundingBox(blockGrid_);
                        diffdet::BoundingBox fullBox =
                            diffdet::MapBoundingBoxToFullRes(dsBox, dsW_, dsH_, fullW_, fullH_);
                        sendDeltaFrame(bgra, strideBytes, fi, fullBox);
                    }
                }

                // Zero-copy proxy rotation: the just-built currFrameDs_
                // becomes next iteration's prevFrameDs_ via a plain pointer
                // swap (std::vector::swap is O(1), no data movement) --
                // cheaper than the full-res memcpy this replaced, and
                // currFrameDs_ (now holding the old prev contents) simply
                // gets overwritten by DownscaleBoxAverage before it's read
                // again next iteration.
                std::swap(prevFrameDs_, currFrameDs_);
                havePrevFrame_ = true;
            } catch (const std::exception &ex) {
                std::fprintf(stderr, "[sender] frame %lld dropped (encode/send error: %s)\n",
                             static_cast<long long>(fi), ex.what());
            }
        }
    }

    void sendFullFrame(const uint8_t *bgra, int strideBytes, int64_t fi) {
        codec_.encodeFrame(bgra, strideBytes, fi, baseScratch_, enhScratch_);
        sender_.sendMessage(wire::MSG_FRAME_FULL, fi, nullptr, 0);
        sender_.sendMessage(wire::MSG_BASE, fi, baseScratch_);
        sender_.sendMessage(wire::MSG_ENH, fi, enhScratch_);
    }

    // tile_index is unused by delta frames (position lives in the payload's
    // rect_x/rect_y instead) -- set to 0 rather than the NO_TILE sentinel,
    // matching the wire spec's convention that this field is simply 0 for
    // MSG_FRAME_DELTA.
    static constexpr uint32_t kDeltaTileIndex = 0;

    void sendEmptyDelta(int64_t fi) {
        // Screen unchanged since the last frame: one tiny marker message,
        // nothing to compress, nothing further to send.
        sender_.sendMessage(wire::MSG_FRAME_DELTA, fi, wire::buildEmptyDeltaPayload(), kDeltaTileIndex);
    }

    // Packs the given full-resolution rectangle's BGRA pixels out of the
    // (strided) capture buffer into a tightly-packed scratch buffer,
    // LZ4-compresses it, and sends the whole thing as a single
    // MSG_FRAME_DELTA message -- no per-block messages, no per-block codec
    // overhead. `box` must already be in full-frame pixel coordinates (see
    // MapBoundingBoxToFullRes in the caller).
    void sendDeltaFrame(const uint8_t *bgra, int strideBytes, int64_t fi, const diffdet::BoundingBox &box) {
        if (box.empty()) { // defensive; caller already checked dirtyCount > 0
            sendEmptyDelta(fi);
            return;
        }

        // ---- Pack: this copy is unavoidable, not "unnecessary" -- the
        // rectangle's rows aren't contiguous in the source frame buffer
        // (each row is `strideBytes` apart, the rect is only `box.width*4`
        // wide), and LZ4's single-shot API needs one contiguous input
        // buffer. One memcpy per row, into a buffer sized once at startup. ----
        const int rectRowBytes = box.width * 4;
        for (int row = 0; row < box.height; ++row) {
            const uint8_t *srcRow = bgra + static_cast<size_t>(box.y + row) * strideBytes
                                          + static_cast<size_t>(box.x) * 4;
            std::memcpy(rectPackScratch_.data() + static_cast<size_t>(row) * rectRowBytes,
                        srcRow, rectRowBytes);
        }
        const size_t rectBytes = static_cast<size_t>(rectRowBytes) * box.height;

        const size_t compressedSize = lz4rect::CompressRect(
            rectPackScratch_.data(), rectBytes,
            rectCompressedScratch_.data(), rectCompressedScratch_.size());

        // Assemble payload = [rect_x][rect_y][rect_w][rect_h] + compressed bytes.
        wire::buildDeltaPayloadHeader(deltaPayload_, box.x, box.y, box.width, box.height);
        size_t off = deltaPayload_.size();
        deltaPayload_.resize(off + compressedSize);
        std::memcpy(deltaPayload_.data() + off, rectCompressedScratch_.data(), compressedSize);

        sender_.sendMessage(wire::MSG_FRAME_DELTA, fi, deltaPayload_, kDeltaTileIndex);
    }
};

int main() {
    winrt::init_apartment(winrt::apartment_type::multi_threaded);
    try {
        ScreenCaptureSender sender;
        sender.run();
    } catch (const std::exception &ex) {
        std::fprintf(stderr, "[sender] fatal: %s\n", ex.what());
        return 1;
    }
    return 0;
}
