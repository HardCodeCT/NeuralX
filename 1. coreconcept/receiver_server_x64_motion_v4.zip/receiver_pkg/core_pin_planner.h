// ============================================================================
// core_pin_planner.h
//
// Replaces hardcoded core-index literals (the earlier "pin to 1"/"pin to 2")
// with an actual plan: query how many cores THIS PROCESS can really use,
// decide which cores are worth avoiding, and hand out assignments to hot
// threads round-robin so the decision scales instead of guessing a number.
//
// The "avoid core 0" policy, and how much weight it deserves:
//   The working assumption here -- that core 0 tends to be the OS's
//   default landing spot for interrupt handling, DPCs, and other
//   default-affinity kernel/system work, making it a busier core than the
//   others on average -- is something I'm carrying over from a university
//   lecture's claim, not a benchmark measured on this specific machine.
//   It's a widely repeated heuristic with real historical grounding (early
//   PIC/APIC interrupt routing did default heavily to the first logical
//   processor, and Windows' default IRQ affinity policy still biases that
//   way in practice), but actual interrupt distribution varies by
//   motherboard, IRQ-affinity policy, driver behavior, and OS version --
//   so this is applied as a reasonable DEFAULT BIAS, not stated as a
//   guaranteed fact. If you've measured your actual target hardware and
//   found otherwise, override PreferredCores() below accordingly.
// ============================================================================
#pragma once

#include "thread_affinity.h"
#include <cstdio>
#include <mutex>
#include <vector>

namespace threadutil {

class CorePinPlanner {
public:
    CorePinPlanner() {
        total_ = AvailableCoreCount();

        if (total_ <= 1) {
            // Genuine exception to the policy, not a bug in it: with only
            // one core available to this process, there is nothing to
            // avoid it FOR -- every thread, hot or not, already shares it.
            preferred_.push_back(0);
            std::fprintf(stderr,
                "[core_pin_planner] Only 1 core available to this process -- "
                "cannot avoid core 0, every thread shares it regardless.\n");
        } else {
            for (int c = 1; c < total_; ++c) preferred_.push_back(c);
            std::fprintf(stderr,
                "[core_pin_planner] %d core(s) available to this process; "
                "avoiding core 0, %zu preferred core(s) for hot threads: ",
                total_, preferred_.size());
            for (size_t i = 0; i < preferred_.size(); ++i)
                std::fprintf(stderr, "%d%s", preferred_[i], (i + 1 < preferred_.size()) ? ", " : "\n");
        }
    }

    // Hands out the next core for a hot thread to pin itself to, round-
    // robin across the preferred list. Calling this once per hot thread at
    // startup spreads them across distinct non-zero cores when enough
    // exist; on a low-core-count machine (e.g. a 2-core box, where
    // preferred_ has exactly one entry), multiple hot threads correctly
    // end up sharing that single preferred core rather than the plan
    // silently failing or indexing out of range.
    int AssignNextCore(const char *roleLabel) {
        std::lock_guard<std::mutex> lock(mutex_);
        const int core = preferred_[nextIndex_ % preferred_.size()];
        ++nextIndex_;
        std::fprintf(stderr, "[core_pin_planner] '%s' -> core %d%s\n", roleLabel, core,
                     (total_ > 1 && preferred_.size() < nextIndex_) ? "" :
                     (preferred_.size() == 1 && total_ > 1) ? " (sharing -- only 1 non-zero core available)" : "");
        return core;
    }

    int totalCores() const { return total_; }
    size_t preferredCoreCount() const { return preferred_.size(); }

private:
    int total_ = 1;
    std::vector<int> preferred_;
    size_t nextIndex_ = 0;
    std::mutex mutex_; // AssignNextCore may be called from multiple threads at startup
};

} // namespace threadutil
