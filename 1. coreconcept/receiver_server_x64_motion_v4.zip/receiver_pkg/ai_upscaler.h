#pragma once
// ============================================================================
// ai_upscaler.h
//
// Two-tier upscaling used to make the reconstructed BGRA canvas look like a
// continuously AI-upscaled stream without paying FSRCNN-s's cost on every
// frame:
//
//   FullFrameUpscale()  -- expensive (~tens of ms on CPU): runs FSRCNN-s on
//     the Y channel of the *entire* source-resolution frame, bicubic-
//     upscales Cb/Cr with OpenCV, and recombines to BGRA at N x source
//     resolution. Used for the very first frame and for the periodic
//     staleness refresh. Two interchangeable backends (below).
//
//   CheapRectUpscale() + FeatherPasteRect() -- cheap (~sub-ms for a small
//     dirty rect): plain OpenCV bicubic upscale (cv::INTER_CUBIC) of just
//     the changed rectangle, pasted onto the existing master canvas with a
//     feathered edge so the seam between "AI-sharp" and "cheaply-scaled"
//     pixels isn't visible. Always CPU -- it's cheap enough that a GPU
//     round-trip isn't worth it for a small rect.
//
// Backends for FullFrameUpscale:
//   kCpuEigen   -- thinkerleolee/FSRCNN-OpenCV's own fsrcnn.h/fsrcnn.cc,
//                  unmodified, linked against the prebuilt TensorConv.lib
//                  (vendored under third_party/tensorconv/ + third_party/
//                  eigen/). Runs on CPU cores via Eigen::ThreadPoolDevice.
//                  Works everywhere; no GPU needed.
//   kOpenCLiGpu -- OpenCV's dnn_superres module (opencv_contrib) loading
//                  the same FSRCNN-s architecture from a portable
//                  TensorFlow .pb graph (models/fsrcnn_s_x{2,3}.pb, from
//                  the same thinkerleolee/FSRCNN-OpenCV repo), run through
//                  cv::dnn with DNN_BACKEND_OPENCV / DNN_TARGET_OPENCL --
//                  i.e. the CPU's *integrated* GPU (Intel UHD/Iris, AMD
//                  Radeon on an APU, etc.), not a discrete NVIDIA/CUDA
//                  card. Requires an OpenCV build with dnn_superres +
//                  OpenCL support; falls back to kCpuEigen automatically
//                  (logged) if OpenCL isn't available at runtime.
// ============================================================================

#include <cstdint>
#include <string>
#include <vector>

namespace aiup {

enum class Backend {
    kCpuEigen,    // thinkerleolee/FSRCNN-OpenCV + TensorConv.lib (CPU threads)
    kOpenCLiGpu,  // OpenCV dnn_superres + DNN_TARGET_OPENCL (integrated GPU)
};

// scale must be 2 or 3 -- the only two FSRCNN-s weight sets both backends
// have available (fsrcnn_params.h's arrays, and models/fsrcnn_s_x{2,3}.pb).
class Upscaler {
public:
    // modelDir: only used by kOpenCLiGpu -- directory containing
    // fsrcnn_s_x2.pb / fsrcnn_s_x3.pb (defaults to "models", i.e. a
    // "models\" folder next to the .exe).
    explicit Upscaler(int scale, Backend backend = Backend::kCpuEigen,
                       const std::string &modelDir = "models");
    ~Upscaler();

    int scale() const;
    Backend backend() const; // may differ from the requested one if OpenCL
                              // init failed and it fell back to kCpuEigen

    // srcBGRA: tightly packed top-down BGRA8, srcW x srcH.
    // dstBGRA: caller-owned buffer, must already be sized
    //          (srcW*scale) * (srcH*scale) * 4 bytes.
    void FullFrameUpscale(const uint8_t *srcBGRA, int srcW, int srcH, uint8_t *dstBGRA) const;

    // Upscales just one rectangle of the source-resolution raw frame with
    // cheap bicubic interpolation (no neural net). Returns a tightly packed
    // BGRA8 buffer of size (rectW*scale) x (rectH*scale).
    std::vector<uint8_t> CheapRectUpscale(const uint8_t *srcBGRA, int srcStrideBytes,
                                           int rectX, int rectY, int rectW, int rectH) const;

    // Pastes `upscaledRect` (as produced by CheapRectUpscale, dims
    // rectW*scale x rectH*scale) onto `masterCanvas` (masterW x masterH,
    // stride masterW*4) at the scaled destination position
    // (rectX*scale, rectY*scale), feathering the outer `featherPx` pixels
    // of the rect so it blends with whatever was already on the canvas
    // there (previous FSRCNN-sharp or previously cheap-scaled content)
    // instead of leaving a hard seam.
    void FeatherPasteRect(uint8_t *masterCanvas, int masterW, int masterH,
                           int rectX, int rectY, int rectW, int rectH,
                           const std::vector<uint8_t> &upscaledRect, int featherPx = 6) const;

private:
    struct Impl;
    Impl *impl_;
};

} // namespace aiup
