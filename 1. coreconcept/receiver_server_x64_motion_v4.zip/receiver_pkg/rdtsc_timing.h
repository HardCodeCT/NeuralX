// ============================================================================
// rdtsc_timing.h
//
// Cycle-accurate, low-overhead stage timing using the CPU's own timestamp
// counter (RDTSC), not std::chrono. This is what backs the "why 24 fps"
// budget math: each hot-path stage (staging readback, downscale+diff,
// encode) is timed on every real frame, converted from cycles to
// milliseconds using a one-time wall-clock calibration, and periodically
// summed against kFramePeriod (~41.67ms at 24fps) to confirm the whole
// pipeline actually fits inside one frame period with headroom to spare.
//
// Why RDTSC instead of std::chrono::high_resolution_clock:
//   - RDTSC reads a hardware cycle counter directly (one instruction),
//     which is orders of magnitude cheaper per call than a
//     QueryPerformanceCounter-backed chrono clock -- important here because
//     the tracker is timing sub-millisecond stages many times a second, and
//     the timer itself must not distort what it's measuring.
//   - On any CPU with an invariant TSC (every x86_64 CPU relevant to this
//     project), RDTSC ticks at a fixed rate independent of core frequency
//     scaling/turbo, so it stays proportional to true elapsed time even
//     under power-management frequency changes -- unlike scaling based on
//     rated clock speed, which is not accurate.
//
// LFENCE fencing:
//   RDTSC is not a serializing instruction -- the out-of-order CPU can
//   execute it earlier or later than its position in program order relative
//   to surrounding work. LFENCE forces all prior instructions to retire
//   before RDTSC executes, and blocks later instructions from executing
//   before it, so the cycle count actually brackets the code between the
//   two calls rather than some reordered approximation of it.
// ============================================================================
#pragma once

#include <intrin.h>      // __rdtsc, _mm_lfence (MSVC intrinsics)
#include <cstdint>
#include <cstdio>
#include <array>
#include <chrono>
#include <thread>

namespace timing {

inline uint64_t rdtscFenced() {
    _mm_lfence();
    uint64_t t = __rdtsc();
    _mm_lfence();
    return t;
}

// One-time calibration: RDTSC's tick rate is fixed per-CPU but is NOT the
// same as the CPU's advertised/base clock speed (modern CPUs derive it from
// a separate crystal/PLL reference), so it must be measured against a known
// wall-clock interval rather than assumed from the CPU model.
inline double calibrateCyclesPerMs() {
    using namespace std::chrono;
    uint64_t c0 = rdtscFenced();
    auto t0 = high_resolution_clock::now();
    std::this_thread::sleep_for(milliseconds(50));
    uint64_t c1 = rdtscFenced();
    auto t1 = high_resolution_clock::now();
    double ms = duration<double, std::milli>(t1 - t0).count();
    return static_cast<double>(c1 - c0) / ms;
}

enum Stage : int {
    STAGE_STAGING_READBACK = 0, // GPU->CPU copy, Map(), pitch-stripping memcpy
    STAGE_DOWNSCALE_DIFF,       // detection proxy downscale + 8x8-block SAD diff
    STAGE_ENCODE,               // MJPEG+FFV1 full frame OR LZ4 delta rect pack+compress
    STAGE_COUNT
};

struct StageAccum {
    uint64_t totalCycles = 0;
    uint64_t count = 0;
};

// Accumulates per-stage RDTSC measurements across real frames and reports
// the running average against the frame-period budget every N frames.
class FrameBudgetTracker {
public:
    explicit FrameBudgetTracker(double targetFps) : targetFps_(targetFps) {
        cyclesPerMs_ = calibrateCyclesPerMs();
        std::fprintf(stderr, "[timing] RDTSC calibrated: %.1f cycles/ms on this CPU\n", cyclesPerMs_);
    }

    // RAII scoped timer -- construct at the top of a stage's scope; it
    // records the elapsed cycle count into the tracker on destruction, so
    // callers don't need to manually start/stop anything or handle
    // early-return paths incorrectly.
    class Scope {
    public:
        Scope(FrameBudgetTracker &owner, Stage stage)
            : owner_(owner), stage_(stage), start_(rdtscFenced()) {}
        ~Scope() {
            uint64_t elapsed = rdtscFenced() - start_;
            owner_.accum_[stage_].totalCycles += elapsed;
            owner_.accum_[stage_].count++;
        }
        Scope(const Scope &) = delete;
    private:
        FrameBudgetTracker &owner_;
        Stage stage_;
        uint64_t start_;
    };

    Scope scope(Stage s) { return Scope(*this, s); }

    // Every reportEveryN real frames, dump measured average ms/stage and
    // how much of kFramePeriod is actually consumed -- this is the number
    // that justifies 24fps: if sumMs stays comfortably under framePeriodMs
    // with margin, the budget holds; if it doesn't, either the target fps
    // needs to drop or a stage needs optimizing.
    void maybeReport(int64_t frameIndex, double framePeriodMs, int reportEveryN = 24) {
        if (frameIndex == 0 || frameIndex % reportEveryN != 0) return;

        static const char *names[STAGE_COUNT] = {
            "staging readback", "downscale + diff", "encode"
        };

        double sumMs = 0.0;
        std::fprintf(stderr, "[timing] --- budget check @ frame %lld (target %.2f fps, %.3fms/frame) ---\n",
                     static_cast<long long>(frameIndex), targetFps_, framePeriodMs);
        for (int s = 0; s < STAGE_COUNT; ++s) {
            if (accum_[s].count == 0) continue;
            double avgMs = (static_cast<double>(accum_[s].totalCycles) / accum_[s].count) / cyclesPerMs_;
            sumMs += avgMs;
            std::fprintf(stderr, "[timing]   %-18s avg %.3fms  (RDTSC, %llu samples)\n",
                         names[s], avgMs, static_cast<unsigned long long>(accum_[s].count));
        }
        std::fprintf(stderr, "[timing]   sum of stages: %.3fms / %.3fms budget  (%.1f%% used, %.3fms headroom)\n",
                     sumMs, framePeriodMs, 100.0 * sumMs / framePeriodMs, framePeriodMs - sumMs);
    }

private:
    double targetFps_;
    double cyclesPerMs_;
    std::array<StageAccum, STAGE_COUNT> accum_{};
};

} // namespace timing
