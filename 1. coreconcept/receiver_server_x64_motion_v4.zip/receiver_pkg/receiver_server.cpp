// ============================================================================
// receiver_server.cpp
//
// Listens on a hardcoded localhost:port TCP socket and reconstructs the
// sender's screen frame by frame, using either of two message shapes the
// sender picks per-frame:
//
//   MSG_FRAME_FULL + MSG_BASE + MSG_ENH   -- whole frame, via the scalable
//     image codec (MJPEG base + FFV1 lossless residual).
//   MSG_FRAME_DELTA                        -- a single message whose payload
//     is [rect_x][rect_y][rect_w][rect_h] + LZ4-compressed BGRA bytes of
//     just that one rectangle -- the bounding box of everything that
//     changed since the previous frame (see diff_detector.h on the sender
//     side). rect_w/rect_h == 0 means nothing changed at all.
//
// A persistent BGRA "canvas" is maintained across frames at SOURCE
// resolution: a full-frame message overwrites it entirely, a delta message
// overwrites only the one rectangle that was sent, leaving everything else
// exactly as it was.
//
// On top of that sits a second, larger buffer -- the "master canvas" -- at
// kUpscaleFactor times source resolution. This is what actually gets
// published/written. A full-frame update triggers an expensive FSRCNN-s
// pass (ai_upscaler.h) over the whole raw canvas to rebuild the master
// canvas from scratch. A delta update instead cheap-upscales (bicubic)
// just the changed rectangle and feather-pastes it onto the master canvas,
// with a periodic full FSRCNN-s re-pass (kStalenessRefreshInterval) so
// regions that only ever got cheap patches don't permanently stay soft.
// See ai_upscaler.h for the full rationale.
//
// Each reconstructed/updated frame is emitted as a standalone image (BMP)
// rather than muxed into a video file, since this is live transmission.
//
// Build (MSVC, x64) -- see build.bat for the full command with all paths;
// summary:
//   cl /std:c++20 /EHsc receiver_server.cpp architecture.cpp simd_residual.cpp ^
//      fsrcnn.cc fsrcnn_params.cc ai_upscaler.cpp lz4.c ^
//      /I . /I third_party\eigen /I<ffmpeg_include> /I<opencv_include> ^
//      /link /LIBPATH:<ffmpeg_lib> /LIBPATH:<opencv_lib> ^
//      avcodec.lib avutil.lib swscale.lib ws2_32.lib ^
//      opencv_world4XX.lib third_party\tensorconv\lib\x64\Release\TensorConv.lib
//
// Architecture:
//   - Network/decode thread: reads the socket (recvMessage() loops recv()
//     until a full header+payload has arrived, so a message split across
//     multiple TCP segments is handled correctly -- see TcpReceiver below),
//     applies full-frame or delta-rect updates to the canvas as they
//     complete, and publishes the resulting BGRA canvas into a
//     pre-allocated triple buffer -- mirroring the sender's zero-alloc,
//     non-blocking hand-off pattern so slow disk I/O never stalls the
//     socket read loop. A delta frame with an empty rect (screen
//     unchanged) is never published at all, so a static desktop costs the
//     writer thread nothing.
//   - Writer thread: claims the latest published canvas and writes it out
//     as frame_%06lld.bmp into the output directory.
// ============================================================================

#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>

#include <atomic>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <thread>
#include <vector>

#include "codec_common.h"
#include "wire_protocol.h"
#include "bandwidth_tracker.h"
#include "thread_affinity.h"
#include "core_pin_planner.h"
#include "rdtsc_receiver_timing.h"
#include "lz4_rect_codec.h"
#include "ai_upscaler.h"

namespace fs = std::filesystem;

// ----------------------------------------------------------------------------
// AI-upscale configuration. The wire protocol has no notion of an "output"
// resolution (MSG_CONFIG only carries the sender's real capture size), so the
// upscale factor is a receiver-side constant. Must be 2 or 3 -- see fsrcnn.h
// for why. 2 is the common case (e.g. 1920x1080 source -> exact 3840x2160/4K
// master canvas).
constexpr int kUpscaleFactor = 2;

// Which FullFrameUpscale backend to use -- see ai_upscaler.h for the
// tradeoffs. kOpenCLiGpu automatically falls back to kCpuEigen at runtime
// if OpenCL (or the models\fsrcnn_s_x{2,3}.pb file it needs) isn't
// available, so it's safe to leave this set even on a machine without a
// usable integrated GPU.
constexpr aiup::Backend kUpscaleBackend = aiup::Backend::kOpenCLiGpu;

// How often the master canvas gets a full, non-cheap FSRCNN-s re-pass so
// regions that only ever received cheap bicubic delta patches don't
// permanently stay soft. At 24fps this comfortably fits the frame budget.
// Matches the sender's kTargetFps/kFramePeriod exactly -- the receiver
// doesn't control frame rate itself (it's driven by whatever arrives off
// the wire), but its own per-frame work still needs to fit inside the same
// budget for the end-to-end pipeline to actually hold at 24fps.
constexpr double kTargetFps = 24.0;
constexpr double kFramePeriodMs = 1000.0 / kTargetFps; // ~41.67ms

constexpr auto kStalenessRefreshInterval = std::chrono::milliseconds(1500);

// ----------------------------------------------------------------------------
// Same triple-buffer pattern as the sender: the decode thread never blocks
// on the writer thread, and the writer thread never blocks the decode/socket
// thread. No allocation in either thread's steady-state hot path.
// ----------------------------------------------------------------------------
class TripleBuffer {
public:
    void init(size_t bytesPerFrame) {
        for (auto &b : buf_) b.assign(bytesPerFrame, 0);
    }
    uint8_t *writeSlot() { return buf_[writeIndex_].data(); }
    void publish(int64_t frameIndex) {
        readyIndex_.store(writeIndex_, std::memory_order_release);
        readyFrameIndex_.store(frameIndex, std::memory_order_release);
        writeIndex_ = (writeIndex_ + 1) % 3;
        if (writeIndex_ == readIndex_.load(std::memory_order_acquire))
            writeIndex_ = (writeIndex_ + 1) % 3;
    }
    const uint8_t *claimLatest(int64_t &outFrameIndex) {
        int idx = readyIndex_.load(std::memory_order_acquire);
        int64_t fi = readyFrameIndex_.load(std::memory_order_acquire);
        if (fi == lastConsumed_) return nullptr;
        lastConsumed_ = fi;
        readIndex_.store(idx, std::memory_order_release);
        outFrameIndex = fi;
        return buf_[idx].data();
    }
private:
    std::vector<uint8_t> buf_[3];
    int writeIndex_ = 0;
    std::atomic<int> readIndex_{0};
    std::atomic<int> readyIndex_{-1};
    std::atomic<int64_t> readyFrameIndex_{-1};
    int64_t lastConsumed_ = -1;
};

// ----------------------------------------------------------------------------
// Writes a tightly packed top-down BGRA8 buffer out as a standard (bottom-up)
// 32-bit BMP -- the most broadly viewable option for a plain still image.
// ----------------------------------------------------------------------------
static void writeBmp(const fs::path &path, const uint8_t *bgraTopDown, int w, int h) {
    const int rowBytes = w * 4;
    const uint32_t pixelDataSize = static_cast<uint32_t>(rowBytes) * h;
    const uint32_t fileSize = 14 + 40 + pixelDataSize;

    std::vector<uint8_t> header(14 + 40);
    uint8_t *p = header.data();
    p[0] = 'B'; p[1] = 'M';
    std::memcpy(p + 2, &fileSize, 4);
    uint32_t zero = 0; std::memcpy(p + 6, &zero, 4);
    uint32_t dataOffset = 14 + 40; std::memcpy(p + 10, &dataOffset, 4);

    uint32_t dibSize = 40; std::memcpy(p + 14, &dibSize, 4);
    int32_t width = w; std::memcpy(p + 18, &width, 4);
    int32_t height = h; std::memcpy(p + 22, &height, 4); // positive: bottom-up
    uint16_t planes = 1; std::memcpy(p + 26, &planes, 2);
    uint16_t bpp = 32; std::memcpy(p + 28, &bpp, 2);
    uint32_t compression = 0; std::memcpy(p + 30, &compression, 4);
    std::memcpy(p + 34, &pixelDataSize, 4);
    int32_t ppm = 2835; std::memcpy(p + 38, &ppm, 4);
    std::memcpy(p + 42, &ppm, 4);
    uint32_t zero2 = 0; std::memcpy(p + 46, &zero2, 4);
    std::memcpy(p + 50, &zero2, 4);

    FILE *f = nullptr;
    if (_wfopen_s(&f, path.c_str(), L"wb") != 0 || !f) return;
    std::fwrite(header.data(), 1, header.size(), f);
    // BMP rows are bottom-up; our source buffer is top-down, so reverse row order.
    for (int y = h - 1; y >= 0; --y)
        std::fwrite(bgraTopDown + static_cast<size_t>(y) * rowBytes, 1, rowBytes, f);
    std::fclose(f);
}

// ----------------------------------------------------------------------------
// Minimal blocking TCP server: accepts exactly one connection (one live
// sender), per the hardcoded localhost pairing with sender_client.cpp.
// ----------------------------------------------------------------------------
class TcpReceiver {
public:
    TcpReceiver() {
        WSADATA wsaData;
        if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
            throw std::runtime_error("WSAStartup failed");
    }
    ~TcpReceiver() {
        if (client_ != INVALID_SOCKET) closesocket(client_);
        if (listenSock_ != INVALID_SOCKET) closesocket(listenSock_);
        WSACleanup();
    }

    void listenAndAccept() {
        listenSock_ = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
        if (listenSock_ == INVALID_SOCKET) throw std::runtime_error("socket() failed");

        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(endpoint::PORT);
        inet_pton(AF_INET, endpoint::HOST, &addr.sin_addr); // hardcoded 127.0.0.1

        int one = 1;
        setsockopt(listenSock_, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<const char *>(&one), sizeof(one));

        if (bind(listenSock_, reinterpret_cast<sockaddr *>(&addr), sizeof(addr)) != 0)
            throw std::runtime_error("bind() failed");
        if (listen(listenSock_, 1) != 0)
            throw std::runtime_error("listen() failed");

        std::fprintf(stderr, "[receiver] listening on %s:%u ...\n", endpoint::HOST, endpoint::PORT);
        client_ = accept(listenSock_, nullptr, nullptr);
        if (client_ == INVALID_SOCKET) throw std::runtime_error("accept() failed");

        int nodelay = 1;
        setsockopt(client_, IPPROTO_TCP, TCP_NODELAY, reinterpret_cast<const char *>(&nodelay), sizeof(nodelay));
        std::fprintf(stderr, "[receiver] sender connected\n");
    }

    // Returns false on clean disconnect.
    bool recvMessage(wire::Header &outHeader, std::vector<uint8_t> &outPayload) {
        uint8_t hdr[wire::HEADER_SIZE];
        if (!recvAll(hdr, sizeof(hdr))) return false;
        outHeader = wire::Header::parse(hdr);
        outPayload.resize(outHeader.payloadSize);
        if (outHeader.payloadSize && !recvAll(outPayload.data(), outHeader.payloadSize)) return false;
        return true;
    }

private:
    SOCKET listenSock_ = INVALID_SOCKET;
    SOCKET client_ = INVALID_SOCKET;

    bool recvAll(uint8_t *data, size_t size) {
        size_t got = 0;
        while (got < size) {
            int rc = recv(client_, reinterpret_cast<char *>(data) + got,
                           static_cast<int>(size - got), 0);
            if (rc <= 0) return false; // 0 = clean close, <0 = error
            got += static_cast<size_t>(rc);
        }
        return true;
    }
};

int main() {
    const fs::path outDir = "received_frames";
    fs::create_directories(outDir);

    try {
        TcpReceiver server;
        server.listenAndAccept();

        // ---- Handshake: read MSG_CONFIG before anything else. ----
        wire::Header hdr;
        std::vector<uint8_t> payload;
        if (!server.recvMessage(hdr, payload) || hdr.type != wire::MSG_CONFIG)
            throw std::runtime_error("expected MSG_CONFIG as first message");
        auto cfg = wire::parseConfigPayload(payload);
        std::fprintf(stderr, "[receiver] full %dx%d, base %dx%d, dirty-detection block %dpx (%dx%d grid, sender-side only)\n",
                     cfg.fullW, cfg.fullH, cfg.lowW, cfg.lowH, cfg.tileSize, cfg.tilesX, cfg.tilesY);

        scalcodec::FrameCodec fullCodec;
        // lowW/lowH are re-derived deterministically from fullW/fullH/targetHeight
        // on both sides via computeLowRes(), so passing the received cfg.lowH as
        // the target height reproduces the identical low-res dimensions.
        fullCodec.init(scalcodec::FrameCodec::Side::Receiver, cfg.fullW, cfg.fullH, cfg.lowH);

        aiup::Upscaler upscaler(kUpscaleFactor, kUpscaleBackend, "models");
        const int masterW = cfg.fullW * kUpscaleFactor;
        const int masterH = cfg.fullH * kUpscaleFactor;
        std::fprintf(stderr, "[receiver] AI upscaling %dx%d -> %dx%d (FSRCNN-s x%d, %s backend, staleness refresh every %lldms)\n",
                     cfg.fullW, cfg.fullH, masterW, masterH, kUpscaleFactor,
                     upscaler.backend() == aiup::Backend::kOpenCLiGpu ? "OpenCL/iGPU" : "CPU/Eigen",
                     static_cast<long long>(kStalenessRefreshInterval.count()));

        // The triple buffer (and everything the writer thread sees) now
        // carries the *upscaled* master canvas, not the raw source frame.
        TripleBuffer tripleBuf;
        tripleBuf.init(static_cast<size_t>(masterW) * masterH * 4);

        // Zero-alloc scratch for the delta-rect path: worst case a
        // rectangle covers the whole frame, so size for that once, up
        // front, and never resize on the hot path.
        const size_t maxRectBytes = static_cast<size_t>(cfg.fullW) * cfg.fullH * 4;
        std::vector<uint8_t> rectDecompressScratch(maxRectBytes, 0);

        std::atomic<bool> running{true};

        // Shared by both hot threads below -- constructed once so its core
        // count query and "avoid core 0" plan happen a single time, and so
        // AssignNextCore()'s round-robin actually spreads the two threads
        // across distinct cores when enough are available, rather than
        // each thread separately guessing a hardcoded index.
        threadutil::CorePinPlanner corePinPlanner;
        timing::ReceiveBudgetTracker budgetTracker(kTargetFps);

        // Pins the CURRENT thread -- i.e. this decode/reconstruct loop,
        // which does diff-application, LZ4 decompress, and AI upscaling --
        // to its planner-assigned core, before falling into the main loop.
        threadutil::PinCurrentThreadToCore(
            corePinPlanner.AssignNextCore("receiver decode/reconstruct thread"),
            "receiver decode/reconstruct thread");

        // ---- Writer thread: claims latest reconstructed frame, writes BMP.
        // Only frames that actually changed get published (see the decode
        // loop below), so this thread -- and disk I/O -- naturally goes
        // idle whenever the screen is static. ----
        std::thread writer([&]() {
            // Requests its own core from the SAME planner -- on a machine
            // with 3+ cores available, this naturally lands on a different
            // core than the decode/reconstruct thread above (round-robin);
            // on a 2-core machine, both correctly share the single
            // preferred (non-zero) core rather than the plan breaking.
            threadutil::PinCurrentThreadToCore(
                corePinPlanner.AssignNextCore("receiver writer thread"),
                "receiver writer thread");

            while (running.load(std::memory_order_relaxed)) {
                int64_t fi;
                const uint8_t *bgra = tripleBuf.claimLatest(fi);
                if (!bgra) {
                    std::this_thread::sleep_for(std::chrono::milliseconds(1));
                    continue;
                }
                char name[64];
                std::snprintf(name, sizeof(name), "frame_%06lld.bmp", static_cast<long long>(fi));
                writeBmp(outDir / name, bgra, masterW, masterH);
                std::fprintf(stderr, "[receiver] wrote %s\n", name);
            }
        });

        // ---- Persistent canvas: the running reconstruction of the sender's
        // screen. A full-frame message overwrites it entirely; a delta
        // message overwrites only the single rectangle that was actually
        // sent, so an unchanged region simply keeps whatever pixels were
        // already there from a previous frame. ----
        std::vector<uint8_t> canvas(static_cast<size_t>(cfg.fullW) * cfg.fullH * 4, 0);
        const int strideBytes = cfg.fullW * 4;

        // The master (upscaled) canvas -- this is what actually gets
        // published/written. It starts as a full FSRCNN-s upscale of
        // `canvas` the first time `canvas` is fully populated (see
        // MSG_FRAME_FULL handling below), then gets touched two ways:
        // cheap bicubic-patched per delta rect, or fully redone on the
        // periodic staleness refresh.
        std::vector<uint8_t> masterCanvas(static_cast<size_t>(masterW) * masterH * 4, 0);
        auto lastFullRefresh = std::chrono::steady_clock::now();

        enum class Mode { None, Full, Delta };
        Mode mode = Mode::None;
        int64_t currentFrame = -1;
        std::vector<uint8_t> baseBuf, enhBuf;
        bool haveBase = false, haveEnh = false;

        auto publishCanvas = [&](int64_t fi) {
            std::memcpy(tripleBuf.writeSlot(), masterCanvas.data(), masterCanvas.size());
            tripleBuf.publish(fi);
        };

        // Full, expensive FSRCNN-s pass over the whole current `canvas`,
        // replacing `masterCanvas` entirely. Used for the first frame and
        // for the periodic staleness refresh.
        auto refreshMasterFull = [&]() {
            upscaler.FullFrameUpscale(canvas.data(), cfg.fullW, cfg.fullH, masterCanvas.data());
            lastFullRefresh = std::chrono::steady_clock::now();
        };

        // Applies a batch of copy rects (content the sender's motion
        // detector found already existed elsewhere in the previous frame
        // -- see motion_detector.h on the sender side) to BOTH canvases.
        //
        // Two-phase (extract ALL sources first, then write ALL
        // destinations) rather than copy-rect-by-copy-rect: if this
        // message carries more than one copy rect and two of them happen
        // to have overlapping src/dst regions (e.g. two unrelated moving
        // elements in the same frame), applying them one at a time could
        // let a later rect read data an earlier rect already overwrote --
        // wrong output that would never show up in the earlier
        // single-copy-rect testing this went through. Extracting
        // everything up front against the untouched starting canvas
        // guarantees the whole batch behaves as one atomic transform,
        // matching what the sender actually computed it against.
        //
        // This does mean a small (bounded by copyRects.size(), not by
        // pixel count) amount of per-message heap allocation -- a
        // deliberate, disclosed departure from this file's otherwise
        // zero-alloc hot path, traded for batch correctness. Copy rect
        // counts per frame are small (a handful, from coalescing -- see
        // motion_detector.cpp), so this is not a meaningful cost.
        //
        // The master-canvas copy is the free synergy with the AI upscaler:
        // masterCanvas already holds valid, already-upscaled pixels for
        // the OLD position of any moved content (that's what "moved"
        // means -- same pixels, different place), so copying at the
        // scaled position reproduces correct upscaled output with ZERO
        // upscaling work for that region -- cheaper even than the cheap
        // bicubic path used for genuinely new content.
        auto applyCopyRects = [&](const std::vector<wire::CopyRect> &copyRects) -> bool {
            for (const auto &cr : copyRects) {
                if (cr.w == 0 || cr.h == 0 ||
                    cr.srcX + cr.w > static_cast<uint32_t>(cfg.fullW) || cr.srcY + cr.h > static_cast<uint32_t>(cfg.fullH) ||
                    cr.dstX + cr.w > static_cast<uint32_t>(cfg.fullW) || cr.dstY + cr.h > static_cast<uint32_t>(cfg.fullH)) {
                    std::fprintf(stderr, "[receiver] copy rect (%u,%u)->(%u,%u) %ux%u out of canvas bounds, dropping delta\n",
                                 cr.srcX, cr.srcY, cr.dstX, cr.dstY, cr.w, cr.h);
                    return false;
                }
            }

            const int scale = upscaler.scale();
            const int masterStrideBytes = masterW * 4;

            std::vector<std::vector<uint8_t>> canvasExtract(copyRects.size());
            std::vector<std::vector<uint8_t>> masterExtract(copyRects.size());

            // Phase 1: extract every source region from the untouched canvases.
            for (size_t i = 0; i < copyRects.size(); ++i) {
                const auto &cr = copyRects[i];
                const int rowBytes = static_cast<int>(cr.w) * 4;
                canvasExtract[i].resize(static_cast<size_t>(rowBytes) * cr.h);
                for (uint32_t row = 0; row < cr.h; ++row) {
                    const uint8_t *srcRow = canvas.data() + static_cast<size_t>(cr.srcY + row) * strideBytes
                                                           + static_cast<size_t>(cr.srcX) * 4;
                    std::memcpy(canvasExtract[i].data() + static_cast<size_t>(row) * rowBytes, srcRow, rowBytes);
                }

                const int mw = static_cast<int>(cr.w) * scale, mh = static_cast<int>(cr.h) * scale;
                const int mSrcX = static_cast<int>(cr.srcX) * scale, mSrcY = static_cast<int>(cr.srcY) * scale;
                const int mRowBytes = mw * 4;
                masterExtract[i].resize(static_cast<size_t>(mRowBytes) * mh);
                for (int row = 0; row < mh; ++row) {
                    const uint8_t *srcRow = masterCanvas.data() + static_cast<size_t>(mSrcY + row) * masterStrideBytes
                                                                 + static_cast<size_t>(mSrcX) * 4;
                    std::memcpy(masterExtract[i].data() + static_cast<size_t>(row) * mRowBytes, srcRow, mRowBytes);
                }
            }

            // Phase 2: write every destination region.
            for (size_t i = 0; i < copyRects.size(); ++i) {
                const auto &cr = copyRects[i];
                const int rowBytes = static_cast<int>(cr.w) * 4;
                for (uint32_t row = 0; row < cr.h; ++row) {
                    uint8_t *dstRow = canvas.data() + static_cast<size_t>(cr.dstY + row) * strideBytes
                                                     + static_cast<size_t>(cr.dstX) * 4;
                    std::memcpy(dstRow, canvasExtract[i].data() + static_cast<size_t>(row) * rowBytes, rowBytes);
                }

                const int mw = static_cast<int>(cr.w) * scale, mh = static_cast<int>(cr.h) * scale;
                const int mDstX = static_cast<int>(cr.dstX) * scale, mDstY = static_cast<int>(cr.dstY) * scale;
                const int mRowBytes = mw * 4;
                for (int row = 0; row < mh; ++row) {
                    uint8_t *dstRow = masterCanvas.data() + static_cast<size_t>(mDstY + row) * masterStrideBytes
                                                           + static_cast<size_t>(mDstX) * 4;
                    std::memcpy(dstRow, masterExtract[i].data() + static_cast<size_t>(row) * mRowBytes, mRowBytes);
                }
            }
            return true;
        };

        BandwidthTracker bandwidth;

        while (true) {
            // recvMessage() internally loops recv() until the full header
            // and payload have arrived (see TcpReceiver::recvAll below) --
            // TCP makes no guarantee a single recv() call returns a whole
            // message, so every read here is already boundary-safe.
            if (!server.recvMessage(hdr, payload)) break; // sender disconnected
            if (hdr.type == wire::MSG_END) break;

            bandwidth.recordMessage(hdr.type, wire::HEADER_SIZE, payload.size());

            switch (hdr.type) {
                case wire::MSG_FRAME_FULL:
                    mode = Mode::Full;
                    currentFrame = hdr.frameIndex;
                    haveBase = haveEnh = false;
                    break;

                case wire::MSG_FRAME_DELTA: {
                    mode = Mode::Delta;
                    currentFrame = hdr.frameIndex;

                    std::vector<wire::CopyRect> copyRects;
                    size_t bytesConsumed = 0;
                    if (!wire::parseCopyRects(payload.data(), payload.size(), copyRects, &bytesConsumed)) {
                        std::fprintf(stderr, "[receiver] frame %lld: malformed delta payload (copy-rect list)\n",
                                     static_cast<long long>(currentFrame));
                        break;
                    }
                    if (payload.size() - bytesConsumed < wire::RECT_HEADER_SIZE) {
                        std::fprintf(stderr, "[receiver] frame %lld: malformed delta payload (too short for rect header)\n",
                                     static_cast<long long>(currentFrame));
                        break;
                    }
                    auto rect = wire::parseRawRectHeaderAt(payload.data() + bytesConsumed);

                    // Breaks out what portion of THIS delta's bytes were
                    // copy-rect instructions (motion, ~0 pixels) vs the
                    // trailing leftover payload (genuinely new pixels) --
                    // bytesConsumed already covers the copy-rect list, so
                    // everything after it (rect header + any LZ4 bytes) is
                    // the leftover share.
                    bandwidth.recordDeltaBreakdown(bytesConsumed, payload.size() - bytesConsumed);

                    if (copyRects.empty() && (rect.rectW == 0 || rect.rectH == 0)) {
                        // Screen unchanged since last frame: nothing to
                        // decompress, nothing new to write, nothing moved
                        // either -- this is the whole point of delta mode
                        // (a static desktop or a mouse-only frame costs
                        // essentially zero bytes and zero receiver work).
                        std::fprintf(stderr, "[receiver] frame %lld unchanged (empty payload)\n",
                                     static_cast<long long>(currentFrame));
                        break;
                    }

                    // Apply any copy rects (moved content) first -- see
                    // applyCopyRects' own comment for why this is a batch,
                    // not one-at-a-time, and why it also updates
                    // masterCanvas directly at zero upscaling cost.
                    if (!copyRects.empty() && !applyCopyRects(copyRects)) {
                        break; // malformed/out-of-bounds copy rect; whole delta dropped, same posture as the raw-rect bounds check below
                    }

                    if (rect.rectW == 0 || rect.rectH == 0) {
                        // Pure motion this frame -- every dirty pixel was
                        // explained by a copy rect, nothing genuinely new
                        // to paint. Still need to publish, since the
                        // copy(s) above did change the canvas.
                        publishCanvas(currentFrame);
                        break;
                    }

                    // Bounds-check against the canvas before touching memory --
                    // a corrupt/malicious rect_x+rect_w exceeding cfg.fullW
                    // would otherwise write past the canvas buffer.
                    if (rect.rectX < 0 || rect.rectY < 0 ||
                        rect.rectX + rect.rectW > cfg.fullW || rect.rectY + rect.rectH > cfg.fullH) {
                        std::fprintf(stderr, "[receiver] frame %lld: rect (%d,%d %dx%d) out of canvas bounds, dropped\n",
                                     static_cast<long long>(currentFrame), rect.rectX, rect.rectY, rect.rectW, rect.rectH);
                        break;
                    }

                    const uint8_t *compressed = payload.data() + bytesConsumed + wire::RECT_HEADER_SIZE;
                    const size_t compressedSize = payload.size() - bytesConsumed - wire::RECT_HEADER_SIZE;
                    const size_t rawRectBytes = static_cast<size_t>(rect.rectW) * 4 * rect.rectH;

                    try {
                        // Timed: LZ4 decompress + row-paste together, one
                        // "delta apply" line item -- separate from the
                        // upscale work that follows. Nested block so the
                        // RAII timer ends here, not at the outer try's end.
                        {
                            auto _timingScope = budgetTracker.scope(timing::RECV_DELTA_APPLY);
                            lz4rect::DecompressRect(compressed, compressedSize,
                                                     rectDecompressScratch.data(), rawRectBytes);

                            // Paste: one memcpy per row (the canvas's stride
                            // and the rect's packed width differ in the general
                            // case, so a single whole-rect memcpy only works
                            // when rect.rectW == cfg.fullW; row-by-row is the
                            // correct general form and is still O(height) calls,
                            // not O(width*height)).
                            const int rectRowBytes = rect.rectW * 4;
                            for (int row = 0; row < rect.rectH; ++row) {
                                uint8_t *dstRow = canvas.data() + static_cast<size_t>(rect.rectY + row) * strideBytes
                                                                 + static_cast<size_t>(rect.rectX) * 4;
                                const uint8_t *srcRow = rectDecompressScratch.data() + static_cast<size_t>(row) * rectRowBytes;
                                std::memcpy(dstRow, srcRow, rectRowBytes);
                            }
                        }

                        // Cheap path: bicubic-upscale just this rectangle
                        // from the raw canvas and feather-paste it onto the
                        // master canvas -- no FSRCNN-s call here, this is
                        // the ~1.1ms case.
                        {
                        auto _timingScope = budgetTracker.scope(timing::RECV_CHEAP_UPSCALE);
                        auto cheapRect = upscaler.CheapRectUpscale(canvas.data(), strideBytes,
                                                                    rect.rectX, rect.rectY, rect.rectW, rect.rectH);
                        upscaler.FeatherPasteRect(masterCanvas.data(), masterW, masterH,
                                                   rect.rectX, rect.rectY, rect.rectW, rect.rectH, cheapRect);
                        }

                        // Staleness fix: if enough time has passed since the
                        // last full FSRCNN-s pass, redo the whole canvas now
                        // instead of publishing the cheap-only patch, so
                        // regions that have been living on bicubic scaling
                        // for a while get sharpened back up. 24fps gives
                        // enough per-frame budget (41.6ms) to absorb this
                        // occasional ~21ms cost.
                        if (std::chrono::steady_clock::now() - lastFullRefresh >= kStalenessRefreshInterval) {
                            auto _timingScope = budgetTracker.scope(timing::RECV_FULL_UPSCALE);
                            refreshMasterFull();
                        }

                        publishCanvas(currentFrame);
                    } catch (const std::exception &ex) {
                        std::fprintf(stderr, "[receiver] frame %lld rect decode failed: %s\n",
                                     static_cast<long long>(currentFrame), ex.what());
                    }
                    break;
                }

                case wire::MSG_BASE:
                    baseBuf = std::move(payload);
                    haveBase = true;
                    break;

                case wire::MSG_ENH:
                    enhBuf = std::move(payload);
                    haveEnh = true;
                    if (haveBase && haveEnh && mode == Mode::Full) {
                        try {
                            {
                                auto _timingScope = budgetTracker.scope(timing::RECV_DECODE);
                                fullCodec.decodeFrame(baseBuf, enhBuf, canvas.data(), strideBytes);
                            }
                            // Full frames are relatively rare (first frame,
                            // or a mostly-changed screen) -- always worth
                            // the full FSRCNN-s cost so the whole canvas is
                            // AI-sharp again, not just the delta-patched bits.
                            {
                                auto _timingScope = budgetTracker.scope(timing::RECV_FULL_UPSCALE);
                                refreshMasterFull();
                            }
                            publishCanvas(currentFrame);
                        } catch (const std::exception &ex) {
                            std::fprintf(stderr, "[receiver] frame %lld (full) failed to decode: %s\n",
                                         static_cast<long long>(currentFrame), ex.what());
                        }
                    }
                    break;

                default:
                    break;
            }

            bandwidth.report(currentFrame);
            budgetTracker.maybeReport(currentFrame, kFramePeriodMs);
        }

        running.store(false, std::memory_order_relaxed);
        writer.join();
        std::fprintf(stderr, "[receiver] connection closed, exiting\n");
    } catch (const std::exception &ex) {
        std::fprintf(stderr, "[receiver] fatal: %s\n", ex.what());
        return 1;
    }
    return 0;
}
