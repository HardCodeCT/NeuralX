// ============================================================================
// wire_protocol.h
//
// Minimal framing over a plain, reliable TCP byte stream (Winsock on both
// sender and receiver).
//
// Every message:
//   uint8_t   type            (see MsgType)
//   int64_t   frame_index     (big-endian)
//   uint32_t  tile_index      (big-endian; unused/0 for every message type
//                               below -- kept in the header for wire
//                               compatibility, but delta frames now carry
//                               their position in the payload instead, see
//                               below)
//   uint32_t  payload_size    (big-endian)
//   <payload_size> bytes
//
// Two ways a frame can be transmitted, chosen per-frame by the sender based
// on how much of the screen actually changed:
//
//   FULL FRAME  (first frame, or a frame where most of the screen changed):
//     MSG_FRAME_FULL(frame_index)
//     MSG_BASE(frame_index)   -- MJPEG low-res
//     MSG_ENH(frame_index)    -- FFV1 lossless residual, full res
//
//   DELTA FRAME (only some 8x8 blocks changed -- the common case: typing,
//   mouse moves, a small UI update, or content that just MOVED -- a dragged
//   window, a scroll). Always exactly ONE message. Payload is now two parts:
//
//     MSG_FRAME_DELTA(frame_index), payload =
//         uint32 numCopyRects
//         numCopyRects x { uint32 srcX, srcY, dstX, dstY, w, h }
//         uint32 rect_x, rect_y, rect_w, rect_h
//         <LZ4-compressed BGRA bytes of that rect, tightly packed>
//                (present only if rect_w > 0 && rect_h > 0)
//
//   The copy-rect list carries content the sender's motion detector
//   (motion_detector.h, sender-side only) found already present somewhere
//   else in the PREVIOUS frame -- i.e. content that moved rather than
//   changed. Each entry means "the receiver's own canvas already has this
//   content at (srcX,srcY); copy it to (dstX,dstY)" -- zero new pixel bytes
//   over the wire for that region, just 24 bytes of coordinates. The
//   trailing rect (identical format to the original single-rect design)
//   carries whatever's left over: genuinely new pixel content the motion
//   detector couldn't explain as a copy. rect_w==0 (and no compressed data
//   following) means "no new pixels this frame" -- can happen alongside a
//   non-empty copy-rect list (pure motion, nothing new) or, in the fully
//   static case, alongside an EMPTY copy-rect list too (nothing changed at
//   all -- see buildEmptyDeltaPayload()).
//
// MSG_TILE is kept in the enum only so old captures/logs referencing it
// still name a real value; the current sender/receiver pair never emits or
// expects it.
// ============================================================================
#pragma once

#include <cstdint>
#include <vector>
#include <cstring>

namespace wire {

enum MsgType : uint8_t {
    MSG_CONFIG      = 1,  // payload: fullW(4) fullH(4) lowW(4) lowH(4) blockSize(4) blocksX(4) blocksY(4)
    MSG_BASE        = 2,  // payload: one MJPEG-encoded low-res frame (full-frame mode)
    MSG_ENH         = 3,  // payload: one FFV1-encoded full-res residual frame (full-frame mode)
    MSG_TILE        = 4,  // unused by the current pipeline; reserved
    MSG_FRAME_FULL  = 5,  // payload: empty; marks frame_index as full-frame mode, BASE+ENH follow
    MSG_FRAME_DELTA = 6,  // payload: copy-rect list + rect_x,rect_y,rect_w,rect_h + LZ4 rect bytes (see above)
    MSG_END         = 7,  // payload: empty
};

constexpr uint32_t NO_TILE = 0xFFFFFFFFu;

inline void putU32(std::vector<uint8_t> &b, uint32_t v) {
    b.push_back(uint8_t((v >> 24) & 0xFF)); b.push_back(uint8_t((v >> 16) & 0xFF));
    b.push_back(uint8_t((v >> 8) & 0xFF));  b.push_back(uint8_t(v & 0xFF));
}
inline uint32_t getU32(const uint8_t *p) {
    return (uint32_t(p[0]) << 24) | (uint32_t(p[1]) << 16) | (uint32_t(p[2]) << 8) | uint32_t(p[3]);
}

// Fixed 17-byte header: type(1) + frame_index(8) + tile_index(4) + payload_size(4).
struct Header {
    uint8_t type;
    int64_t frameIndex;
    uint32_t tileIndex = NO_TILE;
    uint32_t payloadSize;

    void serialize(uint8_t out[17]) const {
        out[0] = type;
        for (int i = 0; i < 8; ++i)
            out[1 + i] = uint8_t((uint64_t(frameIndex) >> ((7 - i) * 8)) & 0xFF);
        out[9]  = uint8_t((tileIndex >> 24) & 0xFF);
        out[10] = uint8_t((tileIndex >> 16) & 0xFF);
        out[11] = uint8_t((tileIndex >> 8) & 0xFF);
        out[12] = uint8_t(tileIndex & 0xFF);
        out[13] = uint8_t((payloadSize >> 24) & 0xFF);
        out[14] = uint8_t((payloadSize >> 16) & 0xFF);
        out[15] = uint8_t((payloadSize >> 8) & 0xFF);
        out[16] = uint8_t(payloadSize & 0xFF);
    }
    static Header parse(const uint8_t in[17]) {
        Header h;
        h.type = in[0];
        uint64_t fi = 0;
        for (int i = 0; i < 8; ++i) fi = (fi << 8) | in[1 + i];
        h.frameIndex = int64_t(fi);
        h.tileIndex = getU32(in + 9);
        h.payloadSize = getU32(in + 13);
        return h;
    }
};

constexpr int HEADER_SIZE = 17;

// ---- CONFIG payload: resolution + block grid, sent once at connect time. ----
inline std::vector<uint8_t> buildConfigPayload(int fullW, int fullH, int lowW, int lowH,
                                                int blockSize, int blocksX, int blocksY) {
    std::vector<uint8_t> b;
    putU32(b, uint32_t(fullW));   putU32(b, uint32_t(fullH));
    putU32(b, uint32_t(lowW));    putU32(b, uint32_t(lowH));
    putU32(b, uint32_t(blockSize));
    putU32(b, uint32_t(blocksX)); putU32(b, uint32_t(blocksY));
    return b;
}
struct ParsedConfig { int fullW, fullH, lowW, lowH, tileSize, tilesX, tilesY; };
inline ParsedConfig parseConfigPayload(const std::vector<uint8_t> &p) {
    ParsedConfig c;
    c.fullW = int(getU32(&p[0]));  c.fullH = int(getU32(&p[4]));
    c.lowW  = int(getU32(&p[8]));  c.lowH  = int(getU32(&p[12]));
    c.tileSize = int(getU32(&p[16]));
    c.tilesX = int(getU32(&p[20])); c.tilesY = int(getU32(&p[24]));
    return c;
}

// ---- Copy-rect list: "receiver, copy your own canvas content from
// (srcX,srcY) to (dstX,dstY)" -- content the sender's motion detector
// found already existed somewhere in the previous frame, so no new pixel
// bytes need to cross the wire for it. ----
struct CopyRect {
    uint32_t srcX, srcY, dstX, dstY, w, h;
};
constexpr size_t COPY_RECT_SIZE = 24; // 6 x uint32
constexpr size_t COPY_RECT_COUNT_SIZE = 4; // uint32 count prefix

inline void putCopyRects(std::vector<uint8_t> &out, const std::vector<CopyRect> &rects) {
    putU32(out, uint32_t(rects.size()));
    for (const auto &r : rects) {
        putU32(out, r.srcX); putU32(out, r.srcY);
        putU32(out, r.dstX); putU32(out, r.dstY);
        putU32(out, r.w);    putU32(out, r.h);
    }
}

// Parses the copy-rect list starting at p (which must have at least
// availableBytes valid bytes after it). Returns false (and leaves outRects
// untouched) if the declared count would run past availableBytes -- caller
// should treat that as a malformed payload, same as the existing
// too-short-payload checks elsewhere in this protocol. On success,
// *outBytesConsumed is set to COPY_RECT_COUNT_SIZE + count*COPY_RECT_SIZE,
// i.e. the offset where the trailing raw-rect header begins.
inline bool parseCopyRects(const uint8_t *p, size_t availableBytes,
                            std::vector<CopyRect> &outRects, size_t *outBytesConsumed) {
    if (availableBytes < COPY_RECT_COUNT_SIZE) return false;
    const uint32_t count = getU32(p);
    const size_t needed = COPY_RECT_COUNT_SIZE + size_t(count) * COPY_RECT_SIZE;
    if (needed > availableBytes) return false; // malformed/truncated -- bail before reading OOB

    outRects.clear();
    outRects.reserve(count);
    const uint8_t *q = p + COPY_RECT_COUNT_SIZE;
    for (uint32_t i = 0; i < count; ++i) {
        CopyRect r;
        r.srcX = getU32(q + 0);  r.srcY = getU32(q + 4);
        r.dstX = getU32(q + 8);  r.dstY = getU32(q + 12);
        r.w    = getU32(q + 16); r.h    = getU32(q + 20);
        outRects.push_back(r);
        q += COPY_RECT_SIZE;
    }
    *outBytesConsumed = needed;
    return true;
}

// ---- Trailing raw-rect header: rect header (16 bytes) + LZ4-compressed
// rect pixel bytes. rect_w/rect_h == 0 means "no new pixels, nothing
// follows". Same 16-byte layout as before; only its *offset* within the
// payload changed (it now comes after the copy-rect list, not at byte 0). ----
constexpr size_t RECT_HEADER_SIZE = 16; // 4 x uint32

// Empty delta: no copy rects, no new pixels -- the fully-static-frame case.
inline std::vector<uint8_t> buildEmptyDeltaPayload() {
    std::vector<uint8_t> b;
    putU32(b, 0); // numCopyRects = 0
    putU32(b, 0); putU32(b, 0); putU32(b, 0); putU32(b, 0); // x,y,w=0,h=0
    return b;
}
inline void appendRawRectHeader(std::vector<uint8_t> &out, int rectX, int rectY, int rectW, int rectH) {
    putU32(out, uint32_t(rectX)); putU32(out, uint32_t(rectY));
    putU32(out, uint32_t(rectW)); putU32(out, uint32_t(rectH));
    // caller appends the LZ4-compressed bytes after this call, if rectW/rectH > 0
}
struct ParsedDeltaHeader { int rectX, rectY, rectW, rectH; };
inline ParsedDeltaHeader parseRawRectHeaderAt(const uint8_t *p) {
    ParsedDeltaHeader h;
    h.rectX = int(getU32(p + 0));  h.rectY = int(getU32(p + 4));
    h.rectW = int(getU32(p + 8));  h.rectH = int(getU32(p + 12));
    return h;
}

} // namespace wire

// ---- Hardcoded endpoint. Change here if the loopback assumption ever needs
// to move off localhost; both sender and receiver include this same header
// so the two stay in sync automatically. ----
namespace endpoint {
    constexpr const char *HOST = "127.0.0.1";
    constexpr uint16_t    PORT = 5000;
}
