# receiver_server (x64 only)

## Contents
- `receiver_server.cpp` — listens on the hardcoded `127.0.0.1:5000`,
  maintains a persistent BGRA canvas at source resolution, applies
  full-frame overwrites or a single-rectangle delta patch as they arrive,
  drives the AI upscaler (below) to build a second "master canvas" at
  `kUpscaleFactor`x resolution, and writes each updated *master* frame to
  `received_frames\frame_000123.bmp`.
- `ai_upscaler.h` / `ai_upscaler.cpp` — the two-tier upscaling: an
  expensive full-frame FSRCNN-s pass (Y channel through the real net, Cb/Cr
  bicubic via OpenCV) for full-frame updates and the periodic staleness
  refresh; a cheap `cv::resize(INTER_CUBIC)` upscale + feathered paste for
  delta rectangles.
- `fsrcnn.h` / `fsrcnn.cc` — **copied verbatim** from
  `thinkerleolee/FSRCNN-OpenCV`: the `FSRCNN_FAST` (and `FSRCNN_NORMAL`,
  unused here) network classes, calling straight into `tensorconv::*`.
- `fsutils.h` — **copied verbatim** from that repo's `utils.h`: the
  `fsutils::SR()` driver (preprocess → `FSRCNN_FAST::SrOp` → recombine
  with bicubic chroma) that `ai_upscaler.cpp` calls into.
- `fsrcnn_params.h` / `fsrcnn_params.cc` — the trained FSRCNN-s weights
  (scale x2 and x3), copied unmodified from `thinkerleolee/FSRCNN-OpenCV`.
- `third_party/tensorconv/` — vendored from that repo: `tensorconv_ops.h`
  plus the prebuilt `TensorConv.lib` / `TensorConvd.lib` (Release/Debug,
  x64) that actually implement Conv2D/BiasAdd/PReLU/Depth2Space. This is a
  closed-source binary blob — see "On TensorConv.lib" below.
- `models/fsrcnn_s_x2.pb` / `models/fsrcnn_s_x3.pb` — the FSRCNN-s network
  as portable TensorFlow graphs, also copied unmodified from
  `thinkerleolee/FSRCNN-OpenCV`'s `models/` folder. Only used by the
  `kOpenCLiGpu` backend (see "How AI upscaling works" below) — the
  `kCpuEigen` backend uses `fsrcnn_params.h`'s C arrays instead and never
  touches these.
- `third_party/eigen/` — vendored **from that same repo's own copy** of
  Eigen (MPL2), because `tensorconv_ops.h`'s `Tensor4D` is an
  `Eigen::Tensor<float,4,RowMajor>`, and `TensorConv.lib` was compiled
  against this exact Eigen version's memory layout.
- `FSRCNN-OpenCV-LICENSE.txt` — that repo's LGPL-3.0 license, carried
  along with its weights/architecture/tensorconv/Eigen per license terms.
- `codec_common.h` — per-frame scalable image codec (MJPEG base + FFV1
  lossless residual) for full-frame updates.
- `lz4.h` / `lz4.c` / `lz4_rect_codec.h` — vendored LZ4 (BSD-2-Clause,
  official lz4/lz4 repo) + a thin zero-alloc wrapper, used to decompress
  the incoming dirty rectangle in delta mode.
- `architecture.h` / `architecture.cpp` — runtime CPU capability detection
  (checks whether this x64 CPU actually supports AVX2).
- `simd_residual.h` / `simd_residual.cpp` — AVX2 + scalar implementations of
  the residual math, dispatched once at startup based on what
  `architecture.cpp` detects. (The NEON path in this file is compiled out
  automatically on an x64 build — it costs you nothing.)
- `wire_protocol.h` — shared framing format + hardcoded endpoint.
- `build.bat` — x64-only build script.

(The receiver doesn't need `diff_detector.*` — dirty-region *detection*
only happens sender-side; the receiver just reads the rectangle's
`x,y,w,h` straight out of the message payload, so it's not included here.)

## How delta frames are handled

A full-frame message replaces the entire canvas. A delta-frame message's
payload now has two parts (see `wire_protocol.h`'s file header for the
exact byte layout):

1. **A copy-rect list** — `{srcX,srcY,dstX,dstY,w,h}` entries, 24 bytes
   each. These come from the sender's `motion_detector.h`: content it
   found already existed elsewhere in the previous frame (a dragged
   window, a scroll) rather than genuinely changing. The receiver applies
   these as `memcpy`s **within its own existing canvas** — zero new pixel
   bytes over the wire for that content, just the 24-byte instruction.
   Applied as an all-extract-then-all-write batch (`applyCopyRects` in
   `receiver_server.cpp`), not one rect at a time, so that if two copy
   rects in the same message happen to have overlapping regions, neither
   can read data the other already overwrote.
2. **One trailing raw rect** (`rect_x, rect_y, rect_w, rect_h` + LZ4-
   compressed pixel bytes) — same format the single-rectangle design
   always used, now carrying only whatever the motion detector couldn't
   explain as a copy (genuinely new content). `rect_w == 0` means no new
   pixels this frame; can happen alongside a non-empty copy-rect list
   (pure motion, nothing new) or, in the fully static case, alongside an
   empty copy-rect list too (nothing changed at all — no decompression,
   no BMP write, the writer thread naturally goes idle).

Both copy rects and the raw rect are bounds-checked against the canvas
dimensions before any memory is touched, so a malformed or out-of-range
entry is logged and the whole delta message dropped rather than causing
an out-of-bounds write.

**Free synergy with the AI upscaler:** a copy rect's source position in
`masterCanvas` already holds valid, already-upscaled pixels for that exact
content (that's what "moved" means — same pixels, different place), so
`applyCopyRects` copies directly at the scaled position instead of running
any upscaling at all for that region — cheaper even than the bicubic
cheap-path used for genuinely new content below.

## How AI upscaling works

The receiver keeps two buffers: `canvas` (raw, source resolution) and
`masterCanvas` (`kUpscaleFactor`x source resolution, hardcoded to 2 in
`receiver_server.cpp` — change it to 3 if you need that instead; only 2
and 3 have trained FSRCNN-s weights available, for either backend).

- A **full-frame** message rebuilds `canvas` from the MJPEG+FFV1 codec,
  then runs a full FSRCNN-s pass (`Upscaler::FullFrameUpscale`) over the
  whole thing to rebuild `masterCanvas`, via whichever backend
  `kUpscaleBackend` selects (below).
- A **delta** message patches just its rectangle into `canvas`, then
  `Upscaler::CheapRectUpscale` (`cv::resize(INTER_CUBIC)`, no neural net,
  always CPU regardless of backend) upscales only that rectangle and
  `Upscaler::FeatherPasteRect` blends it onto `masterCanvas` with a
  feathered edge so it doesn't leave a visible seam against neighboring
  AI-sharp or previously-cheap-scaled pixels.
- Every `kStalenessRefreshInterval` (1500ms by default) the *next* delta
  triggers a full FSRCNN-s re-pass instead of just the cheap patch, so
  regions that have been living on bicubic scaling for a while get
  sharpened back up.

### Two backends for the full-frame FSRCNN-s pass

Set `kUpscaleBackend` in `receiver_server.cpp`:

- **`aiup::Backend::kCpuEigen`** (works everywhere) — runs
  `thinkerleolee/FSRCNN-OpenCV`'s own `fsrcnn.h`/`fsrcnn.cc` unmodified,
  linked against the prebuilt `TensorConv.lib`, spread across CPU cores
  via `Eigen::ThreadPoolDevice`. No GPU involved at all — this is what
  the previous version of this package always used, and it's still the
  only option that doesn't depend on anything about the GPU situation of
  the machine it runs on.
- **`aiup::Backend::kOpenCLiGpu`** — runs the same FSRCNN-s architecture
  loaded from a portable TensorFlow graph (`models/fsrcnn_s_x2.pb` /
  `fsrcnn_s_x3.pb`, from the same repo) through OpenCV's `dnn_superres`
  module (`opencv_contrib`) with `DNN_BACKEND_OPENCL` /
  `DNN_TARGET_OPENCL`. This is the **integrated GPU** built into most
  modern CPUs (Intel UHD/Iris, AMD Radeon on an APU) — *not* a discrete
  NVIDIA card, and *not* CUDA (OpenCL runs on Intel/AMD iGPUs; CUDA is
  NVIDIA-only and isn't used here). If OpenCL isn't actually available at
  runtime (no iGPU, drivers missing, or the `.pb` file can't be found),
  `Upscaler`'s constructor logs a warning and **automatically falls back
  to `kCpuEigen`** — check `upscaler.backend()` (also logged at startup)
  to see which one actually ended up running.

Requires `models/fsrcnn_s_x2.pb` and `models/fsrcnn_s_x3.pb` (already in
this package) to sit next to `receiver_server.exe` at runtime — they're
loaded at startup, not linked in. Only needed for the `kOpenCLiGpu`
backend; the CPU backend doesn't touch them.

### On TensorConv.lib

`thinkerleolee/FSRCNN-OpenCV` expresses FSRCNN-s purely in terms of four
generic tensor ops (Conv2D/BiasAdd/PReLU/Depth2Space) declared in
`tensorconv_ops.h`, but their *implementations* only exist in that repo as
a prebuilt Windows static lib — no source. This package links against that
lib directly rather than reimplementing it, per your request. Two things
that come with that:

1. **MSVC only, and probably a specific-ish MSVC.** It's a `.lib` built
   for x64 Windows; it will not link with MinGW/clang-on-Linux/etc., and
   very old or very new MSVC toolchains can occasionally hit CRT/STL ABI
   friction with a lib built against a different `_MSC_VER`. If you hit
   linker errors here, that's the likely cause.
2. **Eigen version must match.** `Tensor4D` is `Eigen::Tensor<float,4,RowMajor>`
   — a header-only template type, so its in-memory layout is baked into
   whatever translation units the lib's object code came from. Building
   against a different Eigen release than the one vendored here risks a
   layout mismatch that compiles fine and corrupts data silently. Don't
   swap `third_party/eigen/` for a system Eigen install.

(This only applies to the `kCpuEigen` backend — `kOpenCLiGpu` doesn't use
`TensorConv.lib`/Eigen at all, it goes through `dnn_superres`/OpenCV `dnn`
instead, loading the `.pb` graph directly.)

## Build

1. Get FFmpeg dev libs (headers + `.lib`s for avcodec/avutil/swscale) —
   e.g. the "shared" package from https://www.gyan.dev/ffmpeg/builds/.
2. Get an OpenCV dev package for MSVC x64 (headers + `opencv_world*.lib`)
   — e.g. the official Windows build from https://opencv.org/releases/.
3. Edit the `set FFMPEG_...` and `set OPENCV_...` paths (and
   `OPENCV_LIB_NAME` to match your OpenCV version's filename) at the top
   of `build.bat`.
4. Open **"x64 Native Tools Command Prompt for VS"** (Start menu, under
   Visual Studio), `cd` into this folder, run:
   ```
   build.bat
   ```
5. Copy `avcodec-*.dll`, `avutil-*.dll`, `swscale-*.dll` from FFmpeg's
   `bin\` folder, and `opencv_world*.dll` from OpenCV's `bin\` folder,
   next to `receiver_server.exe`.

## Run

This is the listener — start it **before** the sender:
```
receiver_server.exe
```
Reconstructed frames land in `received_frames\` as they arrive.
