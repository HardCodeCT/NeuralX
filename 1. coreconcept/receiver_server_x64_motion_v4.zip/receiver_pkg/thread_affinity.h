// ============================================================================
// thread_affinity.h
//
// Optional core pinning for the two hot, long-lived compute threads this
// pipeline actually has: the sender's network/encode thread (diff, motion
// search, encode -- everything after capture) and the receiver's writer
// thread (canvas claim + BMP write). NOT applied to WGC's FrameArrived
// callback: that runs on a COM MTA thread-pool thread whose lifetime and
// identity WGC manages internally, so pinning it directly isn't safe --
// COM can reuse or reassign that thread between callbacks.
//
// Why this wasn't in the pipeline before now: the RDTSC timing already
// showed ~79% headroom in the sender's frame budget with no core pinning
// at all -- there was no MEASURED scheduling-jitter problem to justify the
// complexity. This is added as an available, opt-in tool now, not because
// a specific bottleneck was found.
//
// Fails safe, same posture as GPU device selection and AI-upscale backend
// fallback elsewhere in this codebase: if pinning fails for any reason
// (fewer cores than expected, restricted process affinity, an OS that
// denies the call), this logs and continues UNPINNED rather than crashing
// or aborting the pipeline.
// ============================================================================
#pragma once

#include <windows.h>
#include <cstdio>
#include <thread>

namespace threadutil {

// Returns the number of logical cores actually available to THIS process
// (not the machine) -- respects any affinity mask already imposed by a
// container, job object, or administrator policy, which a raw
// GetSystemInfo() core count would ignore.
inline int AvailableCoreCount() {
    DWORD_PTR processMask = 0, systemMask = 0;
    if (!GetProcessAffinityMask(GetCurrentProcess(), &processMask, &systemMask) || processMask == 0) {
        return 1; // couldn't query -- assume the conservative single-core case
    }
    int count = 0;
    for (DWORD_PTR m = processMask; m != 0; m &= (m - 1)) ++count; // popcount
    return count;
}

// Pins the CALLING thread to logical core `coreIndex` (0-based). Call this
// from inside the thread you want pinned -- SetThreadAffinityMask affects
// the thread that invokes it, not a thread handle passed in, so the
// std::thread lambda/function itself must call this on entry.
//
// Returns true if the pin was applied. On any failure -- coreIndex outside
// what this process can actually use, or the OS call itself failing -- logs
// a warning and returns false; callers are expected to keep running
// unpinned rather than treat this as fatal.
inline bool PinCurrentThreadToCore(int coreIndex, const char *threadLabel) {
    const int available = AvailableCoreCount();
    if (coreIndex < 0 || coreIndex >= available) {
        std::fprintf(stderr,
            "[thread_affinity] '%s': requested core %d, but only %d available to this "
            "process -- continuing unpinned.\n", threadLabel, coreIndex, available);
        return false;
    }

    const DWORD_PTR mask = (DWORD_PTR(1) << coreIndex);
    const DWORD_PTR prev = SetThreadAffinityMask(GetCurrentThread(), mask);
    if (prev == 0) {
        std::fprintf(stderr,
            "[thread_affinity] '%s': SetThreadAffinityMask failed (error %lu) -- "
            "continuing unpinned.\n", threadLabel, GetLastError());
        return false;
    }
    std::fprintf(stderr, "[thread_affinity] '%s' pinned to logical core %d.\n", threadLabel, coreIndex);
    return true;
}

} // namespace threadutil
