@echo off
REM ============================================================================
REM build.bat - receiver_server.exe (x64 only)
REM Run from "x64 Native Tools Command Prompt for VS" (or after calling
REM vcvars64.bat), so cl.exe is on PATH and targeting x64.
REM
REM Uses thinkerleolee/FSRCNN-OpenCV's own fsrcnn.h/fsrcnn.cc + the prebuilt
REM third_party/tensorconv/lib/x64/Release/TensorConv.lib from that repo
REM (vendored here), which needs:
REM   - OpenCV (this repo's fsutils.h calls cv::cvtColor / cv::resize, and
REM     ai_upscaler.cpp additionally uses the dnn_superres module +
REM     DNN_TARGET_OPENCL for the integrated-GPU backend -- your OpenCV
REM     needs to have been built with opencv_contrib (for dnn_superres) and
REM     WITH_OPENCL=ON; the official prebuilt Windows package from
REM     opencv.org has both by default, so that's the easy route)
REM   - Eigen  (vendored in third_party/eigen/ -- must be THIS exact copy,
REM             since TensorConv.lib was compiled against its Eigen::Tensor
REM             layout; a different Eigen version risks silent ABI mismatch)
REM
REM Also needs models\fsrcnn_s_x2.pb and models\fsrcnn_s_x3.pb (already in
REM this package) copied next to the .exe -- only used by the OpenCL/iGPU
REM backend (see kUpscaleBackend in receiver_server.cpp), loaded at runtime,
REM not linked.
REM ============================================================================
setlocal

REM ---- EDIT THESE to point at your FFmpeg dev package (needs avcodec,
REM      avutil, swscale headers + .lib files). ----
set FFMPEG_INCLUDE=C:\ffmpeg\include
set FFMPEG_LIB=C:\ffmpeg\lib

REM ---- EDIT THESE to point at your OpenCV dev package (needs opencv2
REM      headers + the .lib matching OPENCV_LIB_NAME below, e.g. an
REM      opencv_world4XX.lib from a prebuilt Windows package, or your own
REM      build's install\x64\vc17\lib). ----
set OPENCV_INCLUDE=C:\opencv\build\include
set OPENCV_LIB=C:\opencv\build\x64\vc16\lib
set OPENCV_LIB_NAME=opencv_world4100.lib

REM Release build links TensorConv.lib; swap to Debug\TensorConvd.lib (and
REM add /MDd) for a debug build.
set TENSORCONV_LIB=third_party\tensorconv\lib\x64\Release\TensorConv.lib

cl /std:c++20 /EHsc /arch:AVX2 /O2 ^
   receiver_server.cpp architecture.cpp simd_residual.cpp ^
   fsrcnn.cc fsrcnn_params.cc ai_upscaler.cpp lz4.c ^
   /I . ^
   /I "third_party\eigen" ^
   /I "%FFMPEG_INCLUDE%" ^
   /I "%OPENCV_INCLUDE%" ^
   /Fe:receiver_server.exe ^
   /link /LIBPATH:"%FFMPEG_LIB%" /LIBPATH:"%OPENCV_LIB%" ^
   avcodec.lib avutil.lib swscale.lib ws2_32.lib ^
   "%OPENCV_LIB_NAME%" "%TENSORCONV_LIB%"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Build FAILED.
    exit /b %ERRORLEVEL%
)

echo.
echo Build OK: receiver_server.exe
echo Copy avcodec-*.dll, avutil-*.dll, swscale-*.dll from your FFmpeg bin\
echo folder, and opencv_world*.dll from your OpenCV bin\ folder, next to
echo receiver_server.exe before running.
echo Also make sure the models\ folder (fsrcnn_s_x2.pb, fsrcnn_s_x3.pb) sits
echo next to receiver_server.exe -- needed only if kUpscaleBackend is set to
echo kOpenCLiGpu in receiver_server.cpp.
endlocal
