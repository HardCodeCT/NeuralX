@echo off
REM ============================================================================
REM build.bat - sender_client.exe (x64 only)
REM Run from "x64 Native Tools Command Prompt for VS" (or after calling
REM vcvars64.bat), so cl.exe is on PATH and targeting x64.
REM ============================================================================
setlocal

REM ---- EDIT THESE to point at your FFmpeg dev package (needs avcodec,
REM      avutil, swscale headers + .lib files). ----
set FFMPEG_INCLUDE=C:\ffmpeg\include
set FFMPEG_LIB=C:\ffmpeg\lib

cl /std:c++20 /EHsc /await /arch:AVX2 /O2 ^
   sender_client.cpp architecture.cpp simd_residual.cpp diff_detector.cpp motion_detector.cpp lz4.c ^
   /I "%FFMPEG_INCLUDE%" ^
   /Fe:sender_client.exe ^
   /link /LIBPATH:"%FFMPEG_LIB%" ^
   avcodec.lib avutil.lib swscale.lib ^
   d3d11.lib dxgi.lib windowsapp.lib ws2_32.lib

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Build FAILED.
    exit /b %ERRORLEVEL%
)

echo.
echo Build OK: sender_client.exe
echo Copy avcodec-*.dll, avutil-*.dll, swscale-*.dll from your FFmpeg bin\
echo folder next to sender_client.exe before running.
endlocal
