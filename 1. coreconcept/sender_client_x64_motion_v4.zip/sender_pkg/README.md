# sender_client (x64 only)

## Contents
- `sender_client.cpp` — Windows Graphics Capture client: 24 FPS hard-locked
  capture, GPU staging readback with pitch stripping, per-frame full/delta
  decision, encode, send over TCP to the hardcoded receiver at
  `127.0.0.1:5000`.
- `diff_detector.h` / `diff_detector.cpp` — SIMD-accelerated 8x8-block
  comparison against the previous frame's *downscaled proxy* (not the
  native-resolution capture — see `DownscaleBoxAverage`), plus
  `ComputeDirtyBoundingBox()` (collapses dirty blocks into one rectangle)
  and `MapBoundingBoxToFullRes()` (converts that rectangle back to
  full-resolution pixel coordinates for extraction).
- `motion_detector.h` / `motion_detector.cpp` — runs on top of
  `diff_detector`'s dirty bounding box: finds content that just MOVED
  (a dragged window, a scroll) rather than genuinely changed, using a 2D
  rolling hash so it can find arbitrary pixel-exact translations (not just
  block-grid-aligned ones). See "How motion detection works" below.
- `codec_common.h` — per-frame scalable image codec (MJPEG base + FFV1
  lossless residual) for full-frame updates. Also still contains `TileCodec`
  (unused by the current delta path — see the comment above its
  definition — kept as a reusable building block).
- `lz4.h` / `lz4.c` / `lz4_rect_codec.h` — vendored LZ4 (BSD-2-Clause,
  official lz4/lz4 repo) + a thin zero-alloc wrapper, used to compress the
  single dirty rectangle in delta mode. LZ4 was chosen over reusing FFV1
  here because FFV1 wants a fixed-size, persistent codec context, and the
  rectangle's size changes every frame; LZ4 has no such setup cost and
  compresses an arbitrary buffer in one call.
- `architecture.h` / `architecture.cpp` — runtime CPU capability detection
  (checks whether this x64 CPU actually supports AVX2).
- `simd_residual.h` / `simd_residual.cpp` — AVX2 + scalar implementations of
  the residual math, dispatched once at startup based on what
  `architecture.cpp` detects. (The NEON path in this file is compiled out
  automatically on an x64 build — it costs you nothing.)
- `wire_protocol.h` — shared framing format + hardcoded endpoint.
- `build.bat` — x64-only build script.

## How the delta encoding works

Every captured frame is first **downscaled into a small detection proxy**
(~1/3 linear size by default, ~1/9 the pixels — `kDetectionDownscaleFactor`
in `sender_client.cpp`) via `DownscaleBoxAverage()`, and change detection
runs entirely on that proxy against the *previous frame's proxy* — not the
native-resolution capture. This matters: comparing every byte of a
1900x900 capture is real, measurable CPU cost every frame; comparing a
~633x300 proxy is roughly 9x less data to touch.

- **First frame, or if most of the proxy's 8x8 blocks changed** (>50%
  dirty, e.g. a full-screen video or window drag) — sent as a **full
  frame** through the existing lossy scalable codec, same as before.
- **Otherwise** — every dirty block is reduced to a single bounding
  rectangle *in the proxy's coordinate space*, then mapped back to
  full-resolution pixel coordinates (`MapBoundingBoxToFullRes`) before
  extraction — the actual transmitted pixels are always full quality, only
  the *decision of which region changed* runs at reduced resolution. That
  rectangle's original pixels are packed, LZ4-compressed, and sent as
  **one** message. A frame where nothing changed at all sends a tiny empty
  marker and nothing else.

Note on the single-rectangle tradeoff: if two unrelated regions change in
the same frame (e.g. a cursor blink in one corner and a clock update in
another), the bounding box covers both plus everything between them. This
is a deliberate simplicity/bandwidth tradeoff, not a bug — for the target
case (typing, mouse movement, localized UI updates) it's a large win; for
scattered simultaneous changes it costs more than a multi-rectangle scheme
would, but stays capped by the 50% full-frame fallback either way.

Note on the downscale itself: it's a genuine box average, not a nearest-
pixel subsample, specifically so a single-pixel change can't fall "between"
sampled points and get missed entirely. The one residual risk, disclosed
in `diff_detector.h`'s comments, is that two pixels changing in exactly
offsetting directions within the same averaging block could in theory
leave that block's average bit-identical — extremely unlikely for real
screen content, but a real (if negligible) limitation of averaging as a
strategy, not something the code silently guarantees against.

## How motion detection works

`diff_detector.h`'s same-position block comparison only ever asks "is the
pixel data at (x,y) different from last frame's (x,y)" — it has no way to
tell "genuinely new content" apart from "old content that just moved
somewhere else." A dragged window is the clean example: both its old
position (now-revealed background) and its new position get flagged
dirty, and the *entire* union bounding box gets re-sent as raw pixels,
even though the window's actual pixel content already existed in the
previous frame.

`motion_detector.h`'s `DetectMotion()` runs on top of that existing dirty
bounding box (never the whole screen) and asks the second question: for
each 16x16 block inside the box, does this content already exist
*somewhere* in the previous frame, just at a different position? If so,
it's encoded as a `wire::CopyRect` (`{srcX,srcY,dstX,dstY,w,h}`, 24 bytes)
instead of raw pixels — the receiver just copies from its own existing
canvas.

- **Why a rolling hash, not a block-grid-aligned hash table:** real
  drags/scrolls move by an arbitrary pixel amount, not a multiple of 16.
  A hash table built only at block-grid-aligned positions would rarely
  fire on real content. Instead, every possible pixel-offset block
  position within a bounded search region (the dirty box + a margin, see
  `kSearchMargin`) gets hashed via a 2D Rabin-Karp-style rolling hash —
  O(region area) total, not O(region area × block area) — so arbitrary
  translations are actually findable. Every hash hit is still verified
  with a real `memcmp` before being trusted; the hash only narrows down
  candidates, it never gets to unilaterally decide a match.
- **Time complexity** is bounded by the (already small) dirty region, not
  the screen — see the detailed breakdown in `motion_detector.h`'s file
  header.
- **A genuine, tested limitation:** `outLeftoverBox` (the "not explained
  by motion" remainder still sent as raw pixels) is a single bounding box,
  same representation `diff_detector.h`'s own dirty rect already uses.
  This means the *wire-bandwidth* win is inconsistent even when most
  pixels genuinely get explained — if the unexplained pixels form a
  pattern touching multiple edges of the dirty box (a scroll region's true
  content boundary not landing on a 16px block boundary is a common way
  this happens), the leftover box can snap back out to the full original
  extent even though the copy rects themselves are correct and did their
  job. Verified directly with a synthetic scroll test: 91% of pixels
  explained by motion, ~0% wire savings that particular frame, because the
  unexplained 9% formed a border-touching band. The motion detector is
  correct in this situation, just not maximally bandwidth-efficient — a
  multi-rectangle (rather than single bounding-box) leftover
  representation would fix this but is a larger, separate change to both
  the wire protocol and the receiver.
- **A block matching its own position** (offset (0,0) — i.e. genuinely
  unchanged content that just happened to be inside the dirty bounding
  box, which is common since the box itself is a coarse union, not a tight
  mask) is detected and excluded from the leftover raw-pixel region, but
  deliberately **not** emitted as a copy rect either — there's nothing
  useful to copy when the destination already equals the source.

## Build

1. Get FFmpeg dev libs (headers + `.lib`s for avcodec/avutil/swscale) —
   e.g. the "shared" package from https://www.gyan.dev/ffmpeg/builds/.
2. Edit the two `set FFMPEG_...` paths at the top of `build.bat`.
3. Open **"x64 Native Tools Command Prompt for VS"** (Start menu, under
   Visual Studio), `cd` into this folder, run:
   ```
   build.bat
   ```
4. Copy `avcodec-*.dll`, `avutil-*.dll`, `swscale-*.dll` from FFmpeg's
   `bin\` folder next to `sender_client.exe`.

## Run

Start the receiver first (it's the listener), then:
```
sender_client.exe
```
