// ============================================================================
// motion_detector.h
//
// Sender-side "did this content just MOVE" detection, layered on top of the
// existing diff_detector.h dirty-rectangle pipeline. Runs only within the
// (already small) full-resolution dirty bounding box diff_detector already
// computed -- this is deliberately NOT a general full-frame motion search,
// it's specifically closing the gap where same-position block comparison
// fails: a dragged window, a scrolled region, anything whose pixels are
// unchanged but relocated.
//
// ---- Why a rolling hash, not a block-grid-aligned hash table ----
// A naive approach -- hash every 16x16 block of the previous frame at
// block-grid-aligned positions (0,16,32,...), then look up the current
// frame's dirty blocks against that table -- only finds matches when the
// real motion (dx,dy) happens to be an exact multiple of the block size.
// Real drags/scrolls are pixel-exact, not block-grid-quantized, so that
// approach would rarely fire on real content. Instead this hashes EVERY
// possible pixel-offset block position within the search region, using a
// 2D Rabin-Karp-style rolling hash so that costs O(regionArea) total
// (rolling update is O(1) per shifted position) rather than the naive
// O(regionArea * blockArea) of recomputing a full block hash at every
// pixel offset. This is the same family of technique rsync/rolling
// checksums use for "did this chunk of data move" detection.
//
// ---- Time complexity summary ----
// Let R = search region area (dirty box expanded by a bounded margin,
// clamped to the frame -- NOT the whole screen), B = block area (16x16 =
// 256 px), D = number of blocks in the dirty box needing a lookup.
//   - Building the previous-frame hash table:  O(R)        (rolling hash)
//   - Hashing each dirty-box query block:      O(D * B)    (no rolling
//     benefit on the query side -- each query is hashed once, fresh, via
//     the SIMD block hash below)
//   - Table lookups:                           O(D) amortized (single
//     open-addressing probe per query, table sized for a low load factor)
//   - Verification (only on hash hits):        O(B) each, memcmp-based
//   - Coalescing matched blocks into rects:     O(D)
// None of this scales with the full frame size or the full screen area --
// everything is bounded by the dirty region (which the existing cheap
// proxy-based diff detector already keeps small for the common case).
//
// ---- Alignment / SIMD ----
// Block start addresses are data-dependent (arbitrary rect/frame
// coordinates) so nothing here assumes alignment on the frame buffer side
// -- all frame-buffer loads are unaligned (_mm256_loadu_si256 on AVX2).
// The one place we DO control layout, the per-block scratch buffer used
// during verification/packing, is declared alignas(32) so at least one
// side of any SIMD compare can use an aligned load.
// ============================================================================
#pragma once

#include <cstdint>
#include <vector>

#include "wire_protocol.h"
#include "diff_detector.h"

namespace motiondet {

// Fixed block size for motion search. 16x16x4 = 1024 bytes/block -- a clean
// multiple of the AVX2 32-byte lane size (2 loads/row, 16 rows/block).
constexpr int kBlockSize = 16;

// How far past the dirty box's own edges to search in the previous frame,
// in pixels. Bounds both the search region size (and therefore the O(R)
// hashing cost) and how far a single frame's drag/scroll can be detected --
// at 24fps a 96px margin comfortably covers realistic per-frame mouse-drag
// deltas without letting the search region (and its cost) grow unbounded.
constexpr int kSearchMargin = 96;

// Hard cap on search region pixel area. If the dirty box + margin would
// exceed this, motion detection is skipped for that frame entirely (falls
// back to the pre-existing raw-pixel-only path) rather than let a
// pathological case (e.g. nearly the whole screen just barely under the
// full-frame-fallback threshold) blow the frame time budget. Sized
// generously above what a typical drag/scroll dirty box + margin needs.
constexpr int kMaxSearchRegionPixels = 2 * 1024 * 1024; // e.g. ~1450x1450

// One block's match result after lookup + verification.
struct BlockMatch {
    bool explained = false; // true if a verified previous-frame source was found
    int32_t srcX = 0, srcY = 0; // only valid if explained
};

// Preallocated, reusable across frames (construct once at startup) -- no
// per-frame heap allocation on the hot path beyond growing scratch vectors
// to their high-water mark once, matching this codebase's existing
// "zero-alloc hot path" convention (see sender_client.cpp's TripleBuffer).
class MotionDetector {
public:
    MotionDetector();

    // prevFull / currFull: full-resolution BGRA8 frames, both with the same
    // strideBytes (tightly packed, i.e. strideBytes == fullW*4, matching
    // what sender_client.cpp already produces).
    // dirtyBox: full-resolution dirty bounding box from diff_detector.h,
    // already computed by the caller (this function does not re-run
    // change detection, only explains WHERE the already-known-dirty
    // content came from).
    // outCopyRects: cleared and filled with verified moved-block rectangles
    // (already coalesced -- adjacent blocks sharing an identical motion
    // vector are merged into one rect each, not emitted individually).
    // outLeftoverBox: the sub-region of dirtyBox NOT explained by any copy
    // rect (i.e. genuinely new pixel content, or motion detection was
    // skipped/found nothing) -- still needs the existing raw-pixel path.
    // May be BoundingBox::empty() if every block was explained.
    //
    // ---- KNOWN, TESTED LIMITATION: outLeftoverBox is a single bounding
    // box, same representation the pre-existing diff_detector.h dirty
    // rectangle already uses. This means the WIRE-BANDWIDTH win from
    // motion detection is inconsistent, even when the underlying pixel
    // explanation rate is high: if the unexplained pixels form a pattern
    // that touches multiple edges of dirtyBox (a common case -- e.g. a
    // scrolled region's true content boundary sitting a few pixels off
    // from a 16px block boundary means blocks straddling that boundary
    // can never validate a single rigid-translation match, and if that
    // happens along a full edge, the bounding box snaps back out to
    // dirtyBox's full extent even though the interior was mostly
    // explained), outLeftoverBox stops shrinking even though most pixels
    // WERE genuinely explained -- verified directly with a synthetic
    // scroll test: 91% of pixels explained by motion, but the leftover
    // bounding box came back unchanged because the unexplained ~9% formed
    // a border-touching band. The copy rects themselves are always
    // correct in this situation (that's not in question, they're
    // pixel-verified); what's inconsistent is specifically how much wire
    // bandwidth gets saved on any given frame. A tighter representation
    // (a short list of leftover rectangles instead of one, or a coarse
    // bitmap) would fix this but is a separate, larger change to both the
    // wire protocol and the receiver's parsing -- out of scope here. ----
    //
    // Returns true if motion detection actually ran (false only when the
    // search region exceeded kMaxSearchRegionPixels and was skipped
    // entirely -- in that case outCopyRects is empty and outLeftoverBox ==
    // dirtyBox unchanged, i.e. behaves exactly like the pre-motion-detection
    // pipeline).
    bool DetectMotion(const uint8_t *prevFull, const uint8_t *currFull, int strideBytes,
                       int fullW, int fullH, const diffdet::BoundingBox &dirtyBox,
                       std::vector<wire::CopyRect> &outCopyRects,
                       diffdet::BoundingBox &outLeftoverBox);

private:
    // ---- Open-addressing hash table over the previous frame's search
    // region, keyed by the rolling block hash. Preallocated to a generous
    // fixed capacity at construction; if a given frame's search region
    // would need more slots than that, DetectMotion degrades gracefully
    // (see kMaxSearchRegionPixels above) rather than reallocating on the
    // hot path. ----
    struct Slot {
        uint64_t hash = 0;
        int32_t x = 0, y = 0;
        bool occupied = false;
    };
    std::vector<Slot> table_;
    size_t tableMask_ = 0; // table_.size() is always a power of two; mask = size-1

    // Scratch reused across frames (sized to the largest search region seen
    // so far via std::vector's normal growth -- still zero *steady-state*
    // allocation once warmed up, same pattern as the rest of this codebase).
    std::vector<uint64_t> rowHashScratch_;
    std::vector<uint64_t> blockHashScratch_;
    std::vector<uint8_t> blockExplainedScratch_;
    std::vector<int32_t> blockSrcXScratch_, blockSrcYScratch_;

    void rebuildTable(size_t neededSlots);
    void insert(uint64_t hash, int32_t x, int32_t y);
    // Returns true and fills candX/candY if a hash match was found (NOT yet
    // pixel-verified -- caller must verify before trusting the position).
    bool lookup(uint64_t hash, int32_t &candX, int32_t &candY) const;
};

} // namespace motiondet
