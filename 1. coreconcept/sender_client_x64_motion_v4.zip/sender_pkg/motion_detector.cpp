#include "motion_detector.h"

#include <algorithm>
#include <cstdio>
#include <cstring>

namespace motiondet {

namespace {

inline uint32_t pixelSymbol(const uint8_t *p) {
    uint32_t v;
    std::memcpy(&v, p, 4); // avoids alignment/strict-aliasing UB; compiles to a plain load
    return v;
}

// Rolling-hash base. Any odd 64-bit constant works; this one (also used in
// the validated standalone prototype for this algorithm) gives good bit
// dispersion over typical pixel-value ranges without any special structure
// that would cause pathological collisions on flat/solid-color regions.
constexpr uint64_t kRollBase = 1000000007ULL;

// ---- Query block hash: hashes ONE kBlockSize x kBlockSize BGRA8 block
// (rows kBlockSize apart by strideBytes, not contiguous) from the CURRENT
// frame, for lookup against the previous frame's rolling-hash table.
//
// CRITICAL CORRECTNESS CONSTRAINT: this MUST compute the exact same 2D
// polynomial value the rolling hash below produces for identical content,
// or every lookup silently misses -- content that genuinely moved would
// never be found, degrading (silently, no crash, no error) to "motion
// detection never fires", which defeats the entire feature without any
// visible symptom other than bandwidth never improving. An early version
// of this file used a different, faster-looking XOR/shift-based hash here
// and shipped exactly that bug -- verified against a real dragged-window
// test case before catching it, see the accompanying explanation.
//
// The rolling hash computes (conceptually, via incremental updates):
//   H_row(y,x)   = sum_{j=0..W-1} symbol(y,x+j)   * B^(W-1-j)
//   H_block(y,x) = sum_{i=0..H-1} H_row(y+i,x)    * B^(H-1-i)
// i.e. Horner's rule. For a single one-off block (no sliding window to
// amortize), that same value can equivalently be computed as a plain
// weighted sum against precomputed powers of B, evaluated in ANY order --
// under fixed-width unsigned (mod 2^64) arithmetic, addition and
// multiplication are associative/commutative regardless of grouping, so
// Horner's rule and a reordered weighted-sum are bit-for-bit identical,
// not just approximately equal (verified independently before integrating
// this). That equivalence is what makes it safe to use a different
// evaluation order here than the rolling table-build uses, while still
// guaranteeing the two sides land on the same hash for the same content.
//
// This intentionally stays scalar rather than reaching for AVX2: a
// genuinely correct vectorized 64x64-bit multiply (needed for this
// specific polynomial, since B^15 does not fit in 32 bits) requires
// manually decomposing into 32-bit partial products -- real, doable, but
// exactly the kind of rarely-exercised, easy-to-get-subtly-wrong SIMD path
// that produced the bug this comment is warning about. This function only
// ever runs on the (already small, bounded) blocks inside the dirty
// region, so its cost is negligible relative to the O(regionArea) rolling
// hash table build below, which is where the real per-frame cost -- and
// this file's actual SIMD-relevant work -- lives.
uint64_t computeQueryBlockHash(const uint8_t *base, int strideBytes) {
    static const auto weights = [] {
        struct W { uint64_t col[kBlockSize], row[kBlockSize]; } w{};
        w.col[kBlockSize - 1] = 1;
        for (int i = kBlockSize - 2; i >= 0; --i) w.col[i] = w.col[i + 1] * kRollBase;
        w.row[kBlockSize - 1] = 1;
        for (int i = kBlockSize - 2; i >= 0; --i) w.row[i] = w.row[i + 1] * kRollBase;
        return w;
    }();

    uint64_t blockHash = 0;
    for (int row = 0; row < kBlockSize; ++row) {
        const uint8_t *r = base + static_cast<size_t>(row) * strideBytes;
        uint64_t rowHash = 0;
        for (int col = 0; col < kBlockSize; ++col)
            rowHash += static_cast<uint64_t>(pixelSymbol(r + static_cast<size_t>(col) * 4)) * weights.col[col];
        blockHash += rowHash * weights.row[row];
    }
    return blockHash;
}

// Exact verification (never trust a hash hit alone -- 64 bits of hash space
// makes accidental collisions rare but not impossible, and rolling hashes
// specifically are more structured / less cryptographically random than a
// general-purpose hash, so this check is not optional). Row-by-row memcmp;
// each row is contiguous (kBlockSize*4 bytes), rows themselves are
// strideBytes apart in both buffers -- the CRT's memcmp already vectorizes
// internally on any target that matters here, so there's no benefit to
// hand-rolling this one with intrinsics too.
bool blocksEqualExact(const uint8_t *a, int strideA, const uint8_t *b, int strideB) {
    constexpr int rowBytes = kBlockSize * 4;
    for (int row = 0; row < kBlockSize; ++row) {
        if (std::memcmp(a + static_cast<size_t>(row) * strideA,
                         b + static_cast<size_t>(row) * strideB, rowBytes) != 0)
            return false;
    }
    return true;
}

inline size_t nextPow2(size_t v) {
    size_t p = 1;
    while (p < v) p <<= 1;
    return p;
}

} // namespace

MotionDetector::MotionDetector() {
    // Warm-start capacity: a 256x256 search region has (256-15)*(256-15) =
    // ~58k candidate block positions; size the table for that from the
    // start so the common case never needs a mid-run grow. rebuildTable()
    // still grows it further (grow-only, geometric) if a frame's search
    // region is unusually large.
    rebuildTable(64 * 1024);
}

void MotionDetector::rebuildTable(size_t neededSlots) {
    // Load factor <= 0.5 keeps linear-probing cheap (short probe chains).
    size_t wanted = nextPow2(std::max<size_t>(neededSlots, 1) * 2);
    if (wanted <= table_.size()) return; // already big enough, grow-only
    table_.assign(wanted, Slot{});
    tableMask_ = wanted - 1;
}

void MotionDetector::insert(uint64_t hash, int32_t x, int32_t y) {
    size_t i = static_cast<size_t>(hash) & tableMask_;
    // Linear probing, single slot per hash (last-write-wins on a genuine
    // collision). Known, documented tradeoff: if two different real block
    // positions in the search region happen to hash identically, only the
    // most recently inserted is kept as a lookup candidate. This never
    // causes an incorrect COPY (every hit is still pixel-verified before
    // being trusted -- see DetectMotion), it can only cause a missed
    // opportunity, which safely falls back to sending that content as raw
    // pixels, exactly like today.
    for (size_t probe = 0; probe < table_.size(); ++probe) {
        Slot &s = table_[i];
        if (!s.occupied || s.hash == hash) {
            s.occupied = true; s.hash = hash; s.x = x; s.y = y;
            return;
        }
        i = (i + 1) & tableMask_;
    }
    // Table completely full (shouldn't happen at load factor 0.5 with a
    // grow-only table sized per-frame in DetectMotion) -- drop silently;
    // worst case is a missed motion match, never incorrect output.
}

bool MotionDetector::lookup(uint64_t hash, int32_t &candX, int32_t &candY) const {
    size_t i = static_cast<size_t>(hash) & tableMask_;
    for (size_t probe = 0; probe < table_.size(); ++probe) {
        const Slot &s = table_[i];
        if (!s.occupied) return false; // empty slot -> definitely not present (standard open-addressing invariant)
        if (s.hash == hash) { candX = s.x; candY = s.y; return true; }
        i = (i + 1) & tableMask_;
    }
    return false;
}

bool MotionDetector::DetectMotion(const uint8_t *prevFull, const uint8_t *currFull, int strideBytes,
                                   int fullW, int fullH, const diffdet::BoundingBox &dirtyBox,
                                   std::vector<wire::CopyRect> &outCopyRects,
                                   diffdet::BoundingBox &outLeftoverBox) {
    outCopyRects.clear();
    outLeftoverBox = dirtyBox; // identity fallback: "nothing explained"

    if (dirtyBox.empty()) return true;

    // ---- 1. Search region: dirty box expanded by a bounded margin, clamped
    // to the frame. This -- not the whole screen -- is what every
    // complexity bound in this file is relative to. ----
    const int regionX = std::max(0, dirtyBox.x - kSearchMargin);
    const int regionY = std::max(0, dirtyBox.y - kSearchMargin);
    const int regionX1 = std::min(fullW, dirtyBox.x + dirtyBox.width + kSearchMargin);
    const int regionY1 = std::min(fullH, dirtyBox.y + dirtyBox.height + kSearchMargin);
    const int regionW = regionX1 - regionX;
    const int regionH = regionY1 - regionY;

    if (regionW < kBlockSize || regionH < kBlockSize) {
        return true; // region too small to contain even one candidate block; nothing to explain
    }
    if (static_cast<int64_t>(regionW) * regionH > kMaxSearchRegionPixels) {
        return false; // explicitly skipped -- caller keeps the pre-motion-detection behavior
    }

    // ---- 2. Build the previous frame's rolling-hash table over the search
    // region: O(regionW*regionH) total, NOT O(regionW*regionH*blockArea)
    // (see file header). outW/outH are the number of valid block-start
    // positions on each axis (every pixel offset, not just block-grid-
    // aligned ones -- this is what lets real, pixel-exact drags/scrolls be
    // found at all). ----
    const int outW = regionW - kBlockSize + 1;
    const int outH = regionH - kBlockSize + 1;

    uint64_t Bpow_w = 1; for (int i = 0; i < kBlockSize - 1; ++i) Bpow_w *= kRollBase;
    uint64_t Bpow_h = 1; for (int i = 0; i < kBlockSize - 1; ++i) Bpow_h *= kRollBase;

    rowHashScratch_.assign(static_cast<size_t>(regionH) * outW, 0);
    for (int y = 0; y < regionH; ++y) {
        const uint8_t *rowPtr = prevFull + static_cast<size_t>(regionY + y) * strideBytes + static_cast<size_t>(regionX) * 4;
        uint64_t h = 0;
        for (int i = 0; i < kBlockSize; ++i)
            h = h * kRollBase + pixelSymbol(rowPtr + static_cast<size_t>(i) * 4);
        rowHashScratch_[static_cast<size_t>(y) * outW + 0] = h;
        for (int x = 1; x < outW; ++x) {
            uint32_t leaving = pixelSymbol(rowPtr + static_cast<size_t>(x - 1) * 4);
            uint32_t entering = pixelSymbol(rowPtr + static_cast<size_t>(x + kBlockSize - 1) * 4);
            h = (h - static_cast<uint64_t>(leaving) * Bpow_w) * kRollBase + entering;
            rowHashScratch_[static_cast<size_t>(y) * outW + x] = h;
        }
    }

    blockHashScratch_.assign(static_cast<size_t>(outH) * outW, 0);
    for (int x = 0; x < outW; ++x) {
        uint64_t h = 0;
        for (int i = 0; i < kBlockSize; ++i)
            h = h * kRollBase + rowHashScratch_[static_cast<size_t>(i) * outW + x];
        blockHashScratch_[static_cast<size_t>(0) * outW + x] = h;
        for (int y = 1; y < outH; ++y) {
            uint64_t leaving = rowHashScratch_[static_cast<size_t>(y - 1) * outW + x];
            uint64_t entering = rowHashScratch_[static_cast<size_t>(y + kBlockSize - 1) * outW + x];
            h = (h - leaving * Bpow_h) * kRollBase + entering;
            blockHashScratch_[static_cast<size_t>(y) * outW + x] = h;
        }
    }

    rebuildTable(static_cast<size_t>(outW) * outH);
    for (auto &s : table_) s.occupied = false; // fresh table every frame -- see class comment

    for (int y = 0; y < outH; ++y)
        for (int x = 0; x < outW; ++x)
            insert(blockHashScratch_[static_cast<size_t>(y) * outW + x], regionX + x, regionY + y);

    // ---- 3. Query every block in the dirty box's own block grid against
    // that table. D blocks total, O(D*blockArea) to hash them (SIMD), O(D)
    // amortized for the lookups. ----
    const int blocksX = (dirtyBox.width + kBlockSize - 1) / kBlockSize;
    const int blocksY = (dirtyBox.height + kBlockSize - 1) / kBlockSize;
    const size_t blockCount = static_cast<size_t>(blocksX) * blocksY;

    blockExplainedScratch_.assign(blockCount, 0);
    blockSrcXScratch_.assign(blockCount, 0);
    blockSrcYScratch_.assign(blockCount, 0);

    for (int by = 0; by < blocksY; ++by) {
        for (int bx = 0; bx < blocksX; ++bx) {
            const size_t idx = static_cast<size_t>(by) * blocksX + bx;
            const int qx = dirtyBox.x + bx * kBlockSize;
            const int qy = dirtyBox.y + by * kBlockSize;
            // Only constraint on where we're allowed to READ from is the
            // actual FRAME edge -- reading a couple pixels past dirtyBox's
            // own (usually not 16px-aligned) edge into already-correct
            // territory is always safe (that content matches truth by
            // definition, or it would have been part of the dirty region)
            // and costs zero extra wire bytes either way, since a copy
            // rect is a fixed 24-byte header regardless of its w/h. Only
            // skip a block that would run off the literal screen edge.
            if (qx + kBlockSize > fullW || qy + kBlockSize > fullH) continue;

            const uint8_t *qPtr = currFull + static_cast<size_t>(qy) * strideBytes + static_cast<size_t>(qx) * 4;
            const uint64_t h = computeQueryBlockHash(qPtr, strideBytes);

            int32_t candX, candY;
            if (!lookup(h, candX, candY)) continue;

            const uint8_t *cPtr = prevFull + static_cast<size_t>(candY) * strideBytes + static_cast<size_t>(candX) * 4;
            if (!blocksEqualExact(cPtr, strideBytes, qPtr, strideBytes)) continue; // hash collision, not a real match

            blockExplainedScratch_[idx] = 1;
            blockSrcXScratch_[idx] = candX;
            blockSrcYScratch_[idx] = candY;
        }
    }

    // ---- 4. Coalesce: merge adjacent explained blocks sharing an identical
    // motion offset into as few rectangles as possible. Two passes, O(D)
    // total: horizontal runs per block-row, then merge vertically adjacent
    // runs with matching (x-span, offset) into rectangles, carrying an
    // "active rectangle" list forward one row at a time. ----
    struct Active { int bx0, bx1, offX, offY, startBy; bool matchedThisRow; };
    std::vector<Active> active;
    std::vector<Active> nextActive;

    auto flush = [&](const Active &a, int endByExclusive) {
        const int px = dirtyBox.x + a.bx0 * kBlockSize;
        const int py = dirtyBox.y + a.startBy * kBlockSize;
        // Blocks may read slightly past dirtyBox's own (usually non-16px-
        // aligned) edge into already-correct territory (see the comment at
        // the query loop above) -- clip the reported rect back to
        // dirtyBox's true extent so it only ever describes genuinely dirty
        // pixels, even though including a few extra correct ones would
        // also have been harmless.
        const int pw = std::min((a.bx1 - a.bx0) * kBlockSize, dirtyBox.x + dirtyBox.width - px);
        const int ph = std::min((endByExclusive - a.startBy) * kBlockSize, dirtyBox.y + dirtyBox.height - py);
        if (pw <= 0 || ph <= 0) return; // fully outside dirtyBox (can't happen for a starting block, defensive only)
        if (a.offX == 0 && a.offY == 0) return; // unchanged content, not motion -- nothing to copy, receiver's canvas is already correct here
        wire::CopyRect r;
        r.dstX = static_cast<uint32_t>(px);
        r.dstY = static_cast<uint32_t>(py);
        r.srcX = static_cast<uint32_t>(px + a.offX);
        r.srcY = static_cast<uint32_t>(py + a.offY);
        r.w = static_cast<uint32_t>(pw);
        r.h = static_cast<uint32_t>(ph);
        outCopyRects.push_back(r);
    };

    for (int by = 0; by <= blocksY; ++by) { // one extra iteration to flush the last row's active rects
        std::vector<Active> rowStrips;
        if (by < blocksY) {
            int bx = 0;
            while (bx < blocksX) {
                const size_t idx = static_cast<size_t>(by) * blocksX + bx;
                if (!blockExplainedScratch_[idx]) { ++bx; continue; }
                const int qx = dirtyBox.x + bx * kBlockSize;
                const int qy = dirtyBox.y + by * kBlockSize;
                const int offX = static_cast<int>(blockSrcXScratch_[idx]) - qx;
                const int offY = static_cast<int>(blockSrcYScratch_[idx]) - qy;
                const int runStart = bx;
                while (bx < blocksX) {
                    const size_t idx2 = static_cast<size_t>(by) * blocksX + bx;
                    if (!blockExplainedScratch_[idx2]) break;
                    const int qx2 = dirtyBox.x + bx * kBlockSize;
                    const int qy2 = dirtyBox.y + by * kBlockSize;
                    if (static_cast<int>(blockSrcXScratch_[idx2]) - qx2 != offX ||
                        static_cast<int>(blockSrcYScratch_[idx2]) - qy2 != offY) break;
                    ++bx;
                }
                rowStrips.push_back(Active{runStart, bx, offX, offY, by, false});
            }
        }

        // Try to extend each still-open active rect with a matching strip
        // in this row; anything not extended gets flushed (finalized) now.
        nextActive.clear();
        for (auto &a : active) {
            bool extended = false;
            for (auto &s : rowStrips) {
                if (!s.matchedThisRow && s.bx0 == a.bx0 && s.bx1 == a.bx1 && s.offX == a.offX && s.offY == a.offY) {
                    s.matchedThisRow = true;
                    nextActive.push_back(Active{a.bx0, a.bx1, a.offX, a.offY, a.startBy, false});
                    extended = true;
                    break;
                }
            }
            if (!extended) flush(a, by);
        }
        // Any strip this row that didn't extend an existing rect starts a new one.
        for (auto &s : rowStrips)
            if (!s.matchedThisRow) nextActive.push_back(Active{s.bx0, s.bx1, s.offX, s.offY, by, false});

        active.swap(nextActive);
    }

    // ---- 5. Leftover bounding box: every block NOT explained (including
    // partial edge blocks, always conservatively left unexplained above),
    // in full-frame pixel coordinates, clipped to dirtyBox's own extents. ----
    int minX = dirtyBox.x + dirtyBox.width, minY = dirtyBox.y + dirtyBox.height, maxX = -1, maxY = -1;
    for (int by = 0; by < blocksY; ++by) {
        for (int bx = 0; bx < blocksX; ++bx) {
            const size_t idx = static_cast<size_t>(by) * blocksX + bx;
            if (blockExplainedScratch_[idx]) continue;
            const int qx = dirtyBox.x + bx * kBlockSize;
            const int qy = dirtyBox.y + by * kBlockSize;
            const int qw = std::min(kBlockSize, dirtyBox.x + dirtyBox.width - qx);
            const int qh = std::min(kBlockSize, dirtyBox.y + dirtyBox.height - qy);
            minX = std::min(minX, qx); minY = std::min(minY, qy);
            maxX = std::max(maxX, qx + qw); maxY = std::max(maxY, qy + qh);
        }
    }

    if (maxX < 0) {
        outLeftoverBox = diffdet::BoundingBox{}; // every block explained -- pure motion, no new pixels at all
    } else {
        outLeftoverBox = diffdet::BoundingBox{minX, minY, maxX - minX, maxY - minY};
    }

    return true;
}

} // namespace motiondet
